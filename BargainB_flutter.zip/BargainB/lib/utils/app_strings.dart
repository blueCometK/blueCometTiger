// import 'package:easy_localization/easy_localization.dart';
//
// class AppStrings{
//   static String get createAnAccount => "createAnAccount".tr();
//   // static String get loremIpsum => "loremIpsum".tr();
//   static String get fullName => "fullName".tr();
//   static String get email => "email".tr();
// }