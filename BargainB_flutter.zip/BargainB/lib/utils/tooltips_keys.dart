import 'package:flutter/widgets.dart';

class TooltipKeys {
  static final showCase1 =
      GlobalKey<State<StatefulWidget>>(debugLabel: 'GlobalFormKey1');
  static final showCase2 =
      GlobalKey<State<StatefulWidget>>(debugLabel: 'GlobalFormKey2');
  static final showCase3 =
      GlobalKey<State<StatefulWidget>>(debugLabel: 'GlobalFormKey3');
  static final showCase4 =
      GlobalKey<State<StatefulWidget>>(debugLabel: 'GlobalFormKey4');
  static final showCase5 =
      GlobalKey<State<StatefulWidget>>(debugLabel: 'GlobalFormKey5');
}
