class BaseURl {
  static String baseUrl="https://admin.4geeks.org/api/";
}