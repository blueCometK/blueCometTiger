//User Model
// ignore_for_file: constant_identifier_names

import 'package:cloud_firestore/cloud_firestore.dart';

class UserModel {
  static const String UID = "uid";
  static const String EMAIL = "email";
  static const String NAME = "name";
  static const String USERNAME = "username";
  static const String ABOUT = "about";
  static const String COUNTRY = "country";
  static const String COUNTRY_CODE = "countryCode";
  static const String USER_JOINED_AT = "userJoinedAt";
  static const String ADDRESS = "address";
  static const String NUMBER = "number";
  static const String PIN = "pin";
  static const String PHOTO_URL = "photoUrl";
  static const String LIKES = "likes";
  static const String BETS_WON = "betsWon";
  static const String BETS_LOST = "betsLost";
  static const String ALL_BETS = "allBets";
  static const String APPLIED_FOR_VERIFICATION = "appliedForVerification";
  static const String FOLLOWERS = "followers";
  static const String FOLLOWING = "following";
  static const String RANK = "rank";

  final String uid;
  final num rank;
  final String email;
  final String name;
  final String username;
  final String about;
  final String country;
  final String countryCode;
  final String address;
  final String number;
  final String pin;
  final String photoUrl;
  final Timestamp userJoinedAt;
  final List likes;
  final List betsLost;
  final List allBets;
  final List betsWon;
  final bool appliedForVerification;
  final List followers;
  final List following;

  UserModel({
    required this.uid,
    required this.rank,
    required this.email,
    required this.name,
    required this.username,
    required this.userJoinedAt,
    required this.about,
    required this.country,
    required this.address,
    required this.number,
    required this.pin,
    required this.countryCode,
    required this.photoUrl,
    required this.likes,
    required this.allBets,
    required this.betsWon,
    required this.betsLost,
    required this.appliedForVerification,
    required this.followers,
    required this.following,
  });

  factory UserModel.newUser(
      {required String uid,
      required String name,
      required String email,
      required String country,
      required String countryCode,
      required String username,
      required String photoUrl}) {
    return UserModel(
      rank: 0,
      uid: uid,
      email: email,
      name: name,
      username: username,
      about: "",
      country: country,
      countryCode: countryCode,
      address: "",
      number: "",
      photoUrl: photoUrl,
      pin: "",
      likes: [],
      betsWon: [],
      betsLost: [],
      allBets: [],
      userJoinedAt: Timestamp.now(),
      appliedForVerification: false,
      followers: [],
      following: [],
    );
  }

  factory UserModel.fromMap(Map data) {
    return UserModel(
      uid: data[UID],
      rank: data[RANK] ?? 0,
      email: data[EMAIL] ?? "",
      name: data[NAME] ?? "",
      username: data[USERNAME] ?? "",
      about: data[ABOUT] ?? "",
      country: data[COUNTRY] ?? "",
      countryCode: data[COUNTRY_CODE] ?? "",
      address: data[ADDRESS] ?? "",
      number: data[NUMBER] ?? "",
      pin: data[PIN] ?? "",
      photoUrl: data[PHOTO_URL] ?? "",
      likes: data[LIKES] ?? "",
      userJoinedAt: data[USER_JOINED_AT] ?? "",
      betsWon: data[BETS_WON] ?? [],
      allBets: data[ALL_BETS] ?? [],
      betsLost: data[BETS_LOST] ?? [],
      appliedForVerification: data[APPLIED_FOR_VERIFICATION] ?? false,
      followers: data[FOLLOWERS] ?? [],
      following: data[FOLLOWING] ?? [],
    );
  }

  Map<String, dynamic> toJson() => {
        UID: uid,
        RANK: rank,
        EMAIL: email,
        NAME: name,
        USERNAME: username,
        ABOUT: about,
        COUNTRY: country,
        COUNTRY_CODE: countryCode,
        ADDRESS: address,
        NUMBER: number,
        USER_JOINED_AT: userJoinedAt,
        PIN: pin,
        PHOTO_URL: photoUrl,
        LIKES: likes,
        BETS_WON: betsWon,
        BETS_LOST: betsLost,
        ALL_BETS: allBets,
        APPLIED_FOR_VERIFICATION: appliedForVerification,
        FOLLOWERS: followers,
        FOLLOWING: following
      };
}
