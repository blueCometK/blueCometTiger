class ImageConstant {
  static const String appLogo = 'assets/images/flexx_bet_logo.png';

  static const String congratsImage = 'assets/images/congrats.png';

  static const String yes = 'assets/images/yes.png';

  static const String no = 'assets/images/no.png';
  static const String watched = 'assets/images/watched.png';

  //single events
  static const String followMeIcon = 'assets/images/follow_me.png';
  static const String successCard = 'assets/images/success_card.png';
  static const String filterButton = 'assets/images/filter_button.png';
  static const String liveCircles = 'assets/images/live_circles.png';
  static const String checkMark = 'assets/images/check_mark.png';
  static const String cross = 'assets/images/cross.png';
  static const String checkMarkSelected =
      'assets/images/check_mark_selected.png';
  static const String crossSelected = 'assets/images/cross_selected.png';
  static const String searchIcon = 'assets/images/search_icon.png';

// end

  static const String betLost = 'assets/images/bet_lost.png';
  static const String betWon = 'assets/images/bet_won.png';

  static const String accountNotificationImage =
      'assets/images/account_notification_image.png';

  static const String mapsFemaleIndicator =
      'assets/images/maps_female_indicator.png';

  static const String mapsMaleIndicator =
      'assets/images/maps_male_indicator.png';

  static const String arsenal = 'assets/images/arsenal.png';
  static const String stokeCity = 'assets/images/stoke_city.png';

  static const String techStory = 'assets/images/tech_story.png';
  static const String musicStory = 'assets/images/music_story.png';
  static const String tvStory = 'assets/images/tv_story.png';

  static const String transferAndTopupSuccess =
      'assets/images/transfer_and_topup_success.png';
  static const String sliderButton = 'assets/images/slider_button.png';
  static const String withdrawSuccess = 'assets/images/withdraw_success.png';

  static const String mapsIcon = 'assets/images/maps_icon.png';

  static const String masterCard = 'assets/images/master_card.png';
  static const String visa = 'assets/images/visa.png';
  static const String paypal = 'assets/images/paypal.png';
  static const String payfast = 'assets/images/payfast.png';
  static const String westernUnion = 'assets/images/western_union.png';

  static const String walletConfirmationImage =
      'assets/images/wallet_confirmation.png';

  static const String genshinFake = 'assets/images/genshin_fake.png';

  static const String successImage = 'assets/images/success_image.png';

  static const String betConfirmationImage =
      'assets/images/confirmation_image.png';

  static const String changeCameraIcon = 'assets/images/change_camera.png';
  static const String editProfileIcon = 'assets/images/person_icon.png';
  static const String settingsIcon = 'assets/images/settings_icon.png';
  static const String changePasswordIcon =
      'assets/images/change_password_icon.png';
  static const String referralIcon = 'assets/images/referral_icon.png';
  static const String flexxAgentIcon = 'assets/images/flexx_agent_icon.png';
  static const String privacyPolicyIcon =
      'assets/images/privacy_policy_icon.png';
  static const String supportIcon = 'assets/images/support_icon.png';
  static const String logoutIcon = 'assets/images/logout_icon.png';

  static const String homeIcon = 'assets/images/home_icon.png';
  static const String activeHomeIcon = 'assets/images/home_icon_active.png';
  static const String betIcon = 'assets/images/bet_icon.png';
  static const String activeBetIcon = 'assets/images/bet_icon_active.png';
  static const String activeRankIcon = 'assets/images/rank_icon_active.png';
  static const String activePersonIcon = 'assets/images/person_icon_active.png';
  static const String chatIcon = 'assets/images/chat_icon.png';
  static const String activeChatIcon = 'assets/images/chat_icon_active.png';
  static const String leaderboardIcon = 'assets/images/leaderboard_icon.png';
  static const String userProfileIcon = 'assets/images/user_profile.png';

  static const String rankImage = 'assets/images/rank.png';
  static const String followersImage = 'assets/images/followers.png';
  static const String betsImage = 'assets/images/bets.png';

  static const String successBanner = 'assets/images/success_upper_banner.png';

  static const String leaderBoardPerson = 'assets/images/topper.png';
  static const String leaderBoardPerson2 = 'assets/images/after_topper.png';

  static const String categorySportsImage = 'assets/images/sports_category.png';
  static const String categoryMusicImage = 'assets/images/music_category.png';
  static const String categoryCryptoImage = 'assets/images/crypto_category.png';
  static const String categoryOtherImage = 'assets/images/other_category.png';

  static const String liveEvent1 = 'assets/images/live_event.png';
  static const String liveEvent2 = 'assets/images/live_event_two.png';
  static const String liveEvent3 = 'assets/images/live_event_three.png';
  static const String liveEvent4 = 'assets/images/live_event_four.png';

  static const String user1 = 'assets/images/user_one.png';
  static const String user2 = 'assets/images/user_two.png';
  static const String user3 = 'assets/images/user_three.png';
  static const String user4 = 'assets/images/user_four.png';

  static const String internalServerErrorBanner =
      'assets/images/internal_server_error.png';
  static const String noInternetBanner = 'assets/images/no_internet.png';

  static const String homeSlideBanner1 = 'assets/images/home_banner.png';

  static const String sendIcon = 'assets/images/icon_send.png';
  static const String withdrawIcon = 'assets/images/withdraw_icon.png';

  static const String likes = 'assets/images/likes.png';
  static const String betImage = 'assets/images/event_photo.png';
  static const String comments = 'assets/images/comments.png';

  static const String doneIcon = 'assets/images/done.svg';
  static const String editIcon = 'assets/images/edit.svg';

  static const String cashout = 'assets/images/cashout.png';

  static const String accCheckBanner =
      'assets/images/acc_checking_upper_banner.png';
  static const String user = 'assets/images/user_default.png';
  static const String usFlag = 'assets/images/us.png';
  static const String identityVerfication =
      'assets/images/identity_verfication.png';
  static const String createBetCominSoon = 'assets/images/create_bet.png';
  static const String hiEmoji = 'assets/images/hi_emoji.png';
  static const String apple = 'assets/images/apple.png';
  static const String google = 'assets/images/google.png';
  static const String facebook = 'assets/images/facebook.png';
  static const String upperOnboardingImage =
      'assets/images/top_banner_onboarding.png';
  static const String bottomOnboardingImage =
      'assets/images/bottom_banner_onboarding.png';
}
