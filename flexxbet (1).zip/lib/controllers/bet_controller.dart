import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flexx_bet/controllers/auth_controller.dart';
import 'package:flexx_bet/controllers/events_controller.dart';
import 'package:flexx_bet/controllers/leaderboard_controller.dart';
import 'package:flexx_bet/models/bet_model.dart';
import 'package:flexx_bet/ui/components/loading.dart';
import 'package:get/get.dart';
import 'package:uuid/uuid.dart';

class BetsController extends GetxController {
  static BetsController to = Get.find<BetsController>();
  final LeaderboardController _leaderbardController =
      Get.put(LeaderboardController());
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  bool isNewBetPossible = false;
  final Rxn<num> userSelectedAmount = Rxn<num>(500);
  final Rxn<String> userSelectedOption = Rxn<String>();
  Rxn<BetModel> currentBet = Rxn<BetModel>();

  Rxn<BetModel> bet = Rxn<BetModel>();
  var uuid = const Uuid();

  Future getBetWithRequirements() async {
    Get.log("_getBetWithRequirements of event");
    Get.log(EventsController.to.currentEvent.value!.uid, isError: true);

    try {
      currentBet.value = await _db
          .collection('/bets')
          .where(BetModel.FIRST_USER,
              isNotEqualTo: AuthController.to.firestoreUser.value!.uid)
          .where(BetModel.STATUS, isEqualTo: BetModel.BetStatus.WAITING)
          .where(BetModel.SECOND_USER, isEqualTo: "")
          .where(BetModel.FIRST_USER_AMOUNT,
              isEqualTo: userSelectedAmount.value!)
          .where(BetModel.EVENT_ID,
              isEqualTo: EventsController.to.currentEvent.value!.uid)
          .get()
          .then((snapshot) {
        if (snapshot.docs.isNotEmpty) {
          return BetModel.fromMap(snapshot.docs.first.data());
        } else {
          return null;
        }
      });
      if (currentBet.value != null) {
        userSelectedOption.value = currentBet.value!.secondUserSelectedOption;

        Get.log("currentBet.value event: ${currentBet.value!.eventId}");
      } else {
        _checkNewBetPossible();
      }
    } catch (e) {
      Get.log(e.toString(), isError: true);
    }
  }

  Future _checkNewBetPossible() async {
    Get.log("checkNewBetPossible of event");
    EventsController eventsController = EventsController.to;
    Get.log(eventsController.currentEvent.value!.uid, isError: true);
    try {
      isNewBetPossible = await _db
          .collection('/bets')
          .where(BetModel.FIRST_USER,
              isEqualTo: AuthController.to.firestoreUser.value!.uid)
          .where(BetModel.EVENT_ID,
              isEqualTo: eventsController.currentEvent.value!.uid)
          .where(BetModel.FIRST_USER_AMOUNT,
              isEqualTo: userSelectedAmount.value!)
          .get()
          .then((value) {
        Get.log("isNewBetPossible ${value.docs.isEmpty}");
        return value.docs.isEmpty;
      });
      update();
    } catch (e) {
      Get.log(e.toString(), isError: true);
    }
  }

  Future createEntirelyNewBet() async {
    EventsController eventsController = EventsController.to;
    AuthController authController = AuthController.to;
    try {
      BetModel bet = BetModel(
        uid: uuid.v1(),
        status: BetModel.BetStatus.WAITING,
        eventId: eventsController.currentEvent.value!.uid,
        firstUser: authController.firestoreUser.value!.uid,
        firstUsername: authController.firestoreUser.value!.username,
        firstUserAmount: userSelectedAmount.value!,
        firstUserSelectedOption: userSelectedOption.value!,
        secondUser: "",
        secondUsername: "",
        secondUserAmount: userSelectedAmount.value!,
        secondUserSelectedOption:
            userSelectedOption.value! == "yes" ? "no" : "yes",
        correctOption: "to be decided",
        userWonId: "",
      );
      await _createBet(bet);
      await eventsController.addUserToEventPeopleWaiting();
    } catch (e) {
      Get.log(e.toString(), isError: true);
    }
  }

  Future loadBetData(String betId) async {
    Get.log("loadBetData");
    showLoadingIndicator();
    try {
      await _getBet(betId);
    } catch (e) {
      Get.log(e.toString(), isError: true);
    }
    hideLoadingIndicator();
  }

  Future joinBet() async {
    Get.log("joinBet");
    EventsController eventsController = EventsController.to;
    AuthController authController = AuthController.to;
    try {
      BetModel updatedBet = BetModel(
          uid: currentBet.value!.uid,
          status: BetModel.BetStatus.STARTED,
          eventId: currentBet.value!.eventId,
          firstUsername: currentBet.value!.firstUsername,
          firstUser: currentBet.value!.firstUser,
          firstUserAmount: currentBet.value!.firstUserAmount,
          firstUserSelectedOption: currentBet.value!.firstUserSelectedOption,
          secondUser: authController.firestoreUser.value!.uid,
          secondUsername: authController.firestoreUser.value!.username,
          secondUserAmount: currentBet.value!.secondUserAmount,
          secondUserSelectedOption: currentBet.value!.secondUserSelectedOption,
          correctOption: currentBet.value!.correctOption,
          userWonId: currentBet.value!.userWonId);
      await _leaderbardController
          .enterOrUpdateLeaderboard(updatedBet.firstUser);
      await eventsController.removeUserFromEventPeopleWaiting();
      await eventsController.removeUserFromEventPeopleWaiting(
          userId: currentBet.value!.firstUser);
      await eventsController.addUserToEventPeopleBetting();
      await eventsController.addUserToEventPeopleBetting(
          userId: currentBet.value!.firstUser);

      await authController.addBetInUserRecord(
          authController.firestoreUser.value!, updatedBet.uid);
      await authController.loadAnotherUserData(updatedBet.firstUser);
      await authController.addBetInUserRecord(
          authController.otherUser!, updatedBet.uid);

      await _updateBet(updatedBet);
      update();
    } catch (e) {
      Get.log(e.toString(), isError: true);
    }
  }

  Future _createBet(BetModel bet) async {
    Get.log("_createBet");
    await _db.doc('/bets/${bet.uid}').set(bet.toJson());
    update();
  }

  Future _updateBet(BetModel bet) async {
    Get.log("_updateBet");

    await _db.doc('/bets/${bet.uid}').update(bet.toJson());
    update();
  }

  Future _getBet(String betId) async {
    Get.log("_updateBet");
    currentBet.value = await _db
        .doc('/bets/$betId')
        .get()
        .then((betJson) => BetModel.fromMap(betJson.data()!));
    update();
  }
}
