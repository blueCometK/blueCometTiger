import 'dart:io';
import 'package:country_codes/country_codes.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flexx_bet/controllers/events_controller.dart';
import 'package:flexx_bet/controllers/landing_page_controller.dart';
import 'package:flexx_bet/models/verification_request_model.dart';
import 'package:flexx_bet/ui/auth/create_pin_ui.dart';
import 'package:flexx_bet/ui/home/landing_page_ui.dart';
import 'package:flexx_bet/ui/onboarding/onboarding_ui.dart';
import 'package:flexx_bet/ui/profile/widget/success_dialog.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'dart:async';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:get/get.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flexx_bet/models/models.dart';
import 'package:flexx_bet/ui/components/components.dart';
import 'package:google_sign_in/google_sign_in.dart';

class AuthController extends GetxController {
  static AuthController to = Get.find<AuthController>();
  final EventsController _eventsController =
      Get.put<EventsController>(EventsController());
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _db = FirebaseFirestore.instance;
  final FirebaseStorage _storage = FirebaseStorage.instance;
  final GoogleSignIn _googleSignIn = GoogleSignIn.standard(scopes: ['email']);
  late VerificationRequestModel verificationRequest;
  final Rxn<User> _firebaseUser = Rxn<User>();
  Rxn<UserModel> firestoreUser = Rxn<UserModel>();
  final RxBool admin = false.obs;
  static const String defaultPicture =
      "https://firebasestorage.googleapis.com/v0/b/flexxbet.appspot.com/o/user_default.png?alt=media&token=21e970c2-55e9-4a3e-99bc-6a12a5338466";

  UserModel? otherUser;
  List<UserModel?> usersPresent = [];
  String? country;
  String? countryCode;
  String gender = "";

  TextEditingController usernameController = TextEditingController();
  TextEditingController nameController = TextEditingController();
  TextEditingController emailController = TextEditingController();
  TextEditingController pinTextController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  TextEditingController aboutController = TextEditingController();
  TextEditingController numberController = TextEditingController();
  TextEditingController addressController = TextEditingController();
  TextEditingController oldPasswordController = TextEditingController();
  TextEditingController confirmPasswordController = TextEditingController();
  TextEditingController confirmEmailController = TextEditingController();

  @override
  void onReady() async {
    await CountryCodes.init();
    //run every time auth state changes
    ever(_firebaseUser, handleAuthChanged);

    _firebaseUser.bindStream(user);

    super.onReady();
  }

  Future<void> initFirestoreUserStream() {
    Get.log("initStream");
    firestoreUser.bindStream(streamFirestoreUser());
    var firstValueReceived = Completer<void>();
    firestoreUser.listen((val) {
      if (!firstValueReceived.isCompleted) {
        firstValueReceived.complete();
      }
    });
    return firstValueReceived.future;
  }

  void handleAuthChanged(User? firebaseUser) async {
    Get.log("handleAuthChanged");
    //get user data from firestore
    if (firebaseUser != null) {
      await initFirestoreUserStream();
      await isAdmin();

      if (firestoreUser.value!.pin == "") {
        if (kDebugMode) {
          Get.log('Send to CreatePinScreen');
        }

        Get.offAll(() => const CreatePinScreen());
      } else {
        if (kDebugMode) {
          Get.log('Send to HomeScreen');
        }
        Get.offAll(() => LandingPage());
      }
    } else {
      if (kDebugMode) {
        Get.log('Send to onboarding');
      }
      Get.offAll(() => const OnboardingScreen());
    }
  }

  get isAuthenticated => _firebaseUser.value != null;
  // Firebase user one-time fetch
  Future<User> get getUser async => _auth.currentUser!;

  // Firebase user a realtime stream
  Stream<User?> get user => _auth.authStateChanges();

  //Streams the firestore user from the firestore collection
  Stream<UserModel> streamFirestoreUser() {
    if (kDebugMode) {
      Get.log('streamFirestoreUser()');
    }

    return _db
        .doc('/users/${_firebaseUser.value!.uid}')
        .snapshots()
        .map((snapshot) {
      if (snapshot.data() != null) {
        return UserModel.fromMap(snapshot.data()!);
      } else {
        UserModel newUser = UserModel.newUser(
          uid: _firebaseUser.value!.uid,
          email: _firebaseUser.value!.email!,
          name: _firebaseUser.value!.displayName!,
          country: CountryCodes.detailsForLocale().name!,
          countryCode: CountryCodes.detailsForLocale().dialCode!,
          username: "",
          photoUrl: _firebaseUser.value!.photoURL!,
        );
        _createUserFirestore(newUser, _firebaseUser.value!);
        return newUser;
      }
    });
  }

  //get the firestore user from the firestore collection
  Future<UserModel?> _getFirestoreUser() {
    Get.log("_getFirestoreUser");
    return _db.doc('/users/${_firebaseUser.value!.uid}').get().then(
        (documentSnapshot) => documentSnapshot.data() == null
            ? null
            : UserModel.fromMap(documentSnapshot.data()!));
  }

  //get the firestore user from the firestore collection
  Future<UserModel?> _getFirestoreAnotherUser(String userId) async {
    Get.log("_getFirestoreAnotherUser");
    return await _db.doc('/users/$userId').get().then((documentSnapshot) =>
        documentSnapshot.data() == null
            ? null
            : UserModel.fromMap(documentSnapshot.data()!));
  }

  Future loadAnotherUserData(String userId) async {
    Get.log("loadAnotherUserData");
    try {
      otherUser = await _getFirestoreAnotherUser(userId);
    } catch (e) {
      Get.log(e.toString(), isError: true);
    }
  }

  Future loadUsersPresent(List userIds) async {
    Get.log("loadUsersPresent");
    try {
      List<UserModel?> newUserList = [];
      for (String userId in userIds) {
        newUserList.add(await _getFirestoreAnotherUser(userId));
      }
      usersPresent = newUserList;
    } catch (e) {
      Get.log(e.toString(), isError: true);
    }
  }

  //Method to handle user sign in using email and password
  Future signInUserWithEmailAndPassword() async {
    Get.log("signInUserWithEmailAndPassword");
    showLoadingIndicator();
    try {
      await _auth.signInWithEmailAndPassword(
          email: emailController.text.trim(),
          password: passwordController.text.trim());

      hideLoadingIndicator();
    } catch (error) {
      Get.log(error.toString(), isError: true);
      hideLoadingIndicator();
      Get.snackbar('auth.signInErrorTitle'.tr, 'auth.signInError'.tr,
          snackPosition: SnackPosition.BOTTOM,
          duration: const Duration(seconds: 7),
          backgroundColor: Get.theme.snackBarTheme.backgroundColor,
          colorText: Get.theme.snackBarTheme.actionTextColor);
    }
  }

  Future registerAndSignInUserWithGoogle() async {
    Get.log("registerAndSignInUserWithGoogle");
    showLoadingIndicator();
    try {
      GoogleSignInAccount? googleSignInAccount = await _googleSignIn.signIn();

      if (googleSignInAccount == null) {
        Get.snackbar('auth.signInErrorTitle'.tr, 'auth.signInErrorGoogle'.tr,
            snackPosition: SnackPosition.BOTTOM,
            duration: const Duration(seconds: 7),
            backgroundColor: Get.theme.snackBarTheme.backgroundColor,
            colorText: Get.theme.snackBarTheme.actionTextColor);
        return;
      }

      GoogleSignInAuthentication googleSignInAuthentication =
          await googleSignInAccount.authentication;

      AuthCredential credential = GoogleAuthProvider.credential(
        accessToken: googleSignInAuthentication.accessToken,
        idToken: googleSignInAuthentication.idToken,
      );

      await _auth.signInWithCredential(credential);

      hideLoadingIndicator();
    } catch (error) {
      Get.log(error.toString(), isError: true);
      hideLoadingIndicator();
      Get.snackbar('auth.signInErrorTitle'.tr, 'Something went wrong'.tr,
          snackPosition: SnackPosition.BOTTOM,
          duration: const Duration(seconds: 7),
          backgroundColor: Get.theme.snackBarTheme.backgroundColor,
          colorText: Get.theme.snackBarTheme.actionTextColor);
    }
  }

  // User registration using email and password
  Future registerUserWithEmailAndPassword() async {
    Get.log("registerUserWithEmailAndPassword");
    showLoadingIndicator();
    try {
      await _auth
          .createUserWithEmailAndPassword(
              email: emailController.text, password: passwordController.text)
          .then((result) async {
        if (kDebugMode) {
          Get.log('uID: ${result.user!.uid}');
          Get.log('email: ${result.user!.email}');
        }

        //create the new user object
        UserModel newUser = UserModel.newUser(
          uid: result.user!.uid,
          email: result.user!.email!,
          name: nameController.text,
          country: CountryCodes.detailsForLocale().name!,
          countryCode: CountryCodes.detailsForLocale().dialCode!,
          username: usernameController.text,
          photoUrl: defaultPicture,
        );
        //create the user in firestore
        _createUserFirestore(newUser, result.user!);
        hideLoadingIndicator();
      });
    } on FirebaseAuthException catch (error) {
      Get.log(error.toString(), isError: true);
      hideLoadingIndicator();
      Get.snackbar('auth.signUpErrorTitle'.tr, error.message!,
          snackPosition: SnackPosition.BOTTOM,
          duration: const Duration(seconds: 10),
          backgroundColor: Get.theme.snackBarTheme.backgroundColor,
          colorText: Get.theme.snackBarTheme.actionTextColor);
    } catch (e) {
      Get.log(e.toString(), isError: true);
    }
  }

  //handles updating the user when updating profile
  Future<void> updateUserEmail() async {
    Get.log("updateUserEmail");
    UserModel user = firestoreUser.value!;

    showLoadingIndicator();
    try {
      UserCredential firebaseUser = await _auth.signInWithEmailAndPassword(
          email: user.email, password: passwordController.text.trim());
      if (pinTextController.text.trim() == user.pin) {
        await firebaseUser.user!
            .updateEmail(emailController.text.trim())
            .then((value) => _updateUserFirestore(user));
        SuccessDialog.show("Email");
      } else {
        Get.snackbar(
            "Invalid Pin", "Pin you entered is not correct for this account",
            snackPosition: SnackPosition.BOTTOM,
            duration: const Duration(seconds: 5),
            backgroundColor: Get.theme.snackBarTheme.backgroundColor,
            colorText: Get.theme.snackBarTheme.actionTextColor);
      }
    } catch (err) {
      if (kDebugMode) {
        Get.log('Caught error: $err');
      }
      String authUpdateUserNoticeTitle;
      String authUpdateUserNotice;
      if (err.toString() ==
          "[firebase_auth/email-already-in-use] The email address is already in use by another account.") {
        authUpdateUserNoticeTitle = 'auth.updateUserEmailInUse'.tr;
        authUpdateUserNotice = 'auth.updateUserEmailInUse'.tr;
      } else {
        authUpdateUserNoticeTitle = 'auth.wrongPasswordNotice'.tr;
        authUpdateUserNotice = 'auth.wrongPasswordNotice'.tr;
      }
      Get.snackbar(authUpdateUserNoticeTitle, authUpdateUserNotice,
          snackPosition: SnackPosition.BOTTOM,
          duration: const Duration(seconds: 5),
          backgroundColor: Get.theme.snackBarTheme.backgroundColor,
          colorText: Get.theme.snackBarTheme.actionTextColor);
    }

    hideLoadingIndicator();
  }

  Future<void> updateUserPassword() async {
    Get.log("updateUserPassword");
    UserModel user = firestoreUser.value!;
    showLoadingIndicator();
    try {
      UserCredential firebaseUser = await _auth.signInWithEmailAndPassword(
          email: user.email, password: oldPasswordController.text.trim());
      if (pinTextController.text.trim() == user.pin) {
        await firebaseUser.user!.updatePassword(passwordController.text.trim());
        SuccessDialog.show("Password");
      } else {
        Get.snackbar(
            "Invalid Pin", "Pin you entered is not correct for this account",
            snackPosition: SnackPosition.BOTTOM,
            duration: const Duration(seconds: 5),
            backgroundColor: Get.theme.snackBarTheme.backgroundColor,
            colorText: Get.theme.snackBarTheme.actionTextColor);
      }
    } catch (err) {
      if (kDebugMode) {
        Get.log('Caught error: $err');
      }
      if (err.toString() ==
          "[firebase_auth/wrong-password] The password is invalid or the user does not have a password.") {
        Get.snackbar(
            'Update password failure', "auth.wrongOldPasswordNotice".tr,
            snackPosition: SnackPosition.BOTTOM,
            duration: const Duration(seconds: 10),
            backgroundColor: Get.theme.snackBarTheme.backgroundColor,
            colorText: Get.theme.snackBarTheme.actionTextColor);
      } else {
        Get.snackbar('auth.unknownError'.tr,
            "There was a Error updating Password, please try later",
            snackPosition: SnackPosition.BOTTOM,
            duration: const Duration(seconds: 10),
            backgroundColor: Get.theme.snackBarTheme.backgroundColor,
            colorText: Get.theme.snackBarTheme.actionTextColor);
      }
    }
    hideLoadingIndicator();
  }

  Future addToUserFollowers(UserModel user) async {
    Get.log("addToUserFollowers");
    showLoadingIndicator();
    try {
      if (otherUser!.uid == firestoreUser.value!.uid) {
        return;
      }
      UserModel prevUserModel = user;
      if (!prevUserModel.followers.contains(firestoreUser.value!.uid)) {
        List followers = [...prevUserModel.followers, firestoreUser.value!.uid];
        UserModel userModel = updateUserModelFieldsAsWanted(
          prevUserModel,
          followers: followers,
        );

        _updateUserFirestore(userModel);
      }
    } catch (e) {
      Get.log(e.toString(), isError: true);
    }
    hideLoadingIndicator();
  }

  Future addToUserFollowing(String userId) async {
    Get.log("addToUserFollowing");
    showLoadingIndicator();
    try {
      if (otherUser!.uid == firestoreUser.value!.uid) {
        return;
      }
      UserModel prevUserModel = firestoreUser.value!;
      if (!prevUserModel.following.contains(userId)) {
        List following = [...prevUserModel.following, userId];
        UserModel userModel = updateUserModelFieldsAsWanted(
          prevUserModel,
          following: following,
        );

        _updateUserFirestore(userModel);
      }
    } catch (e) {
      Get.log(e.toString(), isError: true);
    }
    hideLoadingIndicator();
  }

  Future removeFromUserFollowers(UserModel user) async {
    Get.log("removeFromUserFollowers");
    showLoadingIndicator();
    try {
      if (otherUser!.uid == firestoreUser.value!.uid) {
        return;
      }
      UserModel prevUserModel = user;
      List followers = prevUserModel.followers;
      if (followers.remove(firestoreUser.value!.uid)) {
        Get.log("removing follower");

        UserModel userModel = updateUserModelFieldsAsWanted(
          prevUserModel,
          followers: followers,
        );

        _updateUserFirestore(userModel);
      }
    } catch (e) {
      Get.log(e.toString(), isError: true);
    }
    hideLoadingIndicator();
  }

  Future removeFromUserFollowing(String userId) async {
    Get.log("removeFromUserFollowing");
    showLoadingIndicator();
    try {
      if (otherUser!.uid == firestoreUser.value!.uid) {
        return;
      }
      UserModel prevUserModel = firestoreUser.value!;
      List following = prevUserModel.following;
      if (following.remove(userId)) {
        Get.log("removing following");

        UserModel userModel = updateUserModelFieldsAsWanted(
          prevUserModel,
          following: following,
        );

        _updateUserFirestore(userModel);
      }
    } catch (e) {
      Get.log(e.toString(), isError: true);
    }
    hideLoadingIndicator();
  }

  Future addBetInUserRecord(UserModel user, String betId) async {
    Get.log("addBetInUserRecord");
    showLoadingIndicator();
    try {
      UserModel prevUserModel = user;
      List allBets = [...prevUserModel.allBets, betId];
      UserModel userModel = updateUserModelFieldsAsWanted(
        prevUserModel,
        allBets: allBets,
      );

      if (kDebugMode) {
        Get.log("The url ${userModel.photoUrl}");
      }

      _updateUserFirestore(userModel);
    } catch (e) {
      Get.log(e.toString(), isError: true);
    }
    hideLoadingIndicator();
  }

  Future updateUserProfileImage(File image) async {
    Get.log("updateUserProfileImage");
    showLoadingIndicator();
    try {
      Reference reference =
          _storage.ref().child("profile_image${_firebaseUser.value!.uid}");
      UploadTask uploadTask = reference.putFile(image);
      UserModel prevUserModel = firestoreUser.value!;
      late UserModel userModel;
      await uploadTask.whenComplete(() async {
        userModel = updateUserModelFieldsAsWanted(
          prevUserModel,
          photoUrl: await reference.getDownloadURL(),
        );

        if (kDebugMode) {
          Get.log("The url ${userModel.photoUrl}");
        }
      });
      _updateUserFirestore(userModel);
    } catch (e) {
      Get.log(e.toString(), isError: true);
    }
    hideLoadingIndicator();
  }

  Future updateUserPin() async {
    Get.log("updateUserPin");
    showLoadingIndicator();
    try {
      UserModel prevUserModel = firestoreUser.value!;
      UserModel userModel = updateUserModelFieldsAsWanted(
        prevUserModel,
        pin: pinTextController.text.trim(),
      );

      if (kDebugMode) {
        Get.log("The url ${userModel.photoUrl}");
      }

      _updateUserFirestore(userModel);
      pinTextController.clear();
    } catch (e) {
      Get.log(e.toString(), isError: true);
    }
    hideLoadingIndicator();
  }

  Future updateUserProfile() async {
    Get.log("updateUserProfile");
    try {
      showLoadingIndicator();

      UserModel prevUserModel = firestoreUser.value!;

      UserModel userModel = updateUserModelFieldsAsWanted(
        prevUserModel,
        name: nameController.text.trim(),
        username: usernameController.text.trim(),
        about: aboutController.text.trim(),
        country: country ?? CountryCodes.detailsForLocale().name!,
        countryCode: countryCode ?? CountryCodes.detailsForLocale().dialCode!,
        address: addressController.text.trim(),
        number: numberController.text.trim(),
      );

      if (kDebugMode) {
        Get.log("The url ${userModel.photoUrl}");
      }
      _updateUserFirestore(userModel);

      SuccessDialog.show("Profile");
    } catch (e) {
      Get.log(e.toString(), isError: true);
    }
    hideLoadingIndicator();
  }

  Future<void> setUserVerificationApplied(File image) async {
    Get.log("setUserVerificationApplied");
    try {
      showLoadingIndicator();
      Reference reference =
          _storage.ref().child("verfication_image${_firebaseUser.value!.uid}");
      UploadTask uploadTask = reference.putFile(image);
      await uploadTask.whenComplete(() async {
        verificationRequest.imageUrl = await reference.getDownloadURL();
        if (kDebugMode) {
          Get.log("The url ${verificationRequest.imageUrl!}");
        }
      });
      assert(verificationRequest.imageUrl != null);

      UserModel prevUserModel = firestoreUser.value!;

      UserModel userModel = updateUserModelFieldsAsWanted(prevUserModel,
          appliedForVerification: true);

      _updateUserFirestore(userModel);
      _createVerificationRequestFirestore(
          verificationRequest, _firebaseUser.value!);
      hideLoadingIndicator();
    } catch (e) {
      Get.log(
        e.toString(),
        isError: true,
      );
      hideLoadingIndicator();
    }
  }

  //updates the firestore user in users collection
  void _updateUserFirestore(UserModel user) async {
    Get.log("_updateUserFirestore");
    await _db.doc('/users/${user.uid}').update(user.toJson());
    update();
  }

  //create the firestore user in users collection
  Future _createUserFirestore(UserModel user, User firebaseUser) async {
    Get.log("_createUserFirestore");
    await _db.doc('/users/${firebaseUser.uid}').set(user.toJson());
    update();
  }

  void _createVerificationRequestFirestore(
      VerificationRequestModel verificationRequestModel, User firebaseUser) {
    Get.log("_createVerificationRequestFirestore");
    _db
        .doc('/verificationRequest/${firebaseUser.uid}')
        .set(verificationRequestModel.toJson());
    update();
  }

  //password reset email
  Future<void> sendPasswordResetEmail(BuildContext context) async {
    Get.log("sendPasswordResetEmail");
    showLoadingIndicator();
    try {
      await _auth.sendPasswordResetEmail(email: emailController.text);
      hideLoadingIndicator();
      Get.snackbar(
          'auth.resetPasswordNoticeTitle'.tr, 'auth.resetPasswordNotice'.tr,
          snackPosition: SnackPosition.BOTTOM,
          duration: const Duration(seconds: 5),
          backgroundColor: Get.theme.snackBarTheme.backgroundColor,
          colorText: Get.theme.snackBarTheme.actionTextColor);
    } on FirebaseAuthException catch (error) {
      hideLoadingIndicator();
      Get.snackbar('auth.resetPasswordFailed'.tr, error.message!,
          snackPosition: SnackPosition.BOTTOM,
          duration: const Duration(seconds: 10),
          backgroundColor: Get.theme.snackBarTheme.backgroundColor,
          colorText: Get.theme.snackBarTheme.actionTextColor);
    }
  }

  //check if user is an admin user
  Future isAdmin() async {
    Get.log("isAdmin");
    await getUser.then((user) async {
      DocumentSnapshot adminRef =
          await _db.collection('admin').doc(user.uid).get();
      if (adminRef.exists) {
        admin.value = true;
      } else {
        admin.value = false;
      }
      update();
    });
  }

  UserModel updateUserModelFieldsAsWanted(
    UserModel prevUserModel, {
    num? rank,
    String? uid,
    String? email,
    String? name,
    String? username,
    String? about,
    String? country,
    String? photoUrl,
    String? number,
    String? address,
    String? countryCode,
    String? pin,
    String? photoURl,
    List? likes,
    List? betsWon,
    List? betsLost,
    List? allBets,
    bool? appliedForVerification,
    List? followers,
    List? following,
  }) {
    return UserModel(
      rank: rank ?? prevUserModel.rank,
      uid: uid ?? prevUserModel.uid,
      email: email ?? prevUserModel.email,
      name: name ?? prevUserModel.name,
      username: username ?? prevUserModel.username,
      about: about ?? prevUserModel.about,
      country: country ?? prevUserModel.country,
      userJoinedAt: prevUserModel.userJoinedAt,
      address: address ?? prevUserModel.address,
      number: number ?? prevUserModel.number,
      countryCode: countryCode ?? prevUserModel.countryCode,
      pin: pin ?? prevUserModel.pin,
      photoUrl: photoUrl ?? prevUserModel.photoUrl,
      likes: likes ?? prevUserModel.likes,
      betsWon: betsWon ?? prevUserModel.betsWon,
      allBets: allBets ?? prevUserModel.allBets,
      betsLost: betsLost ?? prevUserModel.betsLost,
      appliedForVerification:
          appliedForVerification ?? prevUserModel.appliedForVerification,
      followers: followers ?? prevUserModel.followers,
      following: following ?? prevUserModel.following,
    );
  }

  @override
  void onClose() {
    nameController.dispose();
    aboutController.dispose();
    numberController.dispose();
    addressController.dispose();
    emailController.dispose();
    pinTextController.dispose();
    oldPasswordController.dispose();
    passwordController.dispose();
    confirmPasswordController.dispose();
    usernameController.dispose();
    confirmEmailController.dispose();
    !_eventsController.isClosed ? _eventsController.dispose() : null;
    Get.log("Authcontroller onClose");
    super.onClose();
  }

  // Sign out
  Future<void> signOut() async {
    Get.log("signOut");
    usernameController.clear();
    nameController.clear();
    emailController.clear();
    pinTextController.clear();
    passwordController.clear();
    aboutController.clear();
    numberController.clear();
    addressController.clear();
    oldPasswordController.clear();
    confirmPasswordController.clear();
    confirmEmailController.clear();
    LandingPageController.to.changeTabIndex(0);
    if (await _googleSignIn.isSignedIn()) {
      await _googleSignIn.disconnect();
    }
    return _auth.signOut();
  }
}
