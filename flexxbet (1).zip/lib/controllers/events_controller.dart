import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flexx_bet/controllers/auth_controller.dart';
import 'package:flexx_bet/controllers/bet_controller.dart';
import 'package:flexx_bet/models/event_model.dart';
import 'package:flexx_bet/ui/components/loading.dart';
import 'package:get/get.dart';

class EventsController extends GetxController {
  static EventsController to = Get.find<EventsController>();
  final BetsController _betsController = Get.put(BetsController());
  final FirebaseFirestore _db = FirebaseFirestore.instance;
  Rxn<List<EventModel>> featuredEvents = Rxn<List<EventModel>>();
  Rxn<List<EventModel>> liveEvents = Rxn<List<EventModel>>();
  List<EventModel> fiveNextEvents = [];
  Rxn<List<EventModel>> upcomingEvents = Rxn<List<EventModel>>();
  Rxn<EventModel> currentEvent = Rxn<EventModel>();
  List<QueryDocumentSnapshot<Map<String, dynamic>>> documentList = [];
  bool? isLive;

  @override
  void onReady() {
    liveEvents.bindStream(_streamLiveEvents());
    upcomingEvents.bindStream(_streamUpcomingEvents());
    featuredEvents.bindStream(_streamFeaturedEvents());
    super.onReady();
  }

  Stream<List<EventModel>> _streamLiveEvents() {
    Get.log("_streamLiveEvents");

    return _db
        .collection('/events')
        .where("heldDate", isLessThan: Timestamp.now())
        .where("isEnded", isEqualTo: false)
        .where("isCancelled", isEqualTo: false)
        .snapshots()
        .map((snapshot) {
      List<EventModel> events = [];
      for (var doc in snapshot.docs) {
        events.add(EventModel.fromMap(doc.data()));
      }
      return events;
    });
  }

  Future fetchFirstEventsList() async {
    Get.log("fetchFirstEventsList");
    try {
      documentList = (await _db
              .collection('/events')
              .where("uid", isNotEqualTo: currentEvent.value!.uid)
              .limit(5)
              .get())
          .docs;
      for (var value in documentList) {
        fiveNextEvents.add(EventModel.fromMap(value.data()));
      }
    } catch (e) {
      Get.log(e.toString(), isError: true);
    }
  }

  Future loadFiveNextEvents({String? userId}) async {
    Get.log("loadFiveNextEvents");
    try {
      List<QueryDocumentSnapshot<Map<String, dynamic>>> newDocumentList =
          (await _db
                  .collection('/events')
                  .orderBy("uid", descending: false)
                  .startAfterDocument(documentList[documentList.length - 1])
                  .limit(5)
                  .get())
              .docs;
      for (var value in newDocumentList) {
        List<EventModel> events = [];
        events.add(EventModel.fromMap(value.data()));
        fiveNextEvents = events;
      }
    } catch (e) {
      Get.log(e.toString(), isError: true);
    }
  }

  Future addUserToEventPeopleWaiting({String? userId}) async {
    Get.log("addUserToEventPeopleWaiting");
    AuthController authController = AuthController.to;
    try {
      String userIdf = userId ?? authController.firestoreUser.value!.uid;
      if (!currentEvent.value!.peopleWaiting.contains(userIdf)) {
        EventModel newEvent = updateEventFieldsAsWanted(currentEvent.value!,
            peopleWaiting: [
              ...currentEvent.value!.peopleWaiting,
              authController.firestoreUser.value!.uid
            ]);
        await _updateEvent(newEvent, currentEvent.value!.uid);
      }
    } catch (e) {
      Get.log(e.toString(), isError: true);
    }
  }

  Future addUserToEventPeopleBetting({String? userId}) async {
    Get.log("addUserToEventPeopleBetting");
    AuthController authController = AuthController.to;
    try {
      String userIdf = userId ?? authController.firestoreUser.value!.uid;
      if (!currentEvent.value!.peopleBetting.contains(userIdf)) {
        EventModel newEvent = updateEventFieldsAsWanted(currentEvent.value!,
            peopleBetting: [
              ...currentEvent.value!.peopleBetting,
              authController.firestoreUser.value!.uid
            ]);
        await _updateEvent(newEvent, currentEvent.value!.uid);
      }
    } catch (e) {
      Get.log(e.toString(), isError: true);
    }
  }

  Future removeUserFromEventPeopleWaiting({String? userId}) async {
    Get.log("removeUserToEventPeopleWaiting");
    AuthController authController = AuthController.to;
    try {
      String userIdf = userId ?? authController.firestoreUser.value!.uid;
      List updatedPeopleWaiting = currentEvent.value!.peopleWaiting;
      if (updatedPeopleWaiting.remove(userIdf)) {
        EventModel newEvent = updateEventFieldsAsWanted(currentEvent.value!,
            peopleWaiting: updatedPeopleWaiting);
        await _updateEvent(newEvent, currentEvent.value!.uid);
      }
    } catch (e) {
      Get.log(e.toString(), isError: true);
    }
  }

  Stream<List<EventModel>> _streamUpcomingEvents() {
    Get.log("_streamUpcomingEvents");

    return _db
        .collection('/events')
        .where("heldDate", isGreaterThan: Timestamp.now())
        .snapshots()
        .map((snapshot) {
      List<EventModel> events = [];
      for (var doc in snapshot.docs) {
        events.add(EventModel.fromMap(doc.data()));
      }
      return events;
    });
  }

  Stream<List<EventModel>> _streamFeaturedEvents() {
    Get.log("_streamFeaturedEvents");

    return _db
        .collection('/events')
        .where('featured', isEqualTo: true)
        .snapshots()
        .map((snapshot) {
      List<EventModel> events = [];
      for (var doc in snapshot.docs) {
        events.add(EventModel.fromMap(doc.data()));
      }
      return events;
    });
  }

  Future setupDetailedEventPage(String eventId) async {
    Get.log("loadEventById");
    showLoadingIndicator();
    try {
      currentEvent.value = await _getEvent(eventId);
      fiveNextEvents.add(currentEvent.value!);

      isLive = currentEvent.value!.heldDate.microsecondsSinceEpoch <
              Timestamp.now().microsecondsSinceEpoch &&
          !currentEvent.value!.isEnded &&
          !currentEvent.value!.isCancelled;
      await fetchFirstEventsList();
      await _betsController.getBetWithRequirements();
      update();
    } catch (e) {
      Get.log(e.toString(), isError: true);
    }
    hideLoadingIndicator();
  }

  Future<EventModel?> _getEvent(String eventId) {
    Get.log("_getEvent");
    return _db.doc('/events/$eventId').get().then((documentSnapshot) =>
        documentSnapshot.data() == null
            ? null
            : EventModel.fromMap(documentSnapshot.data()!));
  }

  Future _updateEvent(EventModel event, String eventId) {
    Get.log("_updateEvent");
    return _db.doc('/events/$eventId').update(event.toJson());
  }

  EventModel updateEventFieldsAsWanted(
    EventModel prevEventModel, {
    String? uid,
    String? title,
    String? subtitle,
    String? image,
    String? category,
    Timestamp? heldDate,
    List? peopleBetting,
    List? peopleWaiting,
    bool? featured,
    bool? isEnded,
    bool? isCancelled,
  }) {
    return EventModel(
      uid: uid ?? prevEventModel.uid,
      title: title ?? prevEventModel.title,
      subtitle: subtitle ?? prevEventModel.subtitle,
      image: image ?? prevEventModel.image,
      category: category ?? prevEventModel.category,
      heldDate: heldDate ?? prevEventModel.heldDate,
      peopleBetting: peopleBetting ?? prevEventModel.peopleBetting,
      peopleWaiting: peopleWaiting ?? prevEventModel.peopleWaiting,
      featured: featured ?? prevEventModel.featured,
      isEnded: isEnded ?? prevEventModel.isEnded,
      isCancelled: isCancelled ?? prevEventModel.isCancelled,
    );
  }
}
