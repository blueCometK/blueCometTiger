import 'package:get/get.dart';

class LandingPageController extends GetxController {
  var tabIndex = 0.obs;
  static LandingPageController to = Get.find();
  Function onChange = () {
    Get.log("LandingPageController onChnaged");
  };

  Future changeTabIndex(int index) async {
    Get.log("changeTabIndex");
    if (Get.currentRoute != "/" ||
        Get.currentRoute != "/landing-page" ||
        Get.currentRoute != "/LandingPage") {
      Get.back();
    }
    tabIndex.value = index;
    onChange();
  }
}
