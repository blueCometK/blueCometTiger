import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flexx_bet/controllers/auth_controller.dart';
import 'package:flexx_bet/models/leaderboard_user_model.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';

class LeaderboardController extends GetxController {
  static LeaderboardController to = Get.find<LeaderboardController>();
  final FirebaseFirestore _db = FirebaseFirestore.instance;
  List<QueryDocumentSnapshot<Map<String, dynamic>>> documentList = [];
  int currentUserRank = 0;
  List<LeaderboardUserModel> fifteenNextLeaderBoardModels = [];
  Rxn<LeaderboardUserModel> fetchedLeaderboardUserModel =
      Rxn<LeaderboardUserModel>();
  String date = DateFormat('yyyy-MM-dd').format(DateTime.now().toLocal());

  Future enterOrUpdateLeaderboard(String userId) async {
    Get.log("enterOrUpdateLeaderboard");
    AuthController authController = AuthController.to;
    try {
      await loadLeaderboardUserModel(
          AuthController.to.firestoreUser.value!.uid);
      if (fetchedLeaderboardUserModel.value != null) {
        Get.log("fetchedLeaderboardUserModel not null");
        LeaderboardUserModel newModel = LeaderboardUserModel(
            userId: AuthController.to.firestoreUser.value!.uid,
            betsToday: fetchedLeaderboardUserModel.value!.betsToday + 1,
            nameOfUser: fetchedLeaderboardUserModel.value!.nameOfUser,
            userJoinedApp: fetchedLeaderboardUserModel.value!.userJoinedApp);
        await _updateNewLeaderboardUser(newModel);
      } else {
        Get.log("fetchedLeaderboardUserModel is null");
        LeaderboardUserModel newleaderboardUserModel = LeaderboardUserModel(
            userJoinedApp: authController.firestoreUser.value!.userJoinedAt,
            nameOfUser: authController.firestoreUser.value!.name,
            userId: authController.firestoreUser.value!.uid,
            betsToday: 1);
        await _createNewLeaderboardUser(newleaderboardUserModel);
      }
      Get.log("enterOrUpdateLeaderboard second step");
      await loadLeaderboardUserModel(userId);
      if (fetchedLeaderboardUserModel.value != null) {
        Get.log("fetchedLeaderboardUserModel not null");
        LeaderboardUserModel newModel = LeaderboardUserModel(
            userId: userId,
            betsToday: fetchedLeaderboardUserModel.value!.betsToday + 1,
            nameOfUser: fetchedLeaderboardUserModel.value!.nameOfUser,
            userJoinedApp: fetchedLeaderboardUserModel.value!.userJoinedApp);
        await _updateNewLeaderboardUser(newModel);
      } else {
        Get.log("fetchedLeaderboardUserModel is null");
        await authController.loadAnotherUserData(userId);
        final opponentUser = authController.otherUser!;
        LeaderboardUserModel leaderboardUserModel = LeaderboardUserModel(
            userId: userId,
            betsToday: 1,
            nameOfUser: opponentUser.name,
            userJoinedApp: opponentUser.userJoinedAt);

        await _createNewLeaderboardUser(leaderboardUserModel);
      }
      await fetchFirstLeaderboardList();
      update();
    } catch (e) {
      Get.log(e.toString(), isError: true);
    }
  }

  Future fetchFirstLeaderboardList() async {
    Get.log("fetchFirstLeaderboardList");
    AuthController authController = AuthController.to;
    try {
      List<LeaderboardUserModel> newLeaderboard = [];
      documentList = (await _db
              .collection('/leaderboard')
              .doc('/$date')
              .collection('/users')
              .orderBy('betsToday')
              .orderBy('userJoinedApp')
              .limit(15)
              .get())
          .docs;
      for (var value in documentList) {
        LeaderboardUserModel newLeaderBoardFromFirestore =
            LeaderboardUserModel.fromMap(value.data());
        newLeaderboard.add(newLeaderBoardFromFirestore);
        await authController
            .loadAnotherUserData(newLeaderBoardFromFirestore.userId);
        authController.usersPresent.add(authController.otherUser);
      }
      fifteenNextLeaderBoardModels = newLeaderboard;
      if (fifteenNextLeaderBoardModels.isNotEmpty) {
        currentUserRank = fifteenNextLeaderBoardModels.indexWhere((item) =>
                item.userId == AuthController.to.firestoreUser.value!.uid) +
            1;
      }
      update();
    } catch (e) {
      Get.log(e.toString(), isError: true);
    }
  }

  Future loadFifteenNextLeaderboardUsers({String? userId}) async {
    Get.log("loadFiveNextLeaderboardUsers");
    try {
      List<QueryDocumentSnapshot<Map<String, dynamic>>> newDocumentList =
          (await _db
                  .collection('/leaderboard')
                  .doc('/$date')
                  .collection('/users')
                  .orderBy('betsToday')
                  .orderBy('userJoinedApp', descending: true)
                  .startAfterDocument(documentList[documentList.length - 1])
                  .limit(15)
                  .get())
              .docs;
      for (var value in newDocumentList) {
        fifteenNextLeaderBoardModels
            .add(LeaderboardUserModel.fromMap(value.data()));
      }
      update();
    } catch (e) {
      Get.log(e.toString(), isError: true);
    }
  }

  Future<LeaderboardUserModel?> loadLeaderboardUserModel(String userId) async {
    Get.log("loadLeaderboardUserModel");
    return _db
        .collection('/leaderboard')
        .doc('/$date')
        .collection('/users')
        .doc(userId)
        .get()
        .then(
          (value) => value.data() == null
              ? null
              : fetchedLeaderboardUserModel.value =
                  LeaderboardUserModel.fromMap(value.data()!),
        );
  }

  Future _createNewLeaderboardUser(LeaderboardUserModel leaderboardUserModel) {
    Get.log("_createNewLeaderboardUser");
    return _db
        .collection('/leaderboard')
        .doc('/$date')
        .collection('/users')
        .doc(leaderboardUserModel.userId)
        .set(leaderboardUserModel.toJson());
  }

  Future _updateNewLeaderboardUser(LeaderboardUserModel leaderboardUserModel) {
    Get.log("_updateNewLeaderboardUser");
    return _db
        .collection('/leaderboard')
        .doc('/$date')
        .collection('/users')
        .doc(leaderboardUserModel.userId)
        .update(leaderboardUserModel.toJson());
  }
}
