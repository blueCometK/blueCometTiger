import 'package:flexx_bet/constants/images.dart';
import 'package:flexx_bet/ui/components/custom_appbar.dart';
import 'package:flutter/material.dart';

import 'widgets/bet_result_notification.dart';
import 'widgets/challenge_notification.dart';
import 'widgets/event_notification.dart';

class NotificationsScreen extends StatelessWidget {
  const NotificationsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppBar(),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Padding(
            padding: EdgeInsets.all(14.0),
            child: Text(
              "Notification",
              style: TextStyle(fontSize: 25, fontWeight: FontWeight.w500),
            ),
          ),
          ListView(
            shrinkWrap: true,
            children: const [
              BetResultNotification(),
              ChallengeNotification(),
              BetResultNotification(),
              EventNotification(
                heading: "Expresla is now live: Genshin Impact",
                image: ImageConstant.user3,
                sideImage: ImageConstant.genshinFake,
              ),
              BetResultNotification(),
              EventNotification(
                image: ImageConstant.accountNotificationImage,
                heading: "Account Setup Successful!",
              ),
            ],
          ),
        ],
      ),
    );
  }
}
