import 'package:carousel_slider/carousel_slider.dart';
import 'package:flexx_bet/constants/images.dart';
import 'package:flexx_bet/controllers/events_controller.dart';
import 'package:flexx_bet/models/event_model.dart';
import 'package:flexx_bet/ui/components/custom_appbar.dart';
import 'package:flexx_bet/ui/components/event_card.dart';
import 'package:flexx_bet/ui/components/event_list.dart';
import 'package:flexx_bet/ui/components/live_event_card.dart';
import 'package:flexx_bet/ui/components/scroll_parent.dart';
import 'package:flexx_bet/ui/events/all_featured_events.dart';
import 'package:flexx_bet/ui/events/all_live_events.dart';
import 'package:flexx_bet/ui/home/widgets/home_banner_slider.dart';
import 'package:flexx_bet/ui/home/widgets/single_banner.dart';
import 'package:flexx_bet/ui/home/widgets/single_category.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final EventsController _eventsController = EventsController.to;

  @override
  Widget build(BuildContext context) {
    final ScrollController scrollController = ScrollController();

    final List<CategoryWidget> categories = [
      const CategoryWidget(
          name: "Sports", imagePath: ImageConstant.categorySportsImage),
      const CategoryWidget(
          name: "Music", imagePath: ImageConstant.categoryMusicImage),
      const CategoryWidget(
          name: "Crypto", imagePath: ImageConstant.categoryCryptoImage),
      const CategoryWidget(
          name: "Other", imagePath: ImageConstant.categoryOtherImage),
    ];
    final List<SingleBanner> banners = [
      const SingleBanner(
          imagePath: ImageConstant.homeSlideBanner1,
          subTitle: "Becoming Street Smarter",
          title: "Becoming Street")
    ];

    return Scaffold(
      appBar: CustomAppBar(),
      body: SingleChildScrollView(
        controller: scrollController,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(
              height: 2,
            ),
            HomeBannerSlider(
              banners: banners,
            ),
            const SizedBox(
              height: 10,
            ),
            SizedBox(
              height: Get.height / 8,
              child: ListView(
                scrollDirection: Axis.horizontal,
                children: categories,
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(12.0, 8, 12, 12),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    "Live events 🔥",
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                  GestureDetector(
                    onTap: () {
                      Get.log("To AllLiveEventsScreen");
                      Get.to(() => const AllLiveEventsScreen());
                    },
                    child: const Text(
                      "Show all",
                    ),
                  ),
                ],
              ),
            ),
            CarouselSlider.builder(
              itemCount: _eventsController.liveEvents.value?.length ?? 0,
              itemBuilder: (context, index, realIndex) {
                if (_eventsController.liveEvents.value != null) {
                  EventModel e = _eventsController.liveEvents.value![index];
                  return LiveEventCard(
                    eventId: e.uid,
                    subtitle: e.subtitle,
                    title: e.title,
                    categoryName: e.category,
                    eventHeldDate: e.heldDate.toDate(),
                    categoryImage: ImageConstant.categorySportsImage,
                    imagePath: e.image,
                    peopleWaiting: e.peopleWaiting.length,
                  );
                } else {
                  return SizedBox();
                }
              },
              options: CarouselOptions(
                enableInfiniteScroll: false,
                viewportFraction: .7,
                disableCenter: true,
                autoPlay: true,
                padEnds: false,
                height: Get.height / 2.8,
              ),
            ),
            ScrollParent(
              controller: scrollController,
              child: EventList(
                events: _eventsController.featuredEvents.value?.map((e) {
                  return EventCard(
                    eventId: e.uid,
                    subtitle: e.subtitle,
                    categoryImage: ImageConstant.categorySportsImage,
                    eventHeldDate: e.heldDate.toDate(),
                    category: e.category,
                    imagePath: e.image,
                    title: e.title,
                  );
                }).toList(),
                heading: "Featured Events",
                fullHeight: false,
                trailing: GestureDetector(
                  child: const Text("see all"),
                  onTap: () {
                    Get.log("To AllFeaturedEventsScreen");
                    Get.to(() => const AllFeaturedEventsScreen());
                  },
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}
