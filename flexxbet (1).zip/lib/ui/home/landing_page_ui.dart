import 'package:flexx_bet/constants/images.dart';
import 'package:flexx_bet/controllers/landing_page_controller.dart';
import 'package:flexx_bet/ui/banter/banter.dart';
import 'package:flexx_bet/ui/components/navigation_bar.dart';
import 'package:flexx_bet/ui/events/main_event_screen.dart';
import 'package:flexx_bet/ui/home/home_ui.dart';
import 'package:flexx_bet/ui/home/widgets/draggable_floating_action_button.dart';
import 'package:flexx_bet/ui/leaderboard/leaderboard.dart';
import 'package:flexx_bet/ui/maps/maps.dart';
import 'package:flexx_bet/ui/profile/profile_ui.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class LandingPage extends StatelessWidget {
  LandingPage({super.key});

  final GlobalKey stackKey = GlobalKey();

  @override
  Widget build(BuildContext context) {
    final LandingPageController landingPageController =
        Get.put(LandingPageController(), permanent: false);
    return SafeArea(
        child: Scaffold(
      bottomNavigationBar: buildBottomNavigationMenu(context),
      body: Column(
        children: [
          SizedBox(
            height: Get.height / 1.136,
            width: Get.width,
            child: Stack(
              key: stackKey,
              children: [
                Obx(() => IndexedStack(
                      index: landingPageController.tabIndex.value,
                      children: [
                        const HomeScreen(),
                        EventScreen(),
                        const BanterScreen(),
                        const LeaderBoardScreen(),
                        ProfileScreen()
                      ],
                    )),
                DraggableFloatingActionButton(
                  initialOffset: const Offset(300, 420),
                  parentKey: stackKey,
                  onPressed: () {
                    Get.to(() => MapsScreen());
                  },
                  child: Container(
                    width: 70,
                    height: 70,
                    decoration: const ShapeDecoration(
                      shape: CircleBorder(),
                      color: Color.fromARGB(150, 183, 149, 255),
                    ),
                    child: Image.asset(ImageConstant.mapsIcon),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    ));
  }
}
