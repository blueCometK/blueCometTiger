import 'package:flexx_bet/constants/colors.dart';
import 'package:flexx_bet/constants/images.dart';
import 'package:flexx_bet/controllers/auth_controller.dart';
import 'package:flexx_bet/helpers/size.dart';
import 'package:flexx_bet/ui/auth/auth.dart';
import 'package:flexx_bet/ui/components/custom_button.dart';
import 'package:flexx_bet/ui/components/custom_image_view.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'widgets/login_card.dart';

class SignupSignInChoiceScreen extends StatelessWidget {
  const SignupSignInChoiceScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          leading: const BackButton(color: Colors.black),
          backgroundColor: ColorConstant.whiteA700,
        ),
        backgroundColor: ColorConstant.whiteA700,
        body: Padding(
          padding: EdgeInsets.fromLTRB(
              getHorizontalSize(15), 10, getHorizontalSize(15), 0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Row(
                children: [
                  const Text(
                    "Hi there!",
                    style: TextStyle(
                        fontSize: HEADING_SIZE, fontWeight: FontWeight.w600),
                  ),
                  CustomImageView(
                    imagePath: ImageConstant.hiEmoji,
                    height: Get.height / 14,
                  )
                ],
              ),
              const SizedBox(
                height: 20,
              ),
              LoginCard(
                  text: "Continue with Facebook",
                  color: ColorConstant.blue100,
                  imagePath: ImageConstant.facebook),
              const SizedBox(
                height: 20,
              ),
              GestureDetector(
                onTap: () async {
                  await AuthController.to.registerAndSignInUserWithGoogle();
                },
                child: LoginCard(
                    text: "Continue with Google",
                    color: ColorConstant.yellow200,
                    imagePath: ImageConstant.google),
              ),
              const SizedBox(
                height: 20,
              ),
              const LoginCard(
                  text: "Continue with Phone",
                  color: Color.fromARGB(215, 175, 255, 189),
                  imagePath: ImageConstant.apple),
              const SizedBox(
                height: 75,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    height: 1,
                    width: getHorizontalSize(150),
                    color: ColorConstant.gray400,
                  ),
                  const Text("  or  "),
                  Container(
                    height: 1,
                    width: getHorizontalSize(150),
                    color: ColorConstant.gray400,
                  ),
                ],
              ),
              const SizedBox(
                height: 35,
              ),
              CustomButton(
                height: getVerticalSize(60),
                fontStyle: ButtonFontStyle.PoppinsMedium16,
                onTap: () {
                  Get.to(() => const SignInScreen());
                },
                text: "Sign In With Password".toUpperCase(),
              ),
              SizedBox(
                height: getVerticalSize(10),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Text("Don't Have a account? "),
                  GestureDetector(
                    onTap: () {
                      Get.to(() => const SignUpScreen());
                    },
                    child: Text(
                      "Sign Up",
                      style: TextStyle(color: ColorConstant.blue400),
                    ),
                  ),
                ],
              ),
              SizedBox(
                height: getVerticalSize(30),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
