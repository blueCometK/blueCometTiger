import 'package:flexx_bet/constants/colors.dart';
import 'package:flexx_bet/constants/images.dart';
import 'package:flexx_bet/ui/events/widgets/single_category_rounded.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';

class BottomFilterSheet extends StatefulWidget {
  const BottomFilterSheet({super.key});

  @override
  State<BottomFilterSheet> createState() => _BottomFilterSheetState();
}

class _BottomFilterSheetState extends State<BottomFilterSheet> {
  int amount = 100;
  final TextEditingController _amountController = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: SizedBox(
        height: Get.height / 1.1,
        child: Material(
          color: Colors.transparent,
          child: Container(
            height: 900,
            decoration: BoxDecoration(
                gradient: SweepGradient(
              colors: [Colors.grey[300]!, ColorConstant.primaryColor],
              stops: const [0, 1],
              center: Alignment.topLeft,
            )),
            child: Column(children: [
              const SizedBox(
                height: 40,
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: SearchBar(
                  leading: Image.asset(
                    ImageConstant.searchIcon,
                    height: 20,
                  ),
                  hintText: "Filter Searches",
                  hintStyle: const MaterialStatePropertyAll(TextStyle(
                      color: Colors.grey, fontWeight: FontWeight.normal)),
                  elevation: const MaterialStatePropertyAll(.1),
                  backgroundColor: MaterialStateProperty.resolveWith((states) {
                    // If the button is pressed, return green, otherwise blue
                    if (states.contains(MaterialState.focused)) {
                      return Colors.white;
                    }
                    return Colors.grey[50];
                  }),
                ),
              ),
              const SizedBox(
                height: 25,
              ),
              const Padding(
                padding: EdgeInsets.all(16.0),
                child: Row(
                  children: [
                    Text("Search By Category", style: TextStyle(fontSize: 15)),
                  ],
                ),
              ),
              SizedBox(
                height: Get.height / 7,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  children: const [
                    CategoryRoundedWidget(
                        name: "Sports",
                        imagePath: ImageConstant.categorySportsImage),
                    CategoryRoundedWidget(
                        name: "Music",
                        active: true,
                        imagePath: ImageConstant.categoryMusicImage),
                    CategoryRoundedWidget(
                        name: "Crypto",
                        imagePath: ImageConstant.categoryCryptoImage),
                    CategoryRoundedWidget(
                        name: "Other",
                        imagePath: ImageConstant.categoryOtherImage),
                  ],
                ),
              ),
              const SizedBox(
                height: 15,
              ),
              const Padding(
                padding: EdgeInsets.all(16.0),
                child: Row(
                  children: [
                    Text("Search By Amount", style: TextStyle(fontSize: 15)),
                  ],
                ),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  amountButton(amountValue: 100),
                  amountButton(amountValue: 500),
                  amountButton(amountValue: 1000),
                  amountButton(amountValue: 5000),
                ],
              ),
              const SizedBox(
                height: 30,
              ),
              const Text("Enter amount"),
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: IconButton(
                        onPressed: () {
                          setState(() {
                            if (amount > 10) amount = amount - 10;
                            _amountController.text = "$amount";
                          });
                        },
                        icon: Container(
                          decoration: BoxDecoration(
                              color: Colors.grey,
                              borderRadius: BorderRadius.circular(70)),
                          child: const Center(
                              child: Text(
                            "-",
                            style: TextStyle(color: Colors.white, fontSize: 20),
                          )),
                        )),
                  ),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        "₦",
                        style: TextStyle(
                            color: Colors.grey,
                            fontFamily: "Inter",
                            fontSize: 20),
                      ),
                      SizedBox(
                        width: Get.width / 3,
                        child: TextField(
                          controller: _amountController,
                          decoration: InputDecoration.collapsed(
                            hintText: "$amount",
                          ),
                          textInputAction: TextInputAction.done,
                          keyboardType: TextInputType.number,
                          inputFormatters: [
                            FilteringTextInputFormatter.digitsOnly
                          ],
                          onChanged: (val) {
                            amount = int.parse(val);
                          },
                          style: TextStyle(
                              color: Colors.grey[800],
                              fontFamily: "Inter",
                              fontSize: 50),
                        ),
                      ),
                    ],
                  ),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: IconButton(
                        onPressed: () {
                          setState(() {
                            amount = amount + 10;
                            _amountController.text = "$amount";
                          });
                        },
                        icon: Container(
                          decoration: BoxDecoration(
                              color: Colors.grey,
                              borderRadius: BorderRadius.circular(70)),
                          child: const Center(
                              child: Text(
                            "+",
                            style: TextStyle(color: Colors.white, fontSize: 20),
                          )),
                        )),
                  )
                ],
              ),
              const SizedBox(
                height: 25,
              ),
              TextButton(
                  onPressed: () {
                    Get.log("filter sheet");
                    Get.back();
                  },
                  child: Container(
                    width: Get.width / 1.2,
                    height: 50,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(30),
                        color: ColorConstant.primaryColor),
                    child: const Center(
                      child: Text(
                        "Apply",
                        style: TextStyle(color: Colors.white, fontSize: 20),
                      ),
                    ),
                  ))
            ]),
          ),
        ),
      ),
    );
  }

  Widget amountButton({required int amountValue}) {
    return GestureDetector(
      onTap: () {
        setState(() {
          amount = amountValue;
          _amountController.text = "$amount";
        });
      },
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
            color: Colors.transparent,
            border: Border.all(color: Colors.grey[800]!)),
        child: Text(
          "₦ $amountValue",
          style: TextStyle(
              color: Colors.grey[800], fontFamily: "Inter", fontSize: 16),
        ),
      ),
    );
  }
}
