import 'package:appinio_swiper/appinio_swiper.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flexx_bet/controllers/auth_controller.dart';
import 'package:flexx_bet/controllers/bet_controller.dart';
import 'package:flexx_bet/controllers/events_controller.dart';
import 'package:flexx_bet/models/event_model.dart';
import 'package:flexx_bet/ui/components/loader.dart';
import 'package:flexx_bet/ui/components/navigation_bar.dart';
import 'package:flexx_bet/constants/colors.dart';
import 'package:flexx_bet/constants/images.dart';
import 'package:flexx_bet/ui/components/custom_appbar.dart';
import 'package:flexx_bet/ui/components/user_info_card.dart';
import 'package:flexx_bet/ui/events/widgets/bet_confirmation.dart';
import 'package:flexx_bet/ui/events/widgets/filter_bottom_sheet.dart';
import 'package:flexx_bet/ui/events/widgets/people_betting_widget.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'widgets/bet_confirmation_success.dart';
import 'widgets/event_status_indicator.dart';

class DetailedEventScreen extends StatefulWidget {
  const DetailedEventScreen({super.key});

  @override
  State<DetailedEventScreen> createState() => _DetailedEventScreenState();
}

class _DetailedEventScreenState extends State<DetailedEventScreen> {
  final EventsController _eventController = EventsController.to;
  final BetsController _betsController = BetsController.to;
  final AppinioSwiperController _swiperController = AppinioSwiperController();

  @override
  void dispose() {
    _eventController.fiveNextEvents = [];
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    EventModel eventModel = _eventController.currentEvent.value!;

    final String formattedtime =
        DateFormat("hh:mm:ss a").format(eventModel.heldDate.toDate());

    return Scaffold(
      bottomNavigationBar: buildBottomNavigationMenu(
        context,
      ),
      appBar: CustomAppBar(),
      body: SingleChildScrollView(
        child: SizedBox(
          height: Get.height / 1.2,
          child: Column(
            children: [
              SizedBox(
                height: Get.height * 0.7,
                child: AppinioSwiper(
                  cardsCount: _eventController.fiveNextEvents.length,
                  backgroundCardsCount: 1,
                  controller: _swiperController,
                  loop: true,
                  swipeOptions:
                      const AppinioSwipeOptions.only(left: true, right: true),
                  onSwipe: (index, direction) async {
                    Get.log("Swiped event");

                    Get.log(EventsController.to.currentEvent.value!.uid,
                        isError: true);
                    if (direction == AppinioSwiperDirection.left) {
                      if (_betsController.currentBet.value != null) {
                        await showLoader(() async {
                          await _betsController.joinBet();
                        });
                        betConfirmationSuccess(true);
                      } else if (_betsController.isNewBetPossible &&
                          _eventController.isLive!) {
                        await Get.dialog(BetConfirmation(
                            eventName:
                                _eventController.currentEvent.value!.title));
                      } else if (!_eventController.isLive!) {
                        Get.snackbar("Bet is not possible",
                            "The Event you are trying to join is not yet started or is ended",
                            snackPosition: SnackPosition.BOTTOM,
                            margin: const EdgeInsets.only(bottom: 40),
                            duration: const Duration(seconds: 3),
                            colorText: Colors.black);
                      } else if (!_betsController.isNewBetPossible) {
                        Get.snackbar("Bet is not possible",
                            "You have already ongoing bet in this event or system is currently searching for your opponent",
                            snackPosition: SnackPosition.BOTTOM,
                            margin: const EdgeInsets.only(bottom: 40),
                            duration: const Duration(seconds: 3),
                            colorText: Colors.black);
                      }
                    }
                    if (index == 0) {
                      await showLoader(() async =>
                          await _eventController.loadFiveNextEvents());
                    }

                    _eventController.currentEvent.value =
                        _eventController.fiveNextEvents[index];
                    await showLoader(() async =>
                        await _betsController.getBetWithRequirements());
                    setState(() {
                      _eventController.isLive = _eventController.currentEvent
                                  .value!.heldDate.microsecondsSinceEpoch <
                              Timestamp.now().microsecondsSinceEpoch &&
                          !_eventController.currentEvent.value!.isEnded &&
                          !_eventController.currentEvent.value!.isCancelled;
                    });
                  },
                  threshold: 100,
                  cardsBuilder: (BuildContext context, int index) {
                    bool isLive = _eventController.fiveNextEvents[index]
                                .heldDate.microsecondsSinceEpoch <
                            Timestamp.now().microsecondsSinceEpoch &&
                        !_eventController.fiveNextEvents[index].isEnded &&
                        !_eventController.fiveNextEvents[index].isCancelled;

                    return CachedNetworkImage(
                      imageUrl: _eventController.fiveNextEvents[index].image,
                      imageBuilder: (context, imageProvider) => Container(
                          padding: const EdgeInsets.only(top: 15),
                          decoration: BoxDecoration(
                              color: Colors.black,
                              borderRadius: BorderRadius.circular(20),
                              image: DecorationImage(
                                  image: imageProvider,
                                  fit: BoxFit.cover,
                                  opacity: 0.5)),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  TextButton(
                                      onPressed: () {},
                                      child: Container(
                                        decoration: BoxDecoration(boxShadow: [
                                          BoxShadow(
                                            color:
                                                Colors.black.withOpacity(0.54),
                                            offset: const Offset(-2, 4),
                                            blurRadius: 12,
                                            spreadRadius: -3,
                                          )
                                        ]),
                                        child: Image.asset(
                                          ImageConstant.followMeIcon,
                                          height: 30,
                                          width: 30,
                                        ),
                                      )),
                                  Column(
                                    mainAxisAlignment: MainAxisAlignment.end,
                                    children: [
                                      const SizedBox(
                                        height: 10,
                                      ),
                                      GestureDetector(
                                        onTap: () async {
                                          if (_betsController
                                                  .currentBet.value !=
                                              null) {
                                            await AuthController.to
                                                .loadAnotherUserData(
                                                    _betsController.currentBet
                                                        .value!.firstUser);
                                            Get.dialog(UserInfoCard());
                                          }
                                        },
                                        child: Container(
                                          padding: const EdgeInsets.symmetric(
                                              vertical: 6, horizontal: 10),
                                          decoration: BoxDecoration(
                                            boxShadow: [
                                              BoxShadow(
                                                color: Colors.black
                                                    .withOpacity(0.54),
                                                offset: const Offset(-2, 4),
                                                blurRadius: 12,
                                                spreadRadius: -3,
                                              )
                                            ],
                                            color: ColorConstant.primaryColor,
                                            borderRadius:
                                                BorderRadius.circular(20),
                                          ),
                                          child: Text(
                                            _betsController.currentBet.value !=
                                                    null
                                                ? "@${_betsController.currentBet.value!.firstUsername}"
                                                : 'Waiting for players to join...',
                                            style: const TextStyle(
                                                color: Colors.white),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                  TextButton(
                                      onPressed: () {
                                        Get.bottomSheet(
                                            const BottomFilterSheet(),
                                            isScrollControlled: true,
                                            persistent: true);
                                      },
                                      child: Container(
                                        decoration: BoxDecoration(
                                          boxShadow: [
                                            BoxShadow(
                                              color: Colors.black
                                                  .withOpacity(0.54),
                                              offset: const Offset(-2, 4),
                                              blurRadius: 12,
                                              spreadRadius: -3,
                                            )
                                          ],
                                        ),
                                        child: Image.asset(
                                          ImageConstant.filterButton,
                                          height: 30,
                                          width: 30,
                                        ),
                                      )),
                                ],
                              ),
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  TextButton(
                                      onPressed: () {
                                        _swiperController.swipeRight();
                                      },
                                      child: Container(
                                        padding: const EdgeInsets.all(16),
                                        decoration: BoxDecoration(
                                            borderRadius:
                                                BorderRadius.circular(100),
                                            color: ColorConstant.primaryColor
                                                .withOpacity(0.8)),
                                        child: Image.asset(
                                          ImageConstant.cross,
                                          height: 30,
                                          width: 30,
                                        ),
                                      )),
                                  TextButton(
                                      onPressed: () {
                                        _swiperController.swipeLeft();
                                      },
                                      child: Container(
                                        padding: const EdgeInsets.all(16),
                                        decoration: BoxDecoration(
                                            borderRadius:
                                                BorderRadius.circular(100),
                                            color: ColorConstant.primaryColor
                                                .withOpacity(0.8)),
                                        child: Image.asset(
                                          ImageConstant.checkMark,
                                          height: 30,
                                          width: 30,
                                        ),
                                      )),
                                ],
                              ),
                              Column(
                                children: [
                                  Padding(
                                    padding: const EdgeInsets.all(8.0),
                                    child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        EventStatusIndictor(
                                          isCancelled: _eventController
                                              .fiveNextEvents[index]
                                              .isCancelled,
                                          isEnded: _eventController
                                              .fiveNextEvents[index].isEnded,
                                          isLive: isLive,
                                        ),
                                        const SizedBox(
                                          width: 20,
                                        ),
                                        Row(
                                          children: [
                                            Image.asset(
                                              ImageConstant.watched,
                                              color: Colors.white,
                                              height: 25,
                                              width: 25,
                                            ),
                                            Text(
                                              "${_eventController.fiveNextEvents[index].peopleWaiting.length}",
                                              style: const TextStyle(
                                                  color: Colors.white,
                                                  fontSize: 15),
                                            )
                                          ],
                                        )
                                      ],
                                    ),
                                  ),
                                  Container(
                                    decoration: BoxDecoration(
                                      gradient: LinearGradient(
                                        colors: [
                                          const Color(0xff000000)
                                              .withOpacity(0.9),
                                          const Color.fromARGB(255, 70, 70, 70)
                                              .withOpacity(0.9),
                                          const Color(0xff000000)
                                              .withOpacity(0.9),
                                          const Color.fromARGB(255, 43, 43, 43)
                                              .withOpacity(0.9),
                                          const Color(0xff000000)
                                              .withOpacity(0.9),
                                        ],
                                        stops: const [0, 0.25, 0.5, 0.75, 1],
                                      ),
                                      borderRadius: const BorderRadius.only(
                                          bottomLeft: Radius.circular(20),
                                          bottomRight: Radius.circular(20)),
                                    ),
                                    child: Column(
                                      children: [
                                        const SizedBox(
                                          height: 10,
                                        ),
                                        Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.center,
                                          children: [
                                            SizedBox(
                                              width: Get.width / 1.2,
                                              child: Text(
                                                _eventController
                                                    .fiveNextEvents[index]
                                                    .title,
                                                textAlign: TextAlign.center,
                                                maxLines: 2,
                                                style: const TextStyle(
                                                    color: Colors.white,
                                                    fontSize: 25,
                                                    fontWeight:
                                                        FontWeight.w600),
                                              ),
                                            ),
                                          ],
                                        ),
                                        const SizedBox(
                                          height: 10,
                                        ),
                                        Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.center,
                                          children: [
                                            Container(
                                              padding:
                                                  const EdgeInsets.symmetric(
                                                      vertical: 6,
                                                      horizontal: 10),
                                              decoration: BoxDecoration(
                                                color:
                                                    ColorConstant.primaryColor,
                                                borderRadius:
                                                    BorderRadius.circular(20),
                                              ),
                                              child: Text(
                                                "₦ ${_betsController.userSelectedAmount.value!}",
                                                textAlign: TextAlign.center,
                                                maxLines: 2,
                                                style: const TextStyle(
                                                    color: Colors.white,
                                                    fontFamily: "Inter",
                                                    fontWeight:
                                                        FontWeight.bold),
                                              ),
                                            ),
                                          ],
                                        ),
                                        const SizedBox(
                                          height: 15,
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              )
                            ],
                          )),
                    );
                  },
                ),
              ),
              Expanded(
                flex: 7,
                child: Column(
                  children: [
                    Expanded(
                        flex: 2,
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 18, vertical: 10),
                          color: Colors.white,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                                  ShowPeopleBetting(),
                                ],
                              ),
                              Column(
                                children: [
                                  Row(
                                    children: [
                                      Container(
                                        padding: const EdgeInsets.all(2),
                                        child: Transform.flip(
                                            flipX: true,
                                            child: const Icon(Icons.update)),
                                      ),
                                      Text(
                                        _eventController.isLive!
                                            ? "Event started at: "
                                            : eventModel.isCancelled
                                                ? "Cancelled"
                                                : eventModel.isEnded
                                                    ? "Ended"
                                                    : "Event starts in: ",
                                        style:
                                            const TextStyle(color: Colors.grey),
                                      ),
                                    ],
                                  ),
                                  const SizedBox(
                                    width: 10,
                                  ),
                                  eventModel.isCancelled || eventModel.isEnded
                                      ? const SizedBox()
                                      : Text(formattedtime),
                                ],
                              ),
                            ],
                          ),
                        )),
                  ],
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
