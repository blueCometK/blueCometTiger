import 'package:flutter/material.dart';

class LoadingSplashUI extends StatelessWidget {
  const LoadingSplashUI({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        child: const Center(
          child: CircularProgressIndicator(),
        ),
      ),
    );
  }
}
