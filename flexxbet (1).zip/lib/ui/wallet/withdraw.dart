import 'package:flexx_bet/constants/colors.dart';
import 'package:flexx_bet/controllers/selection_controller.dart';
import 'package:flexx_bet/ui/wallet/withdraw_to.dart';
import 'package:flexx_bet/ui/components/custom_button.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';

class WithdrawScreen extends StatelessWidget {
  WithdrawScreen({super.key});
  final TextEditingController controller = TextEditingController();
  @override
  Widget build(BuildContext context) {
    double width = 3 * Get.width / 12;
    return Scaffold(
      appBar: AppBar(
        systemOverlayStyle:
            const SystemUiOverlayStyle(statusBarColor: Colors.white),
        title: const Text(
          "Withdraw",
          style: TextStyle(color: Colors.black),
        ),
        centerTitle: true,
        leading: const BackButton(
          color: Colors.black,
        ),
        backgroundColor: Colors.white,
      ),
      body: Column(
        children: [
          const SizedBox(
            height: 35,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                "₦",
                style: TextStyle(
                    fontFamily: 'Inter',
                    color: Colors.grey,
                    fontSize: Get.width / 10),
              ),
              StatefulBuilder(
                builder: (context, setState) {
                  return SizedBox(
                    width: width,
                    child: TextFormField(
                      controller: controller,
                      onChanged: (value) {
                        setState(
                          () {
                            width = value.isNotEmpty
                                ? value.length * (Get.width / 12) >
                                        Get.width / 1.3
                                    ? Get.width / 1.3
                                    : value.length * (Get.width / 12)
                                : Get.width / 12;
                          },
                        );
                      },
                      style: TextStyle(
                          fontSize: Get.width / 8.5,
                          color: Colors.black,
                          fontWeight: FontWeight.bold),
                      keyboardType: TextInputType.number,
                      inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                      decoration: InputDecoration(
                          hintStyle: TextStyle(color: Colors.grey[400]),
                          hintText: "500",
                          border: InputBorder.none),
                    ),
                  );
                },
              ),
            ],
          ),
          const Text(
            "Current Balance is ₦5,323.00",
            style: TextStyle(fontFamily: 'Inter'),
          ),
          const SizedBox(
            height: 20,
          ),
          GetBuilder(
            init: SelectionController<String>("25%"),
            builder: (controller) {
              return Padding(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    GestureDetector(
                      onTap: () {
                        controller.setSelection("25%");
                      },
                      child: Container(
                        margin: const EdgeInsets.all(4),
                        padding: const EdgeInsets.fromLTRB(24, 12, 24, 12),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(15),
                          color: controller.selection == "25%"
                              ? ColorConstant.teal400
                              : Colors.white,
                        ),
                        child: Text(
                          "25%",
                          style: TextStyle(
                              color: controller.selection == "25%"
                                  ? Colors.white
                                  : ColorConstant.primaryColor),
                        ),
                      ),
                    ),
                    GestureDetector(
                      onTap: () {
                        controller.setSelection("50%");
                      },
                      child: Container(
                        margin: const EdgeInsets.all(4),
                        padding: const EdgeInsets.fromLTRB(24, 12, 24, 12),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(15),
                          color: controller.selection == "50%"
                              ? ColorConstant.teal400
                              : Colors.white,
                        ),
                        child: Text(
                          "50%",
                          style: TextStyle(
                              color: controller.selection == "50%"
                                  ? Colors.white
                                  : ColorConstant.primaryColor),
                        ),
                      ),
                    ),
                    GestureDetector(
                      onTap: () {
                        controller.setSelection("75%");
                      },
                      child: Container(
                        margin: const EdgeInsets.all(4),
                        padding: const EdgeInsets.fromLTRB(24, 12, 24, 12),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(15),
                          color: controller.selection == "75%"
                              ? ColorConstant.teal400
                              : Colors.white,
                        ),
                        child: Text(
                          "75%",
                          style: TextStyle(
                              color: controller.selection == "75%"
                                  ? Colors.white
                                  : ColorConstant.primaryColor),
                        ),
                      ),
                    ),
                    GestureDetector(
                      onTap: () {
                        controller.setSelection("100%");
                      },
                      child: Container(
                        margin: const EdgeInsets.all(4),
                        padding: const EdgeInsets.fromLTRB(24, 12, 24, 12),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(15),
                          color: controller.selection == "100%"
                              ? ColorConstant.teal400
                              : Colors.white,
                        ),
                        child: Text(
                          "100%",
                          style: TextStyle(
                              color: controller.selection == "100%"
                                  ? Colors.white
                                  : ColorConstant.primaryColor),
                        ),
                      ),
                    ),
                  ],
                ),
              );
            },
          ),
          const SizedBox(
            height: 40,
          ),
          CustomButton(
            width: Get.width / 1.3,
            text: "Withdraw",
            fontStyle: ButtonFontStyle.PoppinsMedium16,
            padding: ButtonPadding.PaddingAll4,
            onTap: () {
              Get.to(() => WithdrawToScreen());
            },
          )
        ],
      ),
    );
  }
}
