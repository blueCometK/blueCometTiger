import 'package:flexx_bet/constants/colors.dart';
import 'package:flexx_bet/constants/images.dart';
import 'package:flexx_bet/ui/wallet/widget/confirm_transfer.dart';
import 'package:flexx_bet/ui/components/custom_button.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'dart:math' as math;
import 'package:get/get.dart';

class TransferUserSelectionScreen extends StatelessWidget {
  TransferUserSelectionScreen({super.key});
  final TextEditingController controller = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        systemOverlayStyle:
            const SystemUiOverlayStyle(statusBarColor: Colors.white),
        title: const Text(
          "Transfer",
          style: TextStyle(color: Colors.black),
        ),
        centerTitle: true,
        leading: const BackButton(
          color: Colors.black,
        ),
        backgroundColor: Colors.white,
      ),
      body: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Container(
          decoration: BoxDecoration(
              color: Colors.grey[100], borderRadius: BorderRadius.circular(15)),
          height: 130,
          margin: const EdgeInsets.all(8),
          padding: const EdgeInsets.all(16),
          width: Get.width,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const CircleAvatar(
                radius: 40,
                backgroundImage: AssetImage(ImageConstant.user2),
              ),
              const Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text("@betmaster554"),
                  Text(
                    "*** *** 6155",
                    style: TextStyle(color: Colors.grey, fontSize: 18),
                  )
                ],
              ),
              Padding(
                padding: const EdgeInsets.only(bottom: 35.0, left: 8),
                child: Transform.rotate(
                    angle: 270 * math.pi / 180,
                    child: const Icon(
                      Icons.arrow_back_ios,
                      size: 12,
                      color: Colors.black,
                    )),
              ),
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(18.0, 18, 0, 0),
          child: Text(
            "Choose Recipent",
            style: TextStyle(color: ColorConstant.primaryColor, fontSize: 15),
          ),
        ),
        Container(
          margin: const EdgeInsets.all(18),
          padding: const EdgeInsets.all(6),
          width: Get.width / 1.4,
          decoration: BoxDecoration(
              color: Colors.white, borderRadius: BorderRadius.circular(14)),
          child: TextFormField(
            cursorColor: ColorConstant.primaryColor,
            decoration: InputDecoration(
                border: InputBorder.none,
                hintText: "Search Contacts",
                prefixIconColor: ColorConstant.primaryColor,
                prefixIcon: const Icon(Icons.search)),
          ),
        ),
        SizedBox(
          height: 140,
          child: ListView(
            shrinkWrap: true,
            scrollDirection: Axis.horizontal,
            children: [
              Container(
                width: Get.width / 3.2,
                margin: const EdgeInsets.symmetric(horizontal: 8),
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(15)),
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const CircleAvatar(
                        backgroundImage: AssetImage(ImageConstant.user3),
                        radius: 25,
                      ),
                      Text(
                        "@JonWick94",
                        style: TextStyle(
                            color: ColorConstant.primaryColor, fontSize: 10),
                      )
                    ]),
              ),
              Container(
                width: Get.width / 3.2,
                margin: const EdgeInsets.symmetric(horizontal: 8),
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(15)),
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const CircleAvatar(
                        backgroundImage: AssetImage(ImageConstant.user4),
                        radius: 25,
                      ),
                      Text(
                        "@kaynone654",
                        style: TextStyle(
                            color: ColorConstant.primaryColor, fontSize: 10),
                      )
                    ]),
              ),
              Container(
                width: Get.width / 3.2,
                margin: const EdgeInsets.symmetric(horizontal: 8),
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(15)),
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const CircleAvatar(
                        backgroundImage: AssetImage(ImageConstant.user1),
                        radius: 25,
                      ),
                      Text(
                        "@jane65rt",
                        style: TextStyle(
                            color: ColorConstant.primaryColor, fontSize: 10),
                      )
                    ]),
              )
            ],
          ),
        ),
        const SizedBox(
          height: 70,
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CustomButton(
              width: Get.width / 1.2,
              text: "Continue",
              fontStyle: ButtonFontStyle.PoppinsMedium16,
              padding: ButtonPadding.PaddingAll4,
              height: 50,
              onTap: () {
                confirmTransfer();
              },
            ),
          ],
        ),
      ]),
    );
  }
}
