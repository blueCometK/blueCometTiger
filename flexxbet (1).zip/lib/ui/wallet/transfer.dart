import 'package:flexx_bet/constants/colors.dart';
import 'package:flexx_bet/constants/images.dart';
import 'package:flexx_bet/ui/wallet/transfer_user_selection.dart';
import 'package:flexx_bet/ui/components/custom_button.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'dart:math' as math;

class TransferScreen extends StatelessWidget {
  TransferScreen({super.key});
  final TextEditingController controller = TextEditingController();

  @override
  Widget build(BuildContext context) {
    double width = 3 * Get.width / 12;
    return Scaffold(
      appBar: AppBar(
        systemOverlayStyle:
            const SystemUiOverlayStyle(statusBarColor: Colors.white),
        title: const Text(
          "Transfer",
          style: TextStyle(color: Colors.black),
        ),
        centerTitle: true,
        leading: const BackButton(
          color: Colors.black,
        ),
        backgroundColor: Colors.white,
      ),
      body: Column(children: [
        Container(
          decoration: BoxDecoration(
              color: Colors.grey[100], borderRadius: BorderRadius.circular(15)),
          height: 130,
          margin: const EdgeInsets.all(8),
          padding: const EdgeInsets.all(16),
          width: Get.width,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const CircleAvatar(
                radius: 40,
                backgroundImage: AssetImage(ImageConstant.user2),
              ),
              const Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text("@betmaster554"),
                  Text(
                    "*** *** 6155",
                    style: TextStyle(color: Colors.grey, fontSize: 18),
                  )
                ],
              ),
              Padding(
                padding: const EdgeInsets.only(bottom: 35.0, left: 8),
                child: Transform.rotate(
                    angle: 270 * math.pi / 180,
                    child: const Icon(
                      Icons.arrow_back_ios,
                      size: 12,
                      color: Colors.black,
                    )),
              ),
            ],
          ),
        ),
        const SizedBox(
          height: 40,
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              "₦",
              style: TextStyle(
                  fontFamily: 'Inter',
                  color: ColorConstant.primaryColor,
                  fontSize: 15),
            ),
            StatefulBuilder(
              builder: (context, setState) {
                return SizedBox(
                  width: width,
                  child: TextFormField(
                    controller: controller,
                    onChanged: (value) {
                      setState(
                        () {
                          width = value.isNotEmpty
                              ? value.length * (Get.width / 12) >
                                      Get.width / 1.3
                                  ? Get.width / 1.3
                                  : value.length * (Get.width / 12)
                              : Get.width / 12;
                        },
                      );
                    },
                    style: TextStyle(
                        fontSize: Get.width / 8.5,
                        color: Colors.black,
                        fontWeight: FontWeight.bold),
                    keyboardType: TextInputType.number,
                    inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                    decoration: InputDecoration(
                      hintStyle: TextStyle(color: Colors.grey[400]),
                      hintText: "500",
                    ),
                  ),
                );
              },
            ),
          ],
        ),
        const SizedBox(
          height: 40,
        ),
        const Text(
          "Current Balance is ₦5,323.00",
          style: TextStyle(fontFamily: 'Inter'),
        ),
        const SizedBox(
          height: 40,
        ),
        Text(
          "0% Fees",
          style: TextStyle(color: ColorConstant.primaryColor, fontSize: 20),
        ),
        const SizedBox(
          height: 40,
        ),
        CustomButton(
          width: Get.width / 1.3,
          text: "Continue",
          fontStyle: ButtonFontStyle.PoppinsMedium16,
          padding: ButtonPadding.PaddingAll4,
          height: 50,
          onTap: () {
            Get.to(() => TransferUserSelectionScreen());
          },
        )
      ]),
    );
  }
}
