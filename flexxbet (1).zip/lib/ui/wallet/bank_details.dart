import 'package:flexx_bet/ui/wallet/widget/withdraw_card.dart';
import 'package:flexx_bet/ui/wallet/widget/withdraw_confirmation.dart';
import 'package:flexx_bet/ui/components/custom_button.dart';
import 'package:flexx_bet/ui/components/custom_text_field.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class BankDetailsScreen extends StatelessWidget {
  BankDetailsScreen({super.key, required this.selectedCard});
  final WithdrawCard selectedCard;
  final TextEditingController accController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        systemOverlayStyle:
            const SystemUiOverlayStyle(statusBarColor: Colors.white),
        title: const Text(
          "Bank Details",
          style: TextStyle(color: Colors.black),
        ),
        centerTitle: true,
        leading: const BackButton(
          color: Colors.black,
        ),
        backgroundColor: Colors.white,
      ),
      body: Column(children: [
        const SizedBox(
          height: 20,
        ),
        selectedCard,
        Padding(
          padding: const EdgeInsets.all(18.0),
          child: CustomTextField(
              label: "Account Number",
              controller: accController,
              textInputType: TextInputType.number),
        ),
        const Padding(
          padding: EdgeInsets.all(18.0),
          child: Text(
            "Please check your details carefully to avoid sending money to the wrong account.",
            textAlign: TextAlign.center,
            style: TextStyle(color: Colors.grey),
          ),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 18.0, horizontal: 32),
          child: CustomButton(
            text: "Continue",
            fontStyle: ButtonFontStyle.PoppinsMedium16,
            padding: ButtonPadding.PaddingAll4,
            onTap: () {
              withdrawConfirmation(selectedCard.bankName, accController.text);
            },
          ),
        )
      ]),
    );
  }
}
