import 'package:flexx_bet/constants/colors.dart';
import 'package:flexx_bet/constants/images.dart';
import 'package:flexx_bet/ui/wallet/widget/topup_success_bottom_sheet.dart';
import 'package:flexx_bet/ui/components/custom_button.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'dart:math' as math;
import '../../../ui/components/custom_image_view.dart';

void paymentConfirmBottomSheet(double topupBalance) {
  Get.bottomSheet(
    Container(
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(25),
          topRight: Radius.circular(25),
        ),
      ),
      width: Get.width,
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: StatefulBuilder(
          builder: (context, setState) => Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Container(
                padding:
                    const EdgeInsets.symmetric(vertical: 14, horizontal: 8),
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: Colors.grey, width: 0.8)),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: CustomImageView(
                            imagePath: ImageConstant.masterCard,
                            width: 40,
                          ),
                        ),
                        const Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text("Matsrecard"),
                            Text("**** **** **** 1121"),
                          ],
                        ),
                      ],
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Transform.rotate(
                          angle: 90 * math.pi / 180,
                          child: const Icon(
                            Icons.arrow_forward_ios_rounded,
                            color: Colors.grey,
                            size: 15,
                          )),
                    )
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text("Top up balance",
                            style: TextStyle(color: Colors.grey, fontSize: 16)),
                        Text("₦$topupBalance",
                            style: TextStyle(
                              color: ColorConstant.primaryColor,
                              fontWeight: FontWeight.bold,
                              fontFamily: 'Inter',
                            ))
                      ],
                    ),
                    const SizedBox(
                      height: 25,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text("Fee",
                            style: TextStyle(color: Colors.grey, fontSize: 16)),
                        Text("₦3",
                            style: TextStyle(
                              color: ColorConstant.primaryColor,
                              fontWeight: FontWeight.bold,
                              fontFamily: 'Inter',
                            ))
                      ],
                    ),
                    const SizedBox(
                      height: 25,
                    ),
                    Container(
                      width: Get.width,
                      height: 1,
                      color: Colors.grey,
                    ),
                    const SizedBox(
                      height: 25,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text(
                          "Total",
                          style: TextStyle(color: Colors.grey, fontSize: 16),
                        ),
                        Text("₦${topupBalance + 3}",
                            style: TextStyle(
                              color: ColorConstant.primaryColor,
                              fontWeight: FontWeight.bold,
                              fontFamily: 'Inter',
                            ))
                      ],
                    ),
                    const SizedBox(
                      height: 25,
                    ),
                    CustomButton(
                      text: "Confirm Topup",
                      fontStyle: ButtonFontStyle.PoppinsMedium16,
                      padding: ButtonPadding.PaddingAll4,
                      height: 50,
                      onTap: () {
                        Get.back();
                        topupSuccess();
                      },
                    )
                  ],
                ),
              )
            ],
          ),
        ),
      ),
    ),
  );
}
