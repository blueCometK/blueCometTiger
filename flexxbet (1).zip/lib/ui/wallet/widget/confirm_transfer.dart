import 'package:flexx_bet/constants/colors.dart';
import 'package:flexx_bet/constants/images.dart';
import 'package:flexx_bet/ui/wallet/widget/transfer_success.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../ui/components/custom_button.dart';
import '../../../ui/components/custom_image_view.dart';

void confirmTransfer() {
  Get.dialog(
    Column(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Container(
          decoration: BoxDecoration(borderRadius: BorderRadius.circular(300)),
          width: 100,
          height: 100,
          child: Material(
            borderRadius: BorderRadius.circular(300),
            child: CustomImageView(
              imagePath: ImageConstant.walletConfirmationImage,
              width: 50,
            ),
          ),
        ),
        MyArc(
          child: Column(
            children: [
              const SizedBox(
                height: 15,
              ),
              Text(
                "Transfer Confirmation",
                style:
                    TextStyle(color: ColorConstant.primaryColor, fontSize: 20),
              ),
              const SizedBox(
                height: 15,
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Text(
                          "From",
                          style: TextStyle(color: Colors.grey),
                        ),
                        const SizedBox(
                          height: 2,
                        ),
                        Text(
                          "You",
                          style: TextStyle(
                              color: ColorConstant.primaryColor,
                              fontSize: 18,
                              fontWeight: FontWeight.bold),
                        )
                      ],
                    ),
                    const CircleAvatar(
                      backgroundImage: AssetImage(ImageConstant.user2),
                      radius: 30,
                    )
                  ],
                ),
              ),
              Container(
                margin: const EdgeInsets.all(8),
                color: Colors.grey,
                height: .21,
                width: Get.width,
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Text(
                          "To",
                          style: TextStyle(color: Colors.grey),
                        ),
                        const SizedBox(
                          height: 2,
                        ),
                        Text(
                          "@betmaster554",
                          style: TextStyle(
                              color: ColorConstant.primaryColor,
                              fontSize: 18,
                              fontWeight: FontWeight.bold),
                        )
                      ],
                    ),
                    const CircleAvatar(
                      backgroundImage: AssetImage(ImageConstant.user2),
                      radius: 30,
                    )
                  ],
                ),
              ),
              Container(
                margin: const EdgeInsets.all(8),
                color: Colors.grey,
                height: .21,
                width: Get.width,
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      "Total",
                      style: TextStyle(
                          color: ColorConstant.gray600,
                          fontWeight: FontWeight.bold),
                    ),
                    Column(
                      children: [
                        Text(
                          "₦2,000",
                          style: TextStyle(
                              fontFamily: 'Inter',
                              color: ColorConstant.primaryColor,
                              fontWeight: FontWeight.bold),
                        ),
                        Text(
                          "0% fee",
                          style: TextStyle(
                            color: ColorConstant.primaryColor,
                          ),
                        )
                      ],
                    )
                  ],
                ),
              ),
              CustomButton(
                width: Get.width,
                text: "OK, Send Now!",
                fontStyle: ButtonFontStyle.PoppinsMedium16,
                padding: ButtonPadding.PaddingAll4,
                height: 50,
                onTap: () {
                  Get.back();
                  transferSuccess();
                },
              )
            ],
          ),
        ),
      ],
    ),
  );
}

class MyArc extends StatelessWidget {
  final Widget child;
  const MyArc({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: Get.width / 1.2,
      height: Get.height / 1.9,
      child: CustomPaint(
        painter: CurvePainter(),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(8, 45, 8, 8),
          child: Material(color: Colors.white, child: child),
        ),
      ),
    );
  }
}

class CurvePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    var paint = Paint();
    paint.color = Colors.white;
    paint.style = PaintingStyle.fill; // Change this to fill

    var path = Path();

    path.moveTo(0, size.height - 20);
    path.quadraticBezierTo(0, size.height, 20, size.height);
    path.lineTo(size.width - 20, size.height);
    path.quadraticBezierTo(
        size.width, size.height, size.width, size.height - 20);
    path.lineTo(size.width, 20);
    path.quadraticBezierTo(size.width, 00, size.width - 20, 0);
    path.lineTo(size.width - 100, 0);
    path.quadraticBezierTo(size.width / 2, size.height / 6, 100, 0);
    path.lineTo(20, 0);
    path.quadraticBezierTo(0, 0, 0, 20);

    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) {
    return true;
  }
}
