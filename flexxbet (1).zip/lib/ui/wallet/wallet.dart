import 'package:flexx_bet/constants/colors.dart';
import 'package:flexx_bet/constants/images.dart';
import 'package:flexx_bet/ui/wallet/topup.dart';
import 'package:flexx_bet/ui/wallet/transfer.dart';
import 'package:flexx_bet/ui/wallet/withdraw.dart';
import 'package:flexx_bet/ui/components/custom_appbar.dart';
import 'package:flexx_bet/ui/components/custom_image_view.dart';
import 'package:flexx_bet/ui/components/participated_event_card.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class WalletScreen extends StatelessWidget {
  const WalletScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppBar(),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          SizedBox(
            width: Get.width,
            height: 15,
          ),
          Text(
            "Wallet Balance",
            style: TextStyle(
                color: ColorConstant.gray500,
                fontWeight: FontWeight.bold,
                fontSize: 20),
          ),
          const Text(
            "₦ 5,323.00",
            style: TextStyle(
                fontFamily: 'inter', fontSize: 40, fontWeight: FontWeight.w500),
          ),
          const SizedBox(
            height: 10,
          ),
          Container(
            padding: const EdgeInsets.fromLTRB(6, 0, 6, 0),
            decoration: BoxDecoration(
                color: Colors.black, borderRadius: BorderRadius.circular(40)),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Text(
                  "\$335",
                  style: TextStyle(color: ColorConstant.whiteA700),
                ),
                Icon(
                  Icons.arrow_drop_up,
                  color: ColorConstant.green500,
                ),
                Text(
                  "+6.54%",
                  style: TextStyle(color: ColorConstant.green500),
                )
              ],
            ),
          ),
          const SizedBox(
            height: 20,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              GestureDetector(
                onTap: () {
                  Get.to(() => TransferScreen());
                },
                child: Column(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                          color: Colors.black,
                          borderRadius: BorderRadius.circular(12)),
                      child: CustomImageView(
                        imagePath: ImageConstant.sendIcon,
                        height: 35,
                        width: 35,
                      ),
                    ),
                    const SizedBox(
                      height: 5,
                    ),
                    const Text("Transfer")
                  ],
                ),
              ),
              GestureDetector(
                onTap: () {
                  Get.to(() => TopupScreen());
                },
                child: Column(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                          color: Colors.black,
                          borderRadius: BorderRadius.circular(12)),
                      child: const Icon(
                        Icons.arrow_downward,
                        size: 35,
                        color: Colors.white,
                      ),
                    ),
                    const SizedBox(
                      height: 5,
                    ),
                    const Text("Deposit")
                  ],
                ),
              ),
              GestureDetector(
                onTap: () {
                  Get.to(() => WithdrawScreen());
                },
                child: Column(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                          color: Colors.black,
                          borderRadius: BorderRadius.circular(12)),
                      child: CustomImageView(
                        imagePath: ImageConstant.withdrawIcon,
                        height: 35,
                        width: 35,
                      ),
                    ),
                    const SizedBox(
                      height: 5,
                    ),
                    const Text("Withdraw")
                  ],
                ),
              ),
            ],
          ),
          Container(
            decoration: BoxDecoration(
                color: Colors.black, borderRadius: BorderRadius.circular(20)),
            margin: const EdgeInsets.all(15),
            padding: const EdgeInsets.fromLTRB(5, 10, 20, 10),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(
                  Icons.arrow_upward,
                  color: Colors.green,
                  size: 40,
                ),
                const SizedBox(
                  width: 5,
                ),
                const Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Total Gain",
                      style: TextStyle(color: Colors.white),
                    ),
                    Text("\$20,000",
                        style: TextStyle(color: Colors.white, fontSize: 22))
                  ],
                ),
                const SizedBox(
                  width: 25,
                ),
                Container(
                  width: 1,
                  height: 50,
                  color: Colors.white,
                ),
                const SizedBox(
                  width: 15,
                ),
                const Icon(
                  Icons.arrow_downward,
                  color: Colors.red,
                  size: 40,
                ),
                const SizedBox(
                  width: 5,
                ),
                const Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text("Total Loss", style: TextStyle(color: Colors.white)),
                    Text("\$17,000",
                        style: TextStyle(color: Colors.white, fontSize: 22))
                  ],
                ),
              ],
            ),
          ),
          DefaultTabController(
              length: 2,
              child: Column(
                children: [
                  TabBar(
                      labelColor: Colors.black,
                      indicatorColor: ColorConstant.primaryColor,
                      tabs: const [
                        Tab(
                          text: "Deposit",
                        ),
                        Tab(text: "Withdrawls")
                      ]),
                  SizedBox(
                      height: Get.height / 2.6,
                      child: TabBarView(children: [
                        ListView(
                          children: [
                            ParticipatedEventCard(
                              profit: -20,
                              title: "Chelsea will beat Arsenal",
                              imagePath: ImageConstant.liveEvent1,
                              subTitle: "UEFA League",
                              eventHeldDate: DateTime.now().subtract(
                                const Duration(days: 20),
                              ),
                            ),
                            ParticipatedEventCard(
                              profit: 200,
                              title: "Chelsea will beat Arsenal",
                              imagePath: ImageConstant.liveEvent1,
                              subTitle: "UEFA League",
                              eventHeldDate: DateTime.now().subtract(
                                const Duration(days: 20),
                              ),
                            ),
                            ParticipatedEventCard(
                              profit: 200,
                              title: "Chelsea will beat Arsenal",
                              imagePath: ImageConstant.liveEvent1,
                              subTitle: "UEFA League",
                              eventHeldDate: DateTime.now().subtract(
                                const Duration(days: 20),
                              ),
                            ),
                            ParticipatedEventCard(
                              profit: 200,
                              title: "Chelsea will beat Arsenal",
                              imagePath: ImageConstant.liveEvent1,
                              subTitle: "UEFA League",
                              eventHeldDate: DateTime.now().subtract(
                                const Duration(days: 20),
                              ),
                            ),
                            ParticipatedEventCard(
                              profit: 200,
                              title: "Chelsea will beat Arsenal",
                              imagePath: ImageConstant.liveEvent1,
                              subTitle: "UEFA League",
                              eventHeldDate: DateTime.now().subtract(
                                const Duration(days: 20),
                              ),
                            ),
                            ParticipatedEventCard(
                              profit: -200,
                              title: "Chelsea will beat Arsenal",
                              imagePath: ImageConstant.liveEvent1,
                              subTitle: "UEFA League",
                              eventHeldDate: DateTime.now().subtract(
                                const Duration(days: 20),
                              ),
                            ),
                          ],
                        ),
                        Container()
                      ]))
                ],
              )),
        ],
      ),
    );
  }
}
