import 'package:flexx_bet/constants/colors.dart';
import 'package:flexx_bet/constants/images.dart';
import 'package:flexx_bet/controllers/selection_controller.dart';
import 'package:flexx_bet/ui/wallet/bank_details.dart';
import 'package:flexx_bet/ui/wallet/widget/withdraw_card.dart';
import 'package:flexx_bet/ui/components/custom_button.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'package:get/get.dart';

class WithdrawToScreen extends StatelessWidget {
  WithdrawToScreen({super.key});

  final SelectionController selectionController =
      Get.put(SelectionController("flutterwave"));

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        systemOverlayStyle:
            const SystemUiOverlayStyle(statusBarColor: Colors.white),
        title: const Text(
          "Withdraw",
          style: TextStyle(color: Colors.black),
        ),
        centerTitle: true,
        leading: const BackButton(
          color: Colors.black,
        ),
        backgroundColor: Colors.white,
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(28, 8, 0, 8),
              child: Text(
                "Withdraw to",
                style: TextStyle(
                    color: ColorConstant.primaryColor,
                    fontSize: 28,
                    fontWeight: FontWeight.bold),
              ),
            ),
            const WithdrawCard(
              name: "Flutter Wave",
              value: "flutterwave",
              image: ImageConstant.paypal,
            ),
            const WithdrawCard(
              name: "Paystack",
              value: "paystack",
              image: ImageConstant.payfast,
            ),
            const WithdrawCard(
              name: "Payfast",
              value: "payfast",
              image: ImageConstant.visa,
            ),
            const WithdrawCard(
              name: "Palm Pay",
              value: "palmpay",
              image: ImageConstant.masterCard,
            ),
            const SizedBox(
              height: 30,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                CustomButton(
                  text: "Submit",
                  fontStyle: ButtonFontStyle.PoppinsMedium16,
                  width: Get.width / 1.2,
                  height: 50,
                  onTap: () {
                    late WithdrawCard selectedCard;
                    if (selectionController.selection == "flutterwave") {
                      selectedCard = const WithdrawCard(
                        name: "Flutter Wave",
                        value: "flutterwave",
                        image: ImageConstant.paypal,
                      );
                    } else if (selectionController.selection == "paystack") {
                      selectedCard = const WithdrawCard(
                        name: "Paystack",
                        value: "paystack",
                        image: ImageConstant.payfast,
                      );
                    } else if (selectionController.selection == "payfast") {
                      selectedCard = const WithdrawCard(
                        name: "Payfast",
                        value: "payfast",
                        image: ImageConstant.visa,
                      );
                    } else if (selectionController.selection == "palmpay") {
                      selectedCard = const WithdrawCard(
                        name: "Palm Pay",
                        value: "palmpay",
                        image: ImageConstant.masterCard,
                      );
                    }
                    Get.to(() => BankDetailsScreen(
                          selectedCard: selectedCard,
                        ));
                  },
                ),
              ],
            ),
            const SizedBox(
              height: 30,
            ),
          ],
        ),
      ),
    );
  }
}
