import 'package:badges/badges.dart' as badges;
import 'package:flexx_bet/constants/colors.dart';
import 'package:flexx_bet/constants/images.dart';
import 'package:flexx_bet/controllers/landing_page_controller.dart';
import 'package:flexx_bet/ui/components/custom_image_view.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

Obx buildBottomNavigationMenu(context) {
  LandingPageController landingPageController = LandingPageController.to;
  return Obx(() => Container(
        padding: const EdgeInsets.only(left: 20, bottom: 8, right: 20, top: 2),
        height: 80,
        child: Container(
          padding: const EdgeInsets.only(top: 6),
          decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(40),
              boxShadow: [
                BoxShadow(
                  color: const Color(0xFF000000).withOpacity(1),
                  offset: const Offset(0, 2),
                  blurRadius: 0,
                  spreadRadius: 1,
                ),
              ],
              color: ColorConstant.primaryColor),
          child: BottomNavigationBar(
            type: BottomNavigationBarType.fixed,
            showUnselectedLabels: false,
            showSelectedLabels: false,
            onTap: landingPageController.changeTabIndex,
            elevation: 0,
            backgroundColor: Colors.transparent,
            currentIndex: landingPageController.tabIndex.value,
            unselectedItemColor: Colors.black.withOpacity(0.5),
            selectedItemColor: Colors.black,
            selectedFontSize: 0,
            unselectedFontSize: 0,
            items: [
              customNavigationBarItem(imagePath: ImageConstant.activeHomeIcon),
              customNavigationBarItem(
                  width: 27,
                  imagePath: ImageConstant.activeBetIcon,
                  isBagedIcon: true),
              customNavigationBarItem(
                  imagePath: ImageConstant.activeChatIcon, isBagedIcon: true),
              customNavigationBarItem(imagePath: ImageConstant.activeRankIcon),
              customNavigationBarItem(
                  width: 21,
                  height: 25,
                  imagePath: ImageConstant.activePersonIcon),
            ],
          ),
        ),
      ));
}

BottomNavigationBarItem customNavigationBarItem(
    {required String imagePath,
    bool isBagedIcon = false,
    double height = 25,
    double width = 25}) {
  const int numberOfMessages = 99;
  return BottomNavigationBarItem(
    activeIcon: Container(
      width: 120,
      child: Column(
        children: [
          badges.Badge(
            position: badges.BadgePosition.topEnd(top: -8),
            badgeAnimation: const badges.BadgeAnimation.slide(),
            showBadge: isBagedIcon,
            badgeStyle: const badges.BadgeStyle(
              padding: EdgeInsets.all(3),
              badgeColor: Colors.red,
            ),
            badgeContent: Text(
              numberOfMessages > 99 ? "99+" : numberOfMessages.toString(),
              style: const TextStyle(color: Colors.white, fontSize: 8),
            ),
            child: CustomImageView(
              imagePath: imagePath,
              fit: BoxFit.contain,
              height: height,
              width: width,
            ),
          ),
          const SizedBox(
            height: 8,
          ),
          Container(
            decoration: BoxDecoration(
                color: Colors.white, borderRadius: BorderRadius.circular(60)),
            height: 2,
            width: 7,
          )
        ],
      ),
    ),
    icon: Column(
      children: [
        badges.Badge(
          position: badges.BadgePosition.topEnd(top: -2),
          badgeAnimation: const badges.BadgeAnimation.slide(),
          showBadge: isBagedIcon,
          badgeStyle: const badges.BadgeStyle(
            padding: EdgeInsets.all(3),
            badgeColor: Colors.red,
          ),
          badgeContent: Text(
            numberOfMessages > 99 ? "99+" : numberOfMessages.toString(),
            style: const TextStyle(color: Colors.white, fontSize: 8),
          ),
          child: CustomImageView(
            imagePath: imagePath,
            height: height,
            width: width,
          ),
        ),
        const SizedBox(
          height: 10,
        ),
      ],
    ),
    label: "",
    backgroundColor: ColorConstant.whiteA700,
  );
}
