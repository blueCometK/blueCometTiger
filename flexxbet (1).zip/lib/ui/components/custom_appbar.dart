import 'package:flexx_bet/constants/colors.dart';
import 'package:flexx_bet/constants/images.dart';
import 'package:flexx_bet/controllers/landing_page_controller.dart';
import 'package:flexx_bet/ui/notifications/notifications.dart';
import 'package:flexx_bet/ui/wallet/wallet.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:badges/badges.dart' as badges;
import 'custom_image_view.dart';

class CustomAppBar extends StatelessWidget implements PreferredSizeWidget {
  CustomAppBar({super.key});

  final bool shouldShowBackbutton = Get.currentRoute == "/LandingPage" ||
      Get.currentRoute == "/" ||
      Get.currentRoute == "/landing-page";

  @override
  Widget build(BuildContext context) {
    return AppBar(
      systemOverlayStyle: SystemUiOverlayStyle(
        // Status bar color
        statusBarColor: ColorConstant.primaryColor,
        statusBarIconBrightness: Brightness.light,
      ),
      toolbarHeight: Get.height / 12,
      actions: [
        GestureDetector(
            onTap: () {
              Get.to(() => const NotificationsScreen());
            },
            child: Center(
              child: badges.Badge(
                  position: badges.BadgePosition.topEnd(top: -1, end: -1),
                  badgeAnimation: const badges.BadgeAnimation.slide(),
                  badgeStyle: const badges.BadgeStyle(
                    padding: EdgeInsets.all(8),
                    badgeColor: Colors.red,
                  ),
                  child: const Icon(
                    Icons.notifications,
                    size: 28,
                  )),
            )),
        const SizedBox(
          width: 15,
        ),
        GestureDetector(
          onTap: () {
            Get.to(() => const WalletScreen());
          },
          child: Container(
            margin: const EdgeInsets.only(top: 14, bottom: 14),
            padding: const EdgeInsets.only(left: 18, right: 18),
            decoration: BoxDecoration(
                color: ColorConstant.whiteA700,
                borderRadius: const BorderRadius.only(
                    topLeft: Radius.circular(50),
                    bottomLeft: Radius.circular(50))),
            child: Center(
              child: Text(
                "₦ 250.00",
                style: TextStyle(
                    fontFamily: 'Inter',
                    fontWeight: FontWeight.w600,
                    color: ColorConstant.primaryColor),
              ),
            ),
          ),
        )
      ],
      leading: shouldShowBackbutton
          ? CustomImageView(
              imagePath: ImageConstant.appLogo,
              fit: BoxFit.contain,
            )
          : BackButton(
              onPressed: () {
                shouldShowBackbutton
                    ? LandingPageController.to.changeTabIndex(0)
                    : Get.back();
              },
            ),
      leadingWidth: shouldShowBackbutton ? Get.width / 2.5 : null,
    );
  }

  @override
  Size get preferredSize => Size.fromHeight(
      Get.height / 12 > kToolbarHeight ? Get.height / 11 : kToolbarHeight);
}
