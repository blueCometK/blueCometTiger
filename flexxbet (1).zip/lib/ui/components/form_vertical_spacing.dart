import 'package:flutter/material.dart';

class FormVerticalSpace extends SizedBox {
  const FormVerticalSpace({super.key, double height = 24.0}) : super(height: height);
}
