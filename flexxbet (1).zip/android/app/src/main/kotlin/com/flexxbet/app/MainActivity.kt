package com.flexxbet.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
