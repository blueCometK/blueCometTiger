export const firebaseConfig = {
  apiKey: "AIzaSyAUdtFzcPu7WL9JAwjVBGFKLTRIBQ3G6yw",
  authDomain: "church-6caf9.firebaseapp.com",
  projectId: "church-6caf9",
  storageBucket: "church-6caf9.appspot.com",
  messagingSenderId: "919308162087",
  appId: "1:919308162087:web:1b147c2b4199dce688aa02",
  measurementId: "G-8E89GGH38R"
};