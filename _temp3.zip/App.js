import * as React from "react";
import { NavigationContainer } from "@react-navigation/native";
import { createStackNavigator } from "@react-navigation/stack";
import DrawerNavigator from "./src/navigators/DrawerNavigator";
import { PaperProvider } from 'react-native-paper';
import SplashPage from "./src/pages/SplashPage";
import Toast from 'react-native-toast-message';
import { UserProvider } from "./src/context/userContext";
import LoginScreen from "./src/pages/Auth/LoginPage";
import RegisgerScreen from "./src/pages/Auth/RegistrationPage";
import { GoogleSignin } from "@react-native-google-signin/google-signin";

GoogleSignin.configure({
  offlineAccess: true,
  webClientId: '919308162087-n9gl6n33h8o7i85i5mb4eht7ppn0219m.apps.googleusercontent.com',
});

const StackApp = createStackNavigator();

export default function App() {
  return (
    <PaperProvider>
      <UserProvider>
        <NavigationContainer>
          <StackApp.Navigator initialRouteName="Splash" screenOptions={{ headerShown: false }}>
            <StackApp.Screen name="Splash" component={SplashPage} />
            <StackApp.Screen name="HomeApp" component={DrawerNavigator} />
            <StackApp.Screen name="Login" component={LoginScreen} />
            <StackApp.Screen name="Register" component={RegisgerScreen} />
          </StackApp.Navigator>
        </NavigationContainer>
      </UserProvider>
      <Toast />
    </PaperProvider>
  );
}
