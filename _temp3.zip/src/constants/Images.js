const IMAGE = {
  HOME_ICON: require("../../assets/home.png"),
  HOME_SELECTED_ICON: require("../../assets/home-selected.png"),
  SETTINGS_ICON: require("../../assets/settings.png"),
  SETTINGS_SELECTED_ICON: require("../../assets/settings-selected.png"),
  MENU_ICON: require("../../assets/hamburger.png"),
  BACK_ICON: require("../../assets/left.png"),
  BACKGROUND_IMAGE : require("../../assets/images/bg.jpg"),
  SLIDE_IMAGE_1 : require("../../assets/images/slide/1.jpg"),
};

export { IMAGE };
