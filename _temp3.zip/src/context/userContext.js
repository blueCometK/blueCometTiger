import React, { createContext, useContext, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

// Create a context
const userContext = createContext();

export const UserProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [reRenderFlag, setReRenderFlag] = useState(false);
  const [notificationFlag, setNotificationFlag] = useState(false);

  const signIn = (
    {
      id,
      userName,
      userEmail,
      phoneNumber,
      birth,
      language,
      address,
      avatarUrl,
      church
    }) => {
    setUser({
      id: id,
      userName: userName,
      userEmail: userEmail,
      phoneNumber: phoneNumber,
      birth: birth,
      language: language,
      address: address,
      avatarUrl: avatarUrl,
      church: church
    }
    );

  }

  const setToken = async (token) => {
    await AsyncStorage.setItem('token', token);
  }

  const signOut = () => {
    setToken('token', '');
    setUser(null);
  }

  const setLoding = (value) => {
    setIsLoading(value);
  }

  const setRenderFlag = (value) => {
    setReRenderFlag(value);
  }

  const setNotification = (value) => {
    setNotificationFlag(value);
  }

  return (
    <userContext.Provider value={{ user, isLoading, reRenderFlag, notificationFlag, signIn, signOut, setLoding, setRenderFlag, setNotification }}>
      {children}
    </userContext.Provider>
  );
};

export const useUserContext = () => {
  return useContext(userContext);
};