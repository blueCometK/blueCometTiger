import React, { useState, useEffect } from 'react';
import { ActivityIndicator, View, ImageBackground } from 'react-native';
import { styles } from '../styles';

export default function SplashPage({ navigation }) {
    const [animating, setAnimating] = useState(true);

    useEffect(() => {
        setTimeout(() => {
            setAnimating(false);
            navigation.navigate("Login");
        }, 2000);
    }, []);

    return (
        <View style={{ flex: 1 }}>
            <ImageBackground source={require('../../assets/images/bg.jpg')} resizeMode="cover" style={{ backgroundColor: "red", flex: 1, justifyContent: 'center' }}>
                <ActivityIndicator
                    animating={animating}
                    color="#FFFFFF"
                    size="large"
                    style={styles.activityIndicator}
                />
            </ImageBackground>
        </View>
    )
}