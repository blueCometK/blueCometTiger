import React from "react";
import { View, Text, Image, ScrollView, TouchableOpacity, ImageBackground } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import CustomHeader from "../../components/CustomHeader";
import { Button } from 'react-native-paper';
import { useUserContext } from "../../context/userContext";
import Preloader from "../../components/Preloader";
import axios from 'axios';
import Toast from "react-native-toast-message";
import AsyncStorage from '@react-native-async-storage/async-storage';

function HomePage({ navigation }) {
  const { user, setLoding, reRenderFlag, isLoading, userChurch } = useUserContext();
  const [churchData, setChurchData] = React.useState(null);

  const getChurch = async (id) => {
    const token = await AsyncStorage.getItem('token');
    const headers = {
      authorization: `${token}`
    }
    await axios.get(`https://church-backend-8690bcab1cc8.herokuapp.com/api/church/get_church_detail/${id}`, { headers })
      .then(function (response) {
        setChurchData(response.data.church);
      })
      .catch(function (error) {
        Toast.show({
          type: 'error',
          text1: "Action Failed",
          text2: error.message,
        });
      });
  }

  React.useEffect(() => {
    getChurch(user?.church);
  }, [navigation]);
  return (
    <SafeAreaView style={{ flex: 1 }}>
      <CustomHeader title="Home" isHome={true} navigation={navigation} />
      <ScrollView style={{ marginTop: 10 }}>
        <View style={{ paddingHorizontal: 20 }}>
          <View style={{ position: 'relative' }}>
            <Text style={{ position: 'absolute', top: 10, zIndex: 30, color: 'white', left: 10, fontSize: 20, fontWeight: 'bold', textShadowColor: '#171717', textShadowOffset: { width: -1, height: 1 }, textShadowRadius: 10 }}>{churchData?.churchName}</Text>
            <Image source={{ uri: churchData?.photoUrl }} style={{ height: 220, width: "100%", borderRadius: 15 }} />
            <TouchableOpacity mode="contained" textColor='white' style={{ backgroundColor: '#FE7940', position: 'absolute', bottom: 10, right: 10, paddingHorizontal: 10, borderRadius: 5 }} onPress={() => navigation.navigate("Church")}><Text style={{ color: 'white' }}>Switch</Text></TouchableOpacity>
          </View>
          <View style={{ backgroundColor: "#DBDBDB", height: 5, width: "100%", marginVertical: 30 }}></View>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 30 }}>
            <TouchableOpacity onPress={() => navigation.navigate("OfferPage", user.church)}>
              <View style={{ width: 110, height: 198 }}>
                <Image source={require('../../../assets/images/banner/offer.jpg')} style={{ width: 110, height: 170, borderRadius: 10, marginBottom: 10, shadowColor: '#171717', shadowOffset: { width: -2, height: 4 }, shadowOpacity: 0.2, shadowRadius: 3, }} />
                <Text style={{ fontSize: 14, color: '#FE7940', textAlign: 'center', fontWeight: 'bold' }}>Offer</Text>
              </View>
            </TouchableOpacity>
            <TouchableOpacity onPress={() => navigation.navigate("TithePage", user.church)}>
              <View style={{ width: 110, height: 198 }}>
                <Image source={require('../../../assets/images/banner/tithe.jpg')} style={{ width: 110, height: 170, borderRadius: 10, marginBottom: 10, shadowColor: '#171717', shadowOffset: { width: -2, height: 4 }, shadowOpacity: 0.2, shadowRadius: 3, }} />
                <Text style={{ fontSize: 14, color: '#FE7940', textAlign: 'center', fontWeight: 'bold' }}>Tithe</Text>
              </View>
            </TouchableOpacity>
            <TouchableOpacity onPress={() => navigation.navigate("Project", user.church)}>
              <View style={{ width: 110, height: 198 }}>
                <Image source={require('../../../assets/images/banner/project.jpg')} style={{ width: 110, height: 170, borderRadius: 10, marginBottom: 10, shadowColor: '#171717', shadowOffset: { width: -2, height: 4 }, shadowOpacity: 0.2, shadowRadius: 3, }} />
                <Text style={{ fontSize: 14, color: '#FE7940', textAlign: 'center', fontWeight: 'bold' }}>Project</Text>
              </View>
            </TouchableOpacity>

          </View>
          <Text style={{ fontSize: 16, fontWeight: '600', marginBottom: 20, marginTop: 20 }}>Daily scripture</Text>
          <ImageBackground source={require('../../../assets/images/scription_bg.jpg')} resizeMode="cover" style={{ flex: 1, justifyContent: 'center', paddingHorizontal: 10, paddingVertical: 20, marginBottom: 30, borderRadius: 5 }}>
            <Text style={{ fontSize: 14, fontWeight: '500' }}>The wicked flee when no one is pursuing, but the righteous are bold as a lion</Text>
            <Text style={{ fontSize: 9, textAlign: 'right', color: '#484848', marginTop: 5 }}>Proverbs 28:1</Text>
          </ImageBackground>
        </View>
      </ScrollView>
      {isLoading && <Preloader />}
    </SafeAreaView>
  );
}

export default HomePage;
