import React, { useState, useEffect, useRef } from 'react';
import { Text, View, Image, ScrollView, TouchableOpacity } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import CustomHeader, { SubHeader } from "../../components/CustomHeader";
import * as ImagePicker from 'expo-image-picker';
import { TextInput, Button } from 'react-native-paper';
import { Picker } from '@react-native-picker/picker';
import { useUserContext } from '../../context/userContext';
import axios from 'axios';
import Toast from 'react-native-toast-message';
import Preloader from '../../components/Preloader';
import AsyncStorage from '@react-native-async-storage/async-storage';

function ProfilePage({ navigation }) {
    const { user, signIn, setLoding, isLoading } = useUserContext();
    const [image, setImage] = useState(null);
    const [churchData, setChurchData] = React.useState([]);

    const [name, setName] = useState(user?.userName);
    const [email, setEmail] = useState(user?.userEmail);
    const [birth, setBirth] = useState(user?.birth);
    const [phone, setPhone] = useState(user?.phoneNumber);
    const [address, setAddress] = useState(user?.address);
    const [avataUrl, setAvatarUrl] = React.useState(user?.avatarUrl);
    const [selectedChurch, setSelectedChurch] = React.useState(user?.church);
    const [selectedLanguage, setSelectedLanguage] = React.useState(user?.language);

    const [oPassword, setOPassword] = useState('');
    const [nPassword, setNPassword] = useState('');
    const [cPassword, setCPassword] = useState('');





    const pickImage = async () => {
        let image = await ImagePicker.launchImageLibraryAsync({
            mediaTypes: ImagePicker.MediaTypeOptions.All,
            allowsEditing: true,
            aspect: [4, 3],
            quality: 1,
        });


        if (!image.canceled) {
            setAvatarUrl(image.uri);

            let imageUri = image.uri;
            let fileName = imageUri.split('/').pop();
            let fileExtension = imageUri.substring(imageUri.lastIndexOf('.') + 1);
            let date = new Date();
            setLoding(true);

            const formData = new FormData();
            formData.append('image', {
                uri: image.uri,
                type: `image/${image.type}`,
                name: `profile_${date.getFullYear()}_${date.getMonth()}_${date.getDay()}_${date.getHours()}_${date.getMinutes()}_${date.getSeconds()}.${fileExtension}`,
            });

            await axios.post('https://church-backend-8690bcab1cc8.herokuapp.com/api/upload', formData, {
                headers: {
                    'Content-Type': 'multipart/form-data',
                },
            })
                .then(response => {
                    setAvatarUrl(response.data.path);
                    setLoding(false);
                    Toast.show({
                        type: 'success',
                        text1: "Image uploaded successfully",
                    });
                })
                .catch(error => {
                    setLoding(false);
                    console.error(error);
                });
        }
    };

    const updateProfile = async () => {
        setLoding(true);
        const token = await AsyncStorage.getItem('token');
        const headers = {
            authorization: `${token}`
        }
        await axios.post('https://church-backend-8690bcab1cc8.herokuapp.com/api/accounts/update_profile',
            {
                userId: user.id,
                username: name,
                useremail: email,
                phonenumber: phone,
                birth: birth,
                language: selectedLanguage,
                address: address,
                church: selectedChurch,
                avatarurl: avataUrl,
                status: true
            },
            { headers })
            .then(function (response) {
                Toast.show({
                    type: 'success',
                    text1: "Action Success",
                    text2: response.data.message,
                });
                signIn({
                    id: response.data.user._id,
                    userName: response.data.user.userName,
                    userEmail: response.data.user.userEmail,
                    phoneNumber: response.data.user.phoneNumber,
                    birth: response.data.user.birth,
                    language: response.data.user.language,
                    address: response.data.user.address,
                    avatarUrl: response.data.user.avatarUrl,
                    church: response.data.user.church
                })
                setLoding(false);

            })
            .catch(function (error) {
                setLoding(false);
                Toast.show({
                    type: 'error',
                    text1: "Action Failed",
                    text2: error.message,
                });
            });
    }

    const updatePassword = async () => {
        const token = await AsyncStorage.getItem('token');
        const headers = {
            authorization: `${token}`
        }


        if (nPassword == '' || cPassword == '') {
            Toast.show({
                type: 'error',
                text1: "You don't input password. please enter password",
            });
            return;
        }

        if (nPassword != cPassword) {
            Toast.show({
                type: 'error',
                text1: "New Password not match with Confirm Password.",
            });
            return;
        }
        setLoding(true);
        await axios.post('https://church-backend-8690bcab1cc8.herokuapp.com/api/accounts/update_password',
            {
                userId: user.id,
                useremail: email,
                oldpassword: oPassword,
                newpassword: nPassword
            }, {
            headers
        })
            .then(function (response) {
                Toast.show({
                    type: 'success',
                    text1: "Action Success",
                    text2: response.data.message,
                });
                // signIn(response.data)
                setOPassword("");
                setNPassword("");
                setCPassword("");
                setLoding(false);

            })
            .catch(function (error) {
                setLoding(false);
                Toast.show({
                    type: 'error',
                    text1: "Action Failed",
                    text2: error.message,
                });
            });
    }

    const getChurchList = async () => {
        const token = await AsyncStorage.getItem('token');
        const headers = {
            authorization: `${token}`
        }
        await axios.get('https://church-backend-8690bcab1cc8.herokuapp.com/api/church/all_churches', { headers })
            .then(function (response) {
                setChurchData(response.data.church);
            })
            .catch(function (error) {
                Toast.show({
                    type: 'error',
                    text1: "Action Failed",
                    text2: error.message,
                });
            });
    }

    useEffect(() => {
        const getData = navigation.addListener('focus', () => {
            setOPassword('');
            setNPassword('');
            setCPassword('');
            getChurchList();
        });
        return getData;
    }, [navigation]);


    return (
        <SafeAreaView style={{ flex: 1 }}>
            <CustomHeader title="Profile" navigation={navigation} />
            <SubHeader navigation={navigation} />
            <ScrollView style={{ flex: 1, paddingHorizontal: 15 }}>
                <View style={{ alignItems: 'center', justifyContent: 'center' }}>
                    <TouchableOpacity onPress={pickImage}>
                        {avataUrl ? <Image source={{ uri: avataUrl }} style={{ width: 115, height: 115, borderRadius: 500, marginBottom: 20 }} /> : <Image source={require('../../../assets/images/default_user.png')} style={{ width: 115, height: 115, borderRadius: 500, marginBottom: 20 }} />}
                    </TouchableOpacity>
                </View>
                <Text style={{ color: "#868889", fontSize: 13, fontWeight: '700', textAlign: 'left' }}>Personal</Text>
                <View style={{ paddingHorizontal: 20, marginBottom: 20 }}>
                    <TextInput
                        label="Enter Full Name"
                        value={name}
                        style={{ backgroundColor: 'transparent', fontSize: 12 }}
                        onChangeText={text => setName(text)}
                    />
                    <TextInput
                        label="Enter Email"
                        value={email}
                        style={{ backgroundColor: 'transparent', fontSize: 12 }}
                        onChangeText={text => setEmail(text)}
                    />
                    <TextInput
                        label="Enter Phone Number"
                        value={phone}
                        style={{ backgroundColor: 'transparent', fontSize: 12 }}
                        onChangeText={text => setPhone(text)}
                    />
                    <TextInput
                        label="Enter Address"
                        value={address}
                        style={{ backgroundColor: 'transparent', fontSize: 12 }}
                        onChangeText={text => setAddress(text)}
                    />
                    <TextInput
                        label="Enter Birthday"
                        placeholder='2000-01-01'
                        keyboardType={'numeric'}
                        style={{ backgroundColor: 'transparent', width: "100%", fontSize: 12 }}
                    />
                    <Text style={{ fontSize: 11, marginLeft: 15, marginTop: 5 }}>Language</Text>
                    <View style={{
                        flex: 1,
                        alignItems: 'center',
                        justifyContent: 'center',
                        flexDirection: 'column',
                        borderBottomColor: 'black',
                        borderBottomWidth: 1
                    }}>

                        <Picker
                            selectedValue={selectedLanguage}
                            style={{ width: "100%", height: 30, marginLeft: 15 }}

                            onValueChange={(itemValue, itemIndex) => setSelectedLanguage(itemValue)}
                        >
                            <Picker.Item label="English" value="option1" style={{ fontSize: 12, marginLeft: 15 }} />
                            <Picker.Item label="French" value="option2" style={{ fontSize: 12 }} />

                        </Picker>

                    </View>
                    <Text style={{ fontSize: 11, marginLeft: 15, marginTop: 5 }}>Church</Text>
                    <View style={{
                        flex: 1,
                        alignItems: 'center',
                        justifyContent: 'center',
                        flexDirection: 'column',
                        borderBottomColor: 'black',
                        borderBottomWidth: 1
                    }}>

                        <Picker
                            selectedValue={selectedChurch}
                            style={{ width: "100%", height: 30, marginLeft: 15 }}
                            onValueChange={(itemValue, itemIndex) => setSelectedChurch(itemValue)}
                        >
                            {churchData.map((item, index) => (
                                <Picker.Item label={item.churchName} key={index} value={item._id} style={{ fontSize: 12 }} />
                            ))}
                        </Picker>

                    </View>

                    <Button mode="contained" textColor='white' style={{ backgroundColor: '#FE7940', marginTop: 30 }} onPress={updateProfile}>Update Profile</Button>
                </View>
                <Text style={{ color: "#868889", fontSize: 13, fontWeight: '700', textAlign: 'left' }}>Security</Text>
                <View style={{ paddingHorizontal: 20, marginBottom: 50 }}>
                    <TextInput
                        label="Enter Old Password"
                        secureTextEntry={true}
                        value={oPassword}
                        onChangeText={(text) => setOPassword(text)}
                        style={{ backgroundColor: 'transparent', fontSize: 12 }}
                    />
                    <TextInput
                        label="Enter New Password"
                        secureTextEntry={true}
                        value={nPassword}
                        onChangeText={(text) => setNPassword(text)}
                        style={{ backgroundColor: 'transparent', fontSize: 12 }}
                    />
                    <TextInput
                        label="Enter Confirm Password"
                        secureTextEntry={true}
                        value={cPassword}
                        onChangeText={text => setCPassword(text)}
                        style={{ backgroundColor: 'transparent', fontSize: 12 }}
                    />
                    <Button mode="contained" textColor='white' style={{ backgroundColor: '#FE7940', marginTop: 30 }} onPress={updatePassword}>Update Password</Button>
                </View>
            </ScrollView>
            {isLoading && <Preloader />}
        </SafeAreaView>
    );
}

export default ProfilePage;
