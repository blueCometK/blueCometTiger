import React, { useEffect } from 'react';
import { View, ImageBackground, Image, Text } from "react-native";
import { Card, TextInput, Button } from 'react-native-paper';
import { styles } from '../../styles';
import { IMAGE } from '../../constants/Images';
import Toast from 'react-native-toast-message';
import axios from 'axios';
import { useUserContext } from '../../context/userContext';
import Preloader from '../../components/Preloader';
import AsyncStorage from '@react-native-async-storage/async-storage';

export default function LoginScreen({ navigation }) {


  const { signIn, signOut, setLoding, isLoading } = useUserContext();
  const [isShow, setIsShow] = React.useState(false);

  const [userName, setUserName] = React.useState('');
  const [password, setPassword] = React.useState('');


  const setToken = async (token) => {
    await AsyncStorage.setItem('token', token);
  }

  const signInButton = async () => {

    if (userName == '' || password == '') {
      Toast.show({
        type: 'error',
        text1: 'Please input User Name or Password'
      });
      return;
    }
    setLoding(true);

    let data = {
      useremail: userName,
      password: password
    }




    await axios.post('https://church-backend-8690bcab1cc8.herokuapp.com/api/accounts/signin', data)
      .then(function (response) {
        Toast.show({
          type: 'success',
          text1: "Action Success",
          text2: response.data.message,
        });
        setToken(response.data.token)


        signIn({
          id: response.data.user._id,
          userName: response.data.user.userName,
          userEmail: response.data.user.userEmail,
          phoneNumber: response.data.user.phoneNumber,
          birth: response.data.user.birth,
          language: response.data.user.language,
          address: response.data.user.address,
          avatarUrl: response.data.user.avatarUrl,
          church: response.data.user.church
        });
        setLoding(false);
        navigation.navigate("HomeApp");
      })
      .catch(function (error) {
        setLoding(false);
        if (error.response?.status == 401) {
          Toast.show({
            type: 'error',
            text1: "Action Failed",
            text2: error.response.data.message,
          });
        }
        if (error.response?.status == 500) {
          Toast.show({
            type: 'error',
            text1: "Action Failed",
            text2: error.response.data.error,
          });
        }
      });
  }


  useEffect(() => {
    const getData = navigation.addListener('focus', () => {
      setUserName('');
      setPassword('');
    });
    return getData;
  }, [navigation]);


  const signInWithGoogleAsync = async () => {
    try {
      await GoogleSignin.hasPlayServices();
      const userInfo = await GoogleSignin.signIn();
      setState({ userInfo });
    } catch (error) {
      if (error.code === statusCodes.SIGN_IN_CANCELLED) {
        // user cancelled the login flow
      } else if (error.code === statusCodes.IN_PROGRESS) {
        // operation (e.g. sign in) is in progress already
      } else if (error.code === statusCodes.PLAY_SERVICES_NOT_AVAILABLE) {
        // play services not available or outdated
      } else {
        // some other error happened
      }
    }
  }


  return (
    <View style={styles.container}>
      <ImageBackground source={IMAGE.BACKGROUND_IMAGE} resizeMode="cover" style={styles.image}>
        <View style={styles.mainContinaer}>
          <Card style={styles.authCard}>
            <Card.Content>
              <View style={styles.tabButtonView}>
                <Button style={styles.tabButtonActive} textColor="white" onPress={() => navigation.navigate("Login")}>Log In</Button>
                <Button style={styles.tabButton} textColor="#FE7940" onPress={() => navigation.navigate("Register")} >Sign Up</Button>
              </View>
              <View>
                <TextInput
                  label="Enter email or phone number"
                  style={styles.inputBox}
                  value={userName}
                  onChangeText={text => setUserName(text)}
                />
                <TextInput
                  label="Password"
                  value={password}
                  onChangeText={text => setPassword(text)}
                  style={styles.inputBox}
                  right={<TextInput.Icon icon="eye" onPress={() => setIsShow(!isShow)} />}
                  secureTextEntry={!isShow ? true : false}
                />
                <Text style={{ textAlign: 'right', fontSize: 12 }}>Forgor Password?</Text>
                <Button mode="contained" textColor='white' style={{ backgroundColor: '#FE7940', marginTop: 30 }} onPress={signInButton}>Log In</Button>
                <Text style={{ marginBottom: 20, marginTop: 20, textAlign: 'center' }}>OR</Text>
                <View style={{ alignContent: 'center', flexDirection: 'row', justifyContent: "center" }}>
                  <Button style={{ height: 70, justifyContent: 'center', alignItems: 'flex-end', padding: 0 }} onPress={signInWithGoogleAsync}><Image source={require('../../../assets/images/icons/google.png')} resizeMode='stretch' style={{ width: 60, height: 60 }} /></Button>
                  <Button style={{ height: 70, justifyContent: 'center', alignItems: 'baseline', padding: 0 }}><Image source={require('../../../assets/images/icons/facebook.png')} resizeMode='stretch' style={{ width: 60, height: 60 }} /></Button>
                </View>
              </View>
            </Card.Content>
          </Card>
        </View>
        {isLoading && <Preloader />}
      </ImageBackground>
    </View>
  )

}

