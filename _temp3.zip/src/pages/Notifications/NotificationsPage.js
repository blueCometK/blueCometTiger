import React, { useEffect, useState } from "react";
import { Text, View, ScrollView } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import CustomHeader, { SubHeader } from "../../components/CustomHeader";
import { NotificationCard } from "../../components/Cards";
import axios from 'axios';
import Toast from "react-native-toast-message";
import { useUserContext } from "../../context/userContext";
import Preloader from "../../components/Preloader";
import { TouchableOpacity } from "react-native-gesture-handler";
import AsyncStorage from '@react-native-async-storage/async-storage';

function NotificationsPage({ navigation }) {
  const [notificationData, setNotificationData] = useState([]);
  const { user, isLoading, setLoding, notificationFlag, setNotification } = useUserContext();

  const getNotification = async () => {
    const token = await AsyncStorage.getItem('token');
    const headers = {
      authorization: `${token}`
    }
    await axios.get(`https://church-backend-8690bcab1cc8.herokuapp.com/api/notifications/get_user_notifications/${user?.id}`, { headers })
      .then(function (response) {
        setNotificationData(response.data.notification);
      })
      .catch(function (error) {
        Toast.show({
          type: 'error',
          text1: "Action Failed",
          text2: error.message,
        });
      });
  }

  const clickRead = async (notificationId, userId) => {
    const token = await AsyncStorage.getItem('token');
    const headers = {
      authorization: `${token}`
    }
    let data = {
      notificationId: notificationId,
      userId: userId,
    }
    await axios.post('https://church-backend-8690bcab1cc8.herokuapp.com/api/notifications/read_notification', data, { headers })
      .then(function (response) {
      })
      .catch(function (error) {
        Toast.show({
          type: 'error',
          text1: "Action Success",
          text2: error.message,
        });
      });
  }

  React.useEffect(() => {
    const getData = navigation.addListener('focus', () => {
      getNotification();
    });
    return getData;
  }, [navigation]);


  const searchItem = (arr, userId) => {
    if (arr.some(obj => obj.userId == userId) == false) {
    }
    return arr.some(obj => obj.userId == userId);
  }
  return (
    <SafeAreaView style={{ flex: 1 }}>
      <CustomHeader title="Notifications" navigation={navigation} />
      <SubHeader navigation={navigation} />
      <ScrollView style={{ paddingHorizontal: 15 }}>
        {
          notificationData.map((item, index) => (
            <TouchableOpacity key={index} onPress={() => {
              if (searchItem(item.markOfRead, user?.id) == false) {
                clickRead(item._id, user?.id);
              }
              navigation.navigate("NotificationDetail", {
                id: item._id,
                title: item.notificationTitle,
                type: item.notificationType,
                description:
                  item.description,
                date: item.createdDate
              })
            }}
            >
              <NotificationCard type={item.notificationType} title={item.notificationTitle} description={item.description} datetime={item.createdDate} markOfRead={searchItem(item.markOfRead, user?.id) == false ? true : false} />
            </TouchableOpacity>
          ))
        }
      </ScrollView>
      {isLoading && <Preloader />}
    </SafeAreaView>
  );
}

export default NotificationsPage;
