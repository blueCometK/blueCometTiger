import React from "react";
import { ScrollView, Text, TextInput, View, Image } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import CustomHeader, { SubHeader } from "../../components/CustomHeader";
import { Button } from 'react-native-paper';
import Toast from 'react-native-toast-message';
import axios from 'axios';
import { useUserContext } from "../../context/userContext";
import { useRoute } from "@react-navigation/native";
import Preloader from "../../components/Preloader";
import AsyncStorage from '@react-native-async-storage/async-storage';

function OfferPage({ navigation }) {
    const { user, setLoding, isLoading, setNotification } = useUserContext();
    const [amount, setAmount] = React.useState('');
    const [churchName, setChurchName] = React.useState('');

    const route = useRoute();
    const churchId = route.params;


    const makeOffer = async () => {
        if (amount == '' || amount == 0) {
            Toast.show({
                type: 'error',
                text1: "You must select amount. you can choose amount or input amount.",
            });
            return;
        }
        const token = await AsyncStorage.getItem('token');
        const headers = {
            authorization: `${token}`
        }

        let data = {
            userId: user.id,
            churchName: churchName,
            projectName: "",
            amount: amount,
            type: "Offer",
        }
        setLoding(true);

        await axios.post('https://church-backend-8690bcab1cc8.herokuapp.com/api/transaction/create_payment', data, { headers })
            .then(function (response) {
                setLoding(false);
                setNotification(true)
                Toast.show({
                    type: 'success',
                    text1: "Action Success",
                    text2: response.data.message,
                });

            })
            .catch(function (error) {
                setLoding(false);
                Toast.show({
                    type: 'error',
                    text1: "Action Success",
                    text2: error.message,
                });
            });
    }

    const getChurch = async () => {
        const token = await AsyncStorage.getItem('token');
        const headers = {
            authorization: `${token}`
        }
        await axios.get(`https://church-backend-8690bcab1cc8.herokuapp.com/api/church/get_church_detail/${churchId}`, { headers })
            .then(function (response) {
                setChurchName(response.data.church.churchName);
            })
            .catch(function (error) {
                Toast.show({
                    type: 'error',
                    text1: "Action Failed",
                    text2: error.message,
                });
            });
    }

    React.useEffect(() => {
        getChurch();
    }, []);


    return (
        <SafeAreaView style={{ flex: 1 }}>
            <CustomHeader title="Offer" navigation={navigation} />
            <View style={{ position: 'relative' }}>
                <View style={{ position: 'absolute', top: 0, zIndex: 1000, width: '100%' }}>
                    <SubHeader navigation={navigation} isWhite={true} />
                </View>
            </View>
            <ScrollView>
                <Image source={require('../../../assets/images/banner/offer-1.jpg')} style={{ height: 290, resizeMode: 'stretch' }} />
                <View style={{ paddingHorizontal: 55, paddingVertical: 30 }}>
                    <Text style={{ fontSize: 14, fontWeight: '500', color: 'black', marginBottom: 30 }}>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</Text>
                    <View>
                        <Button style={{ height: 40, borderColor: "#FE7940", borderWidth: 1, borderRadius: 50, backgroundColor: 'white', marginBottom: 20 }} textColor="#FE7940" onPress={() => setAmount('10')}>$10</Button>
                        <Button style={{ height: 40, borderColor: "#FE7940", borderWidth: 1, borderRadius: 50, backgroundColor: 'white', marginBottom: 20 }} textColor="#FE7940" onPress={() => setAmount('20')}>$20</Button>
                        <Button style={{ height: 40, borderColor: "#FE7940", borderWidth: 1, borderRadius: 50, backgroundColor: 'white', marginBottom: 20 }} textColor="#FE7940" onPress={() => setAmount('50')}>$50</Button>
                        <TextInput
                            style={{ height: 40, borderColor: "#FE7940", borderWidth: 1, borderRadius: 50, backgroundColor: 'white', marginBottom: 20, textAlign: 'center', color: '#FE7940' }}
                            onChangeText={setAmount}
                            keyboardType="numeric"
                            placeholder="Custom Amount"
                            value={amount}
                        />
                        <Button style={{ height: 40, borderColor: "#FE7940", borderWidth: 1, borderRadius: 50, backgroundColor: '#FE7940', marginBottom: 50 }} textColor="white" onPress={makeOffer}>Donate</Button>
                    </View>
                </View>
            </ScrollView>
            {isLoading && <Preloader />}
        </SafeAreaView>
    );
}

export default OfferPage;
