import React from "react";
import { ScrollView, Text, TextInput, View, Image } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import CustomHeader, { SubHeader } from "../../components/CustomHeader";
import { Button } from 'react-native-paper';
import { useRoute } from "@react-navigation/native";
import { useUserContext } from "../../context/userContext";
import Toast from 'react-native-toast-message';
import axios from 'axios';
import Preloader from "../../components/Preloader";
import AsyncStorage from '@react-native-async-storage/async-storage';

function DonatePage({ navigation }) {
  const { user, setLoding, isLoading, setNotification } = useUserContext();
  const route = useRoute();
  const { id, projectName, projectPhoto, description, churchName } = route.params;
  const [amount, setAmount] = React.useState('');

  const makeOffer = async () => {

    if (amount == '' || amount == 0) {
      Toast.show({
        type: 'error',
        text1: "You must select amount. you can choose amount or input amount.",
      });
      return;
    }

    const token = await AsyncStorage.getItem('token');
    const headers = {
      authorization: `${token}`
    }

    let data = {
      userId: user.id,
      churchName: churchName,
      projectName: projectName,
      amount: amount,
      type: "Project",
    }


    await axios.post('http://192.168.3.11:5000/api/transaction/create_payment', data, {headers})
      .then(function (response) {
        setNotification(true)
        Toast.show({
          type: 'success',
          text1: "Action",
          text2: response.data.message,
        });

      },
        { headers })
      .catch(function (error) {
        Toast.show({
          type: 'error',
          text1: "Action Error",
          text2: error.message,
        });
      });
  }

  return (
    <SafeAreaView style={{ flex: 1 }}>
      <CustomHeader title="Donate" navigation={navigation} />
      <View style={{ position: 'relative' }}>
        <View style={{ position: 'absolute', top: 0, zIndex: 1000, width: '100%' }}>
          <SubHeader navigation={navigation} isWhite={true} />
        </View>
      </View>
      <ScrollView>
        {projectPhoto != '' ? (
          <Image source={{ uri: projectPhoto }} style={{ height: 290 }} />
        ) : (
          <Image source={require('../../../assets/images/slide/3.jpg')} style={{ height: 290 }} />
        )}
        <View style={{ paddingHorizontal: 55, paddingVertical: 30 }}>
          <Text style={{ fontSize: 14, fontWeight: '500', color: 'black', marginBottom: 30 }}>{description}</Text>
          <View>
            <Button style={{ height: 40, borderColor: "#FE7940", borderWidth: 1, borderRadius: 50, backgroundColor: 'white', marginBottom: 20 }} textColor="#FE7940" onPress={() => setAmount('10')}>$10</Button>
            <Button style={{ height: 40, borderColor: "#FE7940", borderWidth: 1, borderRadius: 50, backgroundColor: 'white', marginBottom: 20 }} textColor="#FE7940" onPress={() => setAmount('20')}>$20</Button>
            <Button style={{ height: 40, borderColor: "#FE7940", borderWidth: 1, borderRadius: 50, backgroundColor: 'white', marginBottom: 20 }} textColor="#FE7940" onPress={() => setAmount('50')}>$50</Button>
            <TextInput
              style={{ height: 40, borderColor: "#FE7940", borderWidth: 1, borderRadius: 50, backgroundColor: 'white', marginBottom: 20, textAlign: 'center', color: '#FE7940' }}
              onChangeText={setAmount}
              keyboardType="numeric"
              placeholder="Custom Amount"
              value={amount}
            />
            <Button style={{ height: 40, borderColor: "#FE7940", borderWidth: 1, borderRadius: 50, backgroundColor: '#FE7940', marginBottom: 50 }} textColor="white" onPress={makeOffer}>Donate</Button>
          </View>
        </View>
      </ScrollView>
      {isLoading && <Preloader />}
    </SafeAreaView>
  );
}

export default DonatePage;
