import React from "react";
import { Text, View, ScrollView, TouchableOpacity } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import CustomHeader, { SubHeader } from "../../components/CustomHeader";
import { ChurchCard } from "../../components/Cards";
import { TextInput } from "react-native-paper";
import axios from 'axios';
import Toast from "react-native-toast-message";
import Preloader from "../../components/Preloader";
import { useUserContext } from "../../context/userContext";
import { CommonActions } from "@react-navigation/native";
import AsyncStorage from '@react-native-async-storage/async-storage';

function ChurchPage({ navigation }) {
  const { user, signIn, setLoding, isLoading, reRenderFlag, setRenderFlag } = useUserContext();

  const [churchData, setChurchData] = React.useState([]);

  const updateProfile = async (id) => {
    // setLoding(true);
    const token = await AsyncStorage.getItem('token');
    const headers = {
      authorization: `${token}`
    }
    await axios.post('https://church-backend-8690bcab1cc8.herokuapp.com/api/accounts/update_profile',
      {
        username: user?.userName,
        useremail: user?.userEmail,
        phonenumber: user?.phoneNumber,
        birth: user?.birth,
        language: user?.language,
        address: user?.address,
        church: id,
        avatarurl: user?.avatarUrl,
        status: true
      },
      { headers })
      .then(function (response) {

        signIn({
          id: response.data.user._id,
          userName: response.data.user.userName,
          userEmail: response.data.user.userEmail,
          phoneNumber: response.data.user.phoneNumber,
          birth: response.data.user.birth,
          language: response.data.user.language,
          address: response.data.user.address,
          avatarUrl: response.data.user.avatarUrl,
          church: response.data.user.church
        })
        // setLoding(false);
        setRenderFlag(!reRenderFlag);
        // navigation.navigate("HomePage");
        navigation.dispatch(
          CommonActions.reset({
            index: 0,
            routes: [
              { name: 'HomePage' },
            ],
          })
        );

      })
      .catch(function (error) {
        // setLoding(false);
        Toast.show({
          type: 'error',
          text1: "Action Failed",
          text2: error.message,
        });
      });
  }

  const getAllChurch = async () => {
    const token = await AsyncStorage.getItem('token');
    const headers = {
      authorization: `${token}`
    }
    await axios.get('https://church-backend-8690bcab1cc8.herokuapp.com/api/church/all_churches', { headers })
      .then(function (response) {
        setChurchData(response.data.church);
      })
      .catch(function (error) {
        Toast.show({
          type: 'error',
          text1: "Action Failed",
          text2: error.message,
        });
      });
  }

  React.useEffect(() => {
    getAllChurch();
  }, []);


  return (
    <SafeAreaView style={{ flex: 1 }}>
      <CustomHeader title="Churches" navigation={navigation} />
      <SubHeader navigation={navigation} />
      <View style={{ paddingHorizontal: 25, marginBottom: 30 }}>
        <TextInput
          left={<TextInput.Icon icon="magnify" color="#FE7940" />}
          style={{ borderWidth: 0, borderRadius: 12, borderBottomWidth: 0, backgroundColor: 'white', shadowColor: '#171717', shadowOffset: { width: -2, height: 4 }, shadowOpacity: 0.2, shadowRadius: 3, }}
          label="Search"
          textColor="#CBCBCB"
          underlineColor="transparent"
          right={<TextInput.Icon icon="filter-variant" />}
        />
      </View>
      <ScrollView style={{ paddingHorizontal: 25 }}>
        {churchData.map((item, index) => (
          <TouchableOpacity key={index} onPress={() => updateProfile(item._id)}>
            <ChurchCard title={item.churchName} imagePath={item.photoUrl} />
          </TouchableOpacity>
        ))}
      </ScrollView>
      {isLoading && <Preloader />}
    </SafeAreaView>
  );
}

export default ChurchPage;

