import React from "react";
import { ScrollView, Text, TouchableOpacity, View, Image } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import CustomHeader, { SubHeader } from "../../components/CustomHeader";
import axios from 'axios';
import Toast from "react-native-toast-message";
import { useRoute } from "@react-navigation/native";
import Preloader from "../../components/Preloader";
import { useUserContext } from "../../context/userContext";
import { AntDesign } from '@expo/vector-icons';

function TransactionDetailPage({ navigation }) {
  const { isLoading, setLoding } = useUserContext();

  const route = useRoute();
  const { churchName, amount, date, id, type, projectName } = route.params;

  React.useEffect(() => {
  }, [navigation])

  return (
    <SafeAreaView style={{ flex: 1 }}>
      <CustomHeader title="Transaction Detail" navigation={navigation} />
      <View style={{ position: 'relative' }}>
        <View style={{ flexDirection: "row", height: 50, justifyContent: "space-between", alignItems: 'center', paddingHorizontal: 15, position: 'absolute', zIndex: 10, width: "100%" }}>
          <View style={{ flex: 1, justifyContent: "center" }}>
            <TouchableOpacity style={{ flexDirection: 'row', alignItems: 'center' }} onPress={() => navigation.navigate('Transactions')}>
              <AntDesign name="left" size={20} color="white" /><Text style={{ fontSize: 17, color: 'white', fontWeight: '700', marginLeft: 10 }}>Back</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
      <ScrollView>
        <Image source={require('../../../assets/images/slide/3.jpg')} style={{ height: 290 }} />
        <View style={{ paddingHorizontal: 55, paddingVertical: 30 }}>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
            <Text style={{ fontSize: 16, fontWeight: '500', color: 'black', marginBottom: 20, width: 200 }} numberOfLines={1}>TransactionID: {id}</Text>
            <View style={{ backgroundColor: '#FE7940', height: 20, paddingHorizontal: 10, borderRadius: 5 }}><Text style={{ color: 'white' }}>{type}</Text></View>
          </View>
          <Text style={{ fontSize: 16, fontWeight: '500', color: 'black', marginBottom: 20 }}><Text style={{ fontWeight: 'bold', color: '#A8A7A7', fontSize: 12 }}>Church Name: </Text> {churchName}</Text>
          {
            type != "Offer" && type != "Tithe" ? (
              <Text style={{ fontSize: 16, fontWeight: '500', color: 'black', marginBottom: 20 }}><Text style={{ fontWeight: 'bold', color: '#A8A7A7', fontSize: 12 }}>Project Name: </Text> {projectName}</Text>
            ) : (<View></View>)
          }
          <Text style={{ fontSize: 16, fontWeight: '500', color: 'black', marginBottom: 20 }}><Text style={{ fontWeight: 'bold', color: '#A8A7A7', fontSize: 12 }}>Donate Amount: </Text> ${amount}</Text>
          <Text style={{ fontSize: 16, fontWeight: '500', color: 'black', marginBottom: 20 }}><Text style={{ fontWeight: 'bold', color: '#A8A7A7', fontSize: 12 }}>Donate Date and Time: </Text>{date}</Text>


        </View>
      </ScrollView>
      {isLoading && <Preloader />}
    </SafeAreaView>
  );
}

export default TransactionDetailPage;
