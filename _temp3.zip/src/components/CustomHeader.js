import React from "react";
import { Text, View, Image, TouchableOpacity } from "react-native";
import { Ionicons } from '@expo/vector-icons';
import { AntDesign } from '@expo/vector-icons';
import { Badge } from "react-native-paper";
import { useUserContext } from "../context/userContext";
import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';

export default function CustomHeader({ title, isHome, navigation }) {

  const { user, notificationFlag, setNotification } = useUserContext();
  const [notificationData, setNotificationData] = React.useState([]);
  const getNotification = async () => {
    const token = await AsyncStorage.getItem('token');
    const headers = {
      authorization: `${token}`
    }
    await axios.get(`https://church-backend-8690bcab1cc8.herokuapp.com/api/accounts/get_user/${user?.id}`, { headers })
      .then(function (response) {
        setNotificationData(response.data.user.unReadCount);
      })
      .catch(function (error) {
      });
  }

  const checkArray = (arr) => {
    return arr.flat().includes(false);
  }

  React.useEffect(() => {
    if (notificationData == 0) {
      setNotification(false);
    } else {
      setNotification(true);
    }
  }, [notificationData]);

  React.useEffect(() => {
    const getData = navigation.addListener('focus', () => {
      getNotification();
    });
    return getData;
  }, [navigation]);

  return (
    <View style={{ flexDirection: "row", height: 50, justifyContent: "space-between", alignItems: 'center', paddingHorizontal: 15 }}>
      <View style={{ flex: 1, justifyContent: "center" }}>
        <TouchableOpacity style={{ flex: 1, justifyContent: "center" }} onPress={() => navigation.openDrawer()}>
          <Ionicons name="menu" size={35} color="#FE7940" />
        </TouchableOpacity>
      </View>
      <View style={{ flex: 1, justifyContent: "center" }}>
        <Text style={{ textAlign: "center", fontSize: 18, fontWeight: 'bold' }}>{title}</Text>
      </View>
      <View style={{ flex: 1, justifyContent: "center", alignItems: "flex-end" }}>
        <TouchableOpacity style={{ flex: 1, justifyContent: "center", position: 'relative' }} onPress={() => navigation.navigate("Notifications")}>
          {/* <Ionicons name="notifications-outline" size={30} color="#FE7940" /> */}
          {notificationFlag == false ? <Ionicons name="notifications-outline" size={30} color="#FE7940" /> : <Ionicons name="notifications-sharp" size={30} color="#FE7940" />}
        </TouchableOpacity>
      </View>
    </View>
  );
}

export const SubHeader = ({ navigation, isWhite }) => {
  return (
    <View style={{ flexDirection: "row", height: 50, justifyContent: "space-between", alignItems: 'center', paddingHorizontal: 15 }}>
      <View style={{ flex: 1, justifyContent: "center" }}>
        {isWhite ? (
          <TouchableOpacity style={{ flexDirection: 'row', alignItems: 'center' }} onPress={() => navigation.goBack()}>
            <AntDesign name="left" size={20} color="white" /><Text style={{ fontSize: 17, color: 'white', fontWeight: '700', marginLeft: 10 }}>Back</Text>
          </TouchableOpacity>
        ) : (
          <TouchableOpacity style={{ flexDirection: 'row', alignItems: 'center' }} onPress={() => navigation.goBack()}>
            <AntDesign name="left" size={20} color="#474747" /><Text style={{ fontSize: 17, color: '#474747', fontWeight: '700', marginLeft: 10 }}>Back</Text>
          </TouchableOpacity>
        )}
      </View>
    </View>
  )
}
