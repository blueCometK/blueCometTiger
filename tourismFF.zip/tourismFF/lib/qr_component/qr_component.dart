import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:qr_code_scanner/qr_code_scanner.dart';
import '/auth/firebase_auth/auth_util.dart';
import '../app_state.dart';
import '../qr_response.dart';

class QRCodeReader extends StatefulWidget {
  const QRCodeReader({super.key});

  @override
  State<QRCodeReader> createState() => _QRCodeReaderState();
}

class _QRCodeReaderState extends State<QRCodeReader> {
  final qrKey = GlobalKey(debugLabel: "QR");
  //late LoanProvider loanProvider;
  QRViewController? qrViewController;
  bool isRequesting = true;

  @override
  void dispose() {
    qrViewController?.dispose();
    super.dispose();
  }

  @override
  void reassemble() async {
    super.reassemble();

    if (Platform.isAndroid) {
      await qrViewController!.pauseCamera();
    }

    qrViewController!.resumeCamera();
  }

  @override
  Widget build(BuildContext context) {
    if (qrViewController != null && mounted) {
      qrViewController!.pauseCamera();
      qrViewController!.resumeCamera();
    }
    Size window = MediaQuery.of(context).size;
    //loanProvider = Provider.of<LoanProvider>(context, listen: false);
    return Scaffold(
      body: Stack(
        children: [
          QRView(
            key: qrKey,
            overlay: QrScannerOverlayShape(
              cutOutWidth: window.width * 0.8,
              cutOutHeight: window.width * 0.8,
              borderWidth: 10.0,
              borderLength: 20.0,
            ),
            onQRViewCreated: (QRViewController controller) {
              setState(() {
                qrViewController = controller;
              });

              controller.scannedDataStream.listen((Barcode barcode) async {
                try {
                  if(isRequesting){
                    setState(() {
                      isRequesting = false;
                    });
                    print(barcode.code as String);
                    FFAppState().setDecryptString = barcode.code as String;

                    if(FFAppState().getDecryptString != null){

                      Navigator.pop(context,'Decrypt!');
                      //Navigator.pop(context);

                    }
                  }

                } catch (e) {
                  isRequesting = true;
                  print(e);
                }
              });
            },
          ),
          Positioned(
            top: 100.0,
            right: 30.0,
            child: SizedBox(
              height: 50,
              width: 50,
              child: IconButton(
                icon: Icon(
                    Icons.cancel_presentation_outlined,
                  size: 40,
                  color: Colors.white,

                ),
                onPressed: () {
                  Navigator.pop(context);
                     },
              ),
            ),
          ),
        ],
      ),
    );
  }
}
