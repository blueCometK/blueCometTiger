import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:geolocator/geolocator.dart';
import 'package:location/location.dart' as loc;
import 'package:permission_handler/permission_handler.dart';
import 'package:tourism/qr_response.dart';
import '../../backend/backend.dart';
import '../../backend/schema/campaigns_record.dart';
import '../../backend/schema/checkin_record.dart';
import '../../backend/schema/util/firestore_util.dart';
import '../../pages/baseMap/base_map.dart';
import '../../qr_component/qr_component.dart';
import '../../qr_response.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'show_bottom_nav_model.dart';
import '/flutter_flow/flutter_flow_util.dart';
export 'show_bottom_nav_model.dart';
import 'package:latlong2/latlong.dart' as latlng2 ;
import '/auth/firebase_auth/auth_util.dart';
import '/flutter_flow/flutter_flow_util.dart';

class ShowBottomNavWidget extends StatefulWidget {
  const ShowBottomNavWidget({
    Key? key,
    required this.isQRRequired,
    required this.document,
  }) : super(key: key);

  final bool isQRRequired;
  final CampaignsRecord? document;

  @override
  _ShowBottomNavWidgetState createState() => _ShowBottomNavWidgetState();
}

class _ShowBottomNavWidgetState extends State<ShowBottomNavWidget> {
  late ShowBottomNavModel _model;
  final geoLocator = GeolocatorPlatform.instance;
  QrResponse? qrResponse = QrResponse(
    key: "djkkk34343jejjeeeee",
    supportNumber: "+1227743666333",
    accountNumber: "21737474",
    campaignCode: "CAMCODE",
    campaignName: "CAMNAME",
  );

  Position? _currentPosition;
  double? _distance;
  loc.LocationData? currentLocation2;
  bool scanned = false;
  bool pressed = false;
  bool pressedCase2 = false;
  bool pressedCase3 = false;
  bool permissionDenied = false;
  bool requiresScan = false;
  int index = 0;
  final loc.Location location = loc.Location();

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  Future<void> _getCurrentLocation() async {
    try {
      loc.LocationAccuracy locationAccuracy = loc.LocationAccuracy.high;
      await location.changeSettings(accuracy: locationAccuracy);

      var status = await Permission.location.status;
      if(status.isGranted){
        var currentLocation = await location.getLocation();
        print(currentLocation.latitude);
        print(currentLocation.longitude);
        // Position position = await geoLocator.getCurrentPosition(
        //     locationSettings: LocationSettings(
        //       accuracy: LocationAccuracy.best,
        //     )
        // );
        setState(() {
          currentLocation2 = currentLocation;
          //_currentPosition = position;
          _calculateDistance(widget.document!.latitude!.latitude,widget.document!.latitude!.longitude);
        });
      }
      else if(status.isDenied){
        if(await Permission.location.request().isGranted){
          // Position position = await geoLocator.getCurrentPosition(
          //     locationSettings: LocationSettings(
          //       accuracy: LocationAccuracy.best,
          //     )
          // );
          var currentLocation = await location.getLocation();
          print(currentLocation.latitude);
          print(currentLocation.longitude);

          // Position position = await geoLocator.getCurrentPosition(
          //     locationSettings: LocationSettings(
          //       accuracy: LocationAccuracy.best,
          //     )
          // );
          setState(() {
            currentLocation2 = currentLocation;
            //_currentPosition = position;
            _calculateDistance(widget.document!.latitude!.latitude,widget.document!.latitude!.longitude);
          });
        }
        else{
          setState(() {
            permissionDenied = true;
          });
          showSnackBarText('You need to give this app location permission to continue', context, false);
        }
      }
      else{
        if(await Permission.location.request().isGranted){
          // Position position = await geoLocator.getCurrentPosition(
          //     locationSettings: LocationSettings(
          //       accuracy: LocationAccuracy.high,
          //     )
          // );
          // setState(() {
          //   _currentPosition = position;
          //   _calculateDistance(widget.document!.latitude!.latitude,widget.document!.latitude!.longitude);
          // });
          var currentLocation = await location.getLocation();
          print(currentLocation.latitude);
          print(currentLocation.longitude);

          // Position position = await geoLocator.getCurrentPosition(
          //     locationSettings: LocationSettings(
          //       accuracy: LocationAccuracy.best,
          //     )
          // );
          setState(() {
            currentLocation2 = currentLocation;
            //_currentPosition = position;
            _calculateDistance(widget.document!.latitude!.latitude,widget.document!.latitude!.longitude);
          });
        }
        else{
          print(status);
          setState(() {
            permissionDenied = true;
          });
          showSnackBarText('You need to give this app location permission to continue', context, false);
        }
      }

    } catch (e) {
      print('Error getting current location: $e');
    }
  }
  void _calculateDistance(double centerLatitude, double centerLongitude) async {
    if (currentLocation2 != null) {
      double distance =  geoLocator.distanceBetween(
        currentLocation2!.latitude!,
        currentLocation2!.longitude!,
        centerLatitude,
        centerLongitude,
      );
      setState(() {
        _distance = distance * 3.28;
      });
      if((!widget.document!.qRCodeAvailable || !widget.document!.requiresQRScan) && _distance! < getRemoteConfigDouble('distance'))
      {
        await currentUserReference!.update({
        ...mapToFirestore(
        {
        'checkedCampains': FieldValue.arrayUnion(
        [widget.document?.reference]),
        },
        ),
        });
      }

    }
  }
  void showSnackBarText(String text, BuildContext context, bool success){
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(text,style: TextStyle(color: Colors.white),),
        backgroundColor: success ? Colors.green : Colors.redAccent, duration: Duration(seconds: 2, milliseconds: 500),
      ),
    );
  }
  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => ShowBottomNavModel());
    requiresScan = widget.isQRRequired;
    _getCurrentLocation();
  }
  String shortenDistance(double distance) {
    String result;
    print(distance);
    if (distance >= 1000000) {
      double shortened = distance / 1000000;
      result = shortened.toStringAsFixed(1) + 'M ft';
    } else if (distance >= 1000) {
      double shortened = distance / 1000;
      result = shortened.toStringAsFixed(1) + 'K ft';
    } else {
      result = distance.toStringAsFixed(1) + 'ft';
    }
    return result;
  }
  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    context.watch<FFAppState>();
    return Material(
      color: Colors.transparent,
      elevation: 5.0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.only(
          bottomLeft: Radius.circular(0.0),
          bottomRight: Radius.circular(0.0),
          topLeft: Radius.circular(16.0),
          topRight: Radius.circular(16.0),
        ),
      ),
      child: Container(
        width: double.infinity,
        height: MediaQuery.sizeOf(context).height * 0.5,
        decoration: BoxDecoration(
          color: FlutterFlowTheme.of(context).secondaryBackground,
          borderRadius: BorderRadius.only(
            bottomLeft: Radius.circular(0.0),
            bottomRight: Radius.circular(0.0),
            topLeft: Radius.circular(16.0),
            topRight: Radius.circular(16.0),
          ),
        ),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.max,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisSize: MainAxisSize.max,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Padding(
                    padding:
                        EdgeInsetsDirectional.fromSTEB(0.0, 12.0, 0.0, 0.0),
                    child: Container(
                      width: 50.0,
                      height: 4.0,
                      decoration: BoxDecoration(
                        color: FlutterFlowTheme.of(context).alternate,
                        borderRadius: BorderRadius.circular(8.0),
                      ),
                    ),
                  ),
                ],
              ),
              if(!widget.document!.qRCodeAvailable)
                if ((currentUserDocument?.checkedCampains?.toList() ?? [])
                    .contains(widget.document!.reference) ==
                    false)
                  Column(
                    children: [
                      Padding(
                        padding: EdgeInsetsDirectional.fromSTEB(0.0, 10.0, 0.0, 0.0),
                        child: Container(
                          width: MediaQuery.sizeOf(context).width * 0.8,
                          child: Center(
                            child: Text(
                              _distance == null ? 'Let’s Check you in!' : _distance! < getRemoteConfigDouble('distance') ? 'You’re Checked In!' : 'You’re Not Close…',
                              style: FlutterFlowTheme.of(context).headlineMedium.override(
                                  fontFamily: 'Open Sans',
                                  fontWeight: FontWeight.w700,
                                  fontSize: 20
                              ),
                              textAlign: TextAlign.center,
                            ),
                          ),
                        ),
                      ),
                      Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(0.0, 10.0, 0.0, 10.0),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(
                                'Checking current location:  ',
                                style: FlutterFlowTheme.of(context)
                                    .bodyMedium
                                    .override(
                                    fontFamily: 'Readex Pro',
                                    fontSize: 14.0,
                                    color:Colors.black.withOpacity(0.4)
                                ),
                              ),
                              SizedBox(
                                width: 5,
                              ),
                              if(permissionDenied )
                                Text(
                                  'Permission Denied',
                                  style: FlutterFlowTheme.of(context)
                                      .bodyMedium
                                      .override(
                                      fontFamily: 'Readex Pro',
                                      fontSize: 14.0,
                                      color: Colors.red
                                  ),
                                ),
                              if (_distance != null)
                                Text(
                                  '${shortenDistance(_distance!)}',
                                  style: FlutterFlowTheme.of(context)
                                      .bodyMedium
                                      .override(
                                      fontFamily: 'Readex Pro',
                                      fontSize: 14.0,
                                      color: _distance! > getRemoteConfigDouble('distance')? Colors.red : Colors.green
                                  ),
                                ),
                              if (_distance == null && !permissionDenied)
                                SizedBox(
                                  height: 20,
                                  width: 20,
                                  child: CircularProgressIndicator(
                                    color: Colors.black,
                                  ),
                                )
                            ],
                          )
                      ),
                      if (_distance != null)
                        if(_distance! > getRemoteConfigDouble('distance'))
                          Align(
                            alignment: AlignmentDirectional(0.00, 0.00),
                            child: Padding(
                              padding: EdgeInsetsDirectional.fromSTEB(
                                  0.0, 10.0, 0.0, 10.0),
                              child: FFButtonWidget(
                                onPressed: () {
                                  currentLocation2 = null;
                                  _distance = null;
                                  setState(() {
                                    //index++;
                                  });
                                  _getCurrentLocation();
                                },
                                text: 'Check In Again',
                                options: FFButtonOptions(
                                  width:
                                  MediaQuery.sizeOf(context).width *
                                      0.8,
                                  height: 45.0,
                                  padding: EdgeInsetsDirectional.fromSTEB(
                                      0.0, 0.0, 0.0, 0.0),
                                  iconPadding: EdgeInsetsDirectional.fromSTEB(
                                      0.0, 0.0, 0.0, 0.0),
                                  color: Color(0xff2596be),
                                  textStyle: FlutterFlowTheme.of(context)
                                      .titleSmall
                                      .override(
                                    fontFamily: 'Readex Pro',
                                    color: Colors.white,
                                  ),
                                  elevation: 3.0,
                                  borderSide: BorderSide(
                                    color: Colors.transparent,
                                    width: 1.0,
                                  ),
                                  borderRadius:
                                  BorderRadius.circular(12.0),
                                ),
                              ),
                            ),
                          ),
                      if (_distance != null)
                        if(_distance! < getRemoteConfigDouble('distance'))
                          Align(
                            alignment: AlignmentDirectional(0.00, 0.00),
                            child: Padding(
                              padding: EdgeInsetsDirectional.fromSTEB(
                                  0.0, 10.0, 0.0, 10.0),
                              child: FFButtonWidget(
                                onPressed: () {
                                  Navigator.pop(context);
                                },
                                text: 'You’re In',
                                options: FFButtonOptions(
                                  width:
                                  MediaQuery.sizeOf(context).width *
                                      0.8,
                                  height: 45.0,
                                  padding: EdgeInsetsDirectional.fromSTEB(
                                      0.0, 0.0, 0.0, 0.0),
                                  iconPadding: EdgeInsetsDirectional.fromSTEB(
                                      0.0, 0.0, 0.0, 0.0),
                                  color: Color(0xff2596be),
                                  textStyle: FlutterFlowTheme.of(context)
                                      .titleSmall
                                      .override(
                                    fontFamily: 'Readex Pro',
                                    color: Colors.white,
                                  ),
                                  elevation: 3.0,
                                  borderSide: BorderSide(
                                    color: Colors.transparent,
                                    width: 1.0,
                                  ),
                                  borderRadius:
                                  BorderRadius.circular(12.0),
                                ),
                              ),
                            ),
                          ),
                      if (currentLocation2 == null)
                        Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(
                              0.0, 30.0, 0.0, 0.0),
                          child: Center(
                            child: SizedBox(
                              height: 40,
                              width: 40,
                              child: CircularProgressIndicator(
                                color: Colors.black,
                              ),
                            ),
                          ),
                        ),
                      if(currentLocation2 != null)
                        Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(
                              0.0, 15.0, 0.0, 0.0),
                          child: Center(
                            child: SizedBox(
                                width: MediaQuery.sizeOf(context).width * 0.9,
                                height: 330,
                                child:  BaseMap(loc: latlng2.LatLng(currentLocation2!.latitude!,currentLocation2!.longitude!) ,)),
                          ),
                        ),
                    ],
                  ),
              if ((currentUserDocument?.checkedCampains?.toList() ?? [])
                  .contains(widget.document!.reference) ==
                  true)
                  StreamBuilder<List<CheckinRecord>>(
                  stream: queryCheckinRecord(
                  parent: currentUserReference,
                  queryBuilder: (checkinRecord) => checkinRecord.where(
                    'campaignRef',
                    isEqualTo: widget.document!.reference,
                  ),
                  singleRecord: true,
                ),
                builder: (context, snapshot) {
                  // Customize what your widget looks like when it's loading.
                  if (!snapshot.hasData) {
                    return Center(
                      child: SizedBox(
                        width: 50.0,
                        height: 50.0,
                        child: CircularProgressIndicator(
                          valueColor: AlwaysStoppedAnimation<Color>(
                            FlutterFlowTheme.of(context).primary,
                          ),
                        ),
                      ),
                    );
                  }
                  List<CheckinRecord> createNoteCheckinRecordList = snapshot.data!;
                  // Return an empty Container when the item does not exist.
                  if (snapshot.data!.isEmpty) {
                    return Container();
                  }
                  final createNoteCheckinRecord = createNoteCheckinRecordList.isNotEmpty
                      ? createNoteCheckinRecordList.first
                      : null;
                  return Column(
                    children: [
                      Padding(
                        padding: EdgeInsetsDirectional.fromSTEB(0.0, 10.0, 0.0, 0.0),
                        child: Container(
                          width: MediaQuery.sizeOf(context).width * 0.8,
                          child: Center(
                            child: Text(
                              'You’re Checked In!',
                              style: FlutterFlowTheme.of(context).headlineMedium.override(
                                  fontFamily: 'Open Sans',
                                  fontWeight: FontWeight.w700,
                                  fontSize: 20
                              ),
                              textAlign: TextAlign.center,
                            ),
                          ),
                        ),
                      ),
                      Align(
                        alignment: AlignmentDirectional(0.00, 0.00),
                        child: Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(
                              0.0, 10.0, 0.0, 10.0),
                          child: FFButtonWidget(
                            onPressed: () {
                              Navigator.pop(context);
                            },
                            text: 'You’re In',
                            options: FFButtonOptions(
                              width:
                              MediaQuery.sizeOf(context).width *
                                  0.8,
                              height: 45.0,
                              padding: EdgeInsetsDirectional.fromSTEB(
                                  0.0, 0.0, 0.0, 0.0),
                              iconPadding: EdgeInsetsDirectional.fromSTEB(
                                  0.0, 0.0, 0.0, 0.0),
                              color: Color(0xff2596be),
                              textStyle: FlutterFlowTheme.of(context)
                                  .titleSmall
                                  .override(
                                fontFamily: 'Readex Pro',
                                color: Colors.white,
                              ),
                              elevation: 3.0,
                              borderSide: BorderSide(
                                color: Colors.transparent,
                                width: 1.0,
                              ),
                              borderRadius:
                              BorderRadius.circular(12.0),
                            ),
                          ),
                        ),
                      ),
                      if(currentLocation2 != null)
                        Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(
                              0.0, 15.0, 0.0, 0.0),
                          child: Center(
                            child: SizedBox(
                                width: MediaQuery.sizeOf(context).width * 0.9,
                                height: 330,
                                child:  BaseMap(loc: latlng2.LatLng(currentLocation2!.latitude!,currentLocation2!.longitude!) ,)),
                          ),
                        ),
                    ],
                  );
                },
              ),
              if(widget.document!.qRCodeAvailable)
                if(!widget.document!.requiresQRScan)
                  Column(
                    children: [
                      if (currentLocation2 == null)
                        Column(
                          children: [
                            Padding(
                              padding: EdgeInsetsDirectional.fromSTEB(0.0, 10.0, 0.0, 0.0),
                              child: Column(
                                children: [
                                  Container(
                                    width: MediaQuery.sizeOf(context).width * 0.8,
                                    child: Center(
                                      child: Text(
                                        _distance == null ? 'Let’s Check you in!' : _distance! < getRemoteConfigDouble('distance') ? 'You’re Close Enough!' : 'You’re Not Close…',
                                        style: FlutterFlowTheme.of(context).headlineMedium.override(
                                            fontFamily: 'Open Sans',
                                            fontWeight: FontWeight.w700,
                                            fontSize: 20
                                        ),
                                        textAlign: TextAlign.center,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Padding(
                                padding: EdgeInsetsDirectional.fromSTEB(0.0, 10.0, 0.0, 10.0),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Text(
                                      'Checking current location:  ',
                                      style: FlutterFlowTheme.of(context)
                                          .bodyMedium
                                          .override(
                                          fontFamily: 'Readex Pro',
                                          fontSize: 14.0,
                                          color:Colors.black.withOpacity(0.4)
                                      ),
                                    ),
                                    SizedBox(
                                      width: 5,
                                    ),
                                    if(permissionDenied)
                                      Text(
                                        'Permission Denied',
                                        style: FlutterFlowTheme.of(context)
                                            .bodyMedium
                                            .override(
                                            fontFamily: 'Readex Pro',
                                            fontSize: 14.0,
                                            color: Colors.red
                                        ),
                                      ),
                                    if (_distance != null)
                                      Text(
                                        '${shortenDistance(_distance!)}',
                                        style: FlutterFlowTheme.of(context)
                                            .bodyMedium
                                            .override(
                                            fontFamily: 'Readex Pro',
                                            fontSize: 14.0,
                                            color: _distance! > getRemoteConfigDouble('distance')? Colors.red : Colors.green
                                        ),
                                      ),
                                    if (_distance == null && !permissionDenied)
                                      SizedBox(
                                        height: 20,
                                        width: 20,
                                        child: CircularProgressIndicator(
                                          color: Colors.black,
                                        ),
                                      )
                                  ],
                                )
                            ),
                            Padding(
                              padding: EdgeInsetsDirectional.fromSTEB(
                                  0.0, 30.0, 0.0, 0.0),
                              child: Center(
                                child: SizedBox(
                                  height: 40,
                                  width: 40,
                                  child: CircularProgressIndicator(
                                    color: Colors.black,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      if (_distance != null)
                        Padding(
                        padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
                        child: Container(
                          width: double.infinity,
                          decoration: BoxDecoration(
                            color: FlutterFlowTheme.of(context).secondaryBackground,
                          ),
                          child: Column(
                            mainAxisSize: MainAxisSize.max,
                            children: [
                              if(_distance! < getRemoteConfigDouble('distance'))
                                Padding(
                                  padding: EdgeInsetsDirectional.fromSTEB(
                                      0.0, 0.0, 0.0, 0.0),
                                  child: Column(
                                    mainAxisSize: MainAxisSize.max,
                                    children: [
                                      Padding(
                                        padding: EdgeInsetsDirectional.fromSTEB(0.0, 10.0, 0.0, 0.0),
                                        child: Column(
                                          children: [
                                            Container(
                                              width: MediaQuery.sizeOf(context).width * 0.8,
                                              child: Center(
                                                child: Text(
                                                  _distance == null ? 'Let’s Check you in!' : _distance! < getRemoteConfigDouble('distance') ? 'You’re Close Enough!' : 'You’re Not Close…',
                                                  style: FlutterFlowTheme.of(context).headlineMedium.override(
                                                      fontFamily: 'Open Sans',
                                                      fontWeight: FontWeight.w700,
                                                      fontSize: 20
                                                  ),
                                                  textAlign: TextAlign.center,
                                                ),
                                              ),
                                            ),
                                            if (currentLocation2 != null)
                                              Container(
                                                width: MediaQuery.sizeOf(context).width * 0.8,
                                                child: Center(
                                                  child: Text(
                                                    'Want to scan the QR code?',
                                                    style: FlutterFlowTheme.of(context).headlineMedium.override(
                                                        fontFamily: 'Open Sans',
                                                        fontWeight: FontWeight.w400,
                                                        fontSize: 14
                                                    ),
                                                    textAlign: TextAlign.center,
                                                  ),
                                                ),
                                              ),
                                          ],
                                        ),
                                      ),
                                      Padding(
                                          padding: EdgeInsetsDirectional.fromSTEB(0.0, 10.0, 0.0, 10.0),
                                          child: Row(
                                            mainAxisAlignment: MainAxisAlignment.center,
                                            children: [
                                              Text(
                                                'Checking current location:  ',
                                                style: FlutterFlowTheme.of(context)
                                                    .bodyMedium
                                                    .override(
                                                    fontFamily: 'Readex Pro',
                                                    fontSize: 14.0,
                                                    color:Colors.black.withOpacity(0.4)
                                                ),
                                              ),
                                              SizedBox(
                                                width: 5,
                                              ),
                                              if(permissionDenied )
                                                Text(
                                                  'Permission Denied',
                                                  style: FlutterFlowTheme.of(context)
                                                      .bodyMedium
                                                      .override(
                                                      fontFamily: 'Readex Pro',
                                                      fontSize: 14.0,
                                                      color: Colors.red
                                                  ),
                                                ),
                                              if (_distance != null)
                                                Text(
                                                  '${shortenDistance(_distance!)}',
                                                  style: FlutterFlowTheme.of(context)
                                                      .bodyMedium
                                                      .override(
                                                      fontFamily: 'Readex Pro',
                                                      fontSize: 14.0,
                                                      color: _distance! > getRemoteConfigDouble('distance')? Colors.red : Colors.green
                                                  ),
                                                ),
                                              if (_distance == null && !permissionDenied)
                                                SizedBox(
                                                  height: 20,
                                                  width: 20,
                                                  child: CircularProgressIndicator(
                                                    color: Colors.black,
                                                  ),
                                                )
                                            ],
                                          )
                                      ),
                                      // Row(
                                      //   mainAxisAlignment: MainAxisAlignment.center,
                                      //   children: [
                                      //     Align(
                                      //       alignment: AlignmentDirectional(0.00, 0.00),
                                      //       child: Padding(
                                      //         padding: EdgeInsetsDirectional.fromSTEB(
                                      //             0.0, 10.0, 0.0, 10.0),
                                      //         child: FFButtonWidget(
                                      //           onPressed: () {
                                      //             currentLocation2 = null;
                                      //             _distance = null;
                                      //             setState(() {
                                      //               //index++;
                                      //               pressedCase2 = true;
                                      //             });
                                      //             _getCurrentLocation();
                                      //           },
                                      //           text: 'Try Location Again',
                                      //           options: FFButtonOptions(
                                      //             width:
                                      //             MediaQuery.sizeOf(context).width *
                                      //                 0.4,
                                      //             height: 45.0,
                                      //             padding: EdgeInsetsDirectional.fromSTEB(
                                      //                 0.0, 0.0, 0.0, 0.0),
                                      //             iconPadding:
                                      //             EdgeInsetsDirectional.fromSTEB(
                                      //                 0.0, 0.0, 0.0, 0.0),
                                      //             color: Color(0xff2596be),
                                      //             textStyle: FlutterFlowTheme.of(context)
                                      //                 .titleSmall
                                      //                 .override(
                                      //               fontFamily: 'Readex Pro',
                                      //               color: Colors.white,
                                      //             ),
                                      //             elevation: 3.0,
                                      //             borderSide: BorderSide(
                                      //               color: Colors.transparent,
                                      //               width: 1.0,
                                      //             ),
                                      //             borderRadius:
                                      //             BorderRadius.circular(12.0),
                                      //           ),
                                      //         ),
                                      //       ),
                                      //     ),
                                      //     Align(
                                      //       alignment: AlignmentDirectional(0.00, 0.00),
                                      //       child: Padding(
                                      //         padding: EdgeInsetsDirectional.fromSTEB(
                                      //             0.0, 10.0, 0.0, 10.0),
                                      //         child: FFButtonWidget(
                                      //           onPressed: () {
                                      //             currentLocation2 = null;
                                      //             _distance = null;
                                      //             setState(() {
                                      //               //index++;
                                      //               pressedCase2 = true;
                                      //             });
                                      //             _getCurrentLocation();
                                      //           },
                                      //           text: 'Scan QR Code \n(Optional)',
                                      //           options: FFButtonOptions(
                                      //             width:
                                      //             MediaQuery.sizeOf(context).width *
                                      //                 0.4,
                                      //             //height: 45.0,
                                      //             padding: EdgeInsetsDirectional.fromSTEB(
                                      //                 0.0, 0.0, 0.0, 0.0),
                                      //             iconPadding:
                                      //             EdgeInsetsDirectional.fromSTEB(
                                      //                 0.0, 0.0, 0.0, 0.0),
                                      //             color: Color(0xff96c93e),
                                      //             textStyle: FlutterFlowTheme.of(context)
                                      //                 .titleSmall
                                      //                 .override(
                                      //               fontFamily: 'Readex Pro',
                                      //               color: Colors.white,
                                      //             ),
                                      //             elevation: 3.0,
                                      //             borderSide: BorderSide(
                                      //               color: Colors.transparent,
                                      //               width: 1.0,
                                      //             ),
                                      //             borderRadius:
                                      //             BorderRadius.circular(12.0),
                                      //           ),
                                      //         ),
                                      //       ),
                                      //     ),
                                      //   ],
                                      // ),
                                      Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                        children: [
                                          Align(
                                            alignment: AlignmentDirectional(0.00, 0.00),
                                            child: Padding(
                                                padding: EdgeInsetsDirectional.fromSTEB(
                                                    0.0, 10.0, 0.0, 10.0),
                                                child: InkWell(
                                                  splashColor: Colors.transparent,
                                                  focusColor: Colors.transparent,
                                                  hoverColor: Colors.transparent,
                                                  highlightColor: Colors.transparent,
                                                  onTap: (){
                                                    Navigator.pop(context);
                                                  },
                                                  child: Container(
                                                    width: MediaQuery.sizeOf(context).width * 0.4,
                                                    height: 45,
                                                    decoration: BoxDecoration(
                                                      borderRadius:
                                                      BorderRadius.circular(12.0),
                                                      color: Color(0xff2596be),
                                                    ),
                                                    child: Center(
                                                      child: Text('You’re In',style: TextStyle(
                                                          fontSize: 15,
                                                          color: Colors.white,
                                                          fontWeight: FontWeight.w600
                                                      ),textAlign: TextAlign.center,),
                                                    ),
                                                  ),
                                                )
                                            ),
                                          ),
                                          Align(
                                            alignment: AlignmentDirectional(0.00, 0.00),
                                            child: Padding(
                                                padding: EdgeInsetsDirectional.fromSTEB(
                                                    0.0, 10.0, 0.0, 10.0),
                                                child: InkWell(
                                                  splashColor: Colors.transparent,
                                                  focusColor: Colors.transparent,
                                                  hoverColor: Colors.transparent,
                                                  highlightColor: Colors.transparent,
                                                  onTap: ()async{
                                                    final result = await Navigator.push(
                                                      context,
                                                      PageRouteBuilder(
                                                        pageBuilder: (_, __, ___) => QRCodeReader(),
                                                        transitionsBuilder: (_, a1, a2, child) =>
                                                            SlideTransition(
                                                              position: Tween(
                                                                  begin: Offset(1, 0),
                                                                  end: Offset(0, 0))
                                                                  .animate(a1),
                                                              child: child,
                                                            ),
                                                      ),
                                                    );

                                                    if (!mounted) return;

                                                    if (result == 'Decrypt!') {
                                                      openDialog();
                                                      await currentUserReference!.update({
                                                        ...mapToFirestore(
                                                          {
                                                            'checkedCampains': FieldValue.arrayUnion(
                                                                [widget.document?.reference]),
                                                          },
                                                        ),
                                                      });
                                                      Timer(Duration(seconds: 4), () {
                                                        Navigator.of(context).pop();
                                                        Navigator.of(context).pop();
                                                        showSnackBarText('QR Code read successfully!', context, true);
                                                      });
                                                    }
                                                  },
                                                  child: Container(
                                                    width: MediaQuery.sizeOf(context).width * 0.4,
                                                    height: 45,
                                                    decoration: BoxDecoration(
                                                      borderRadius:
                                                      BorderRadius.circular(12.0),
                                                      color: Color(0xff96c93e),
                                                    ),
                                                    child: Center(
                                                      child: Text('Scan QR Code \n(Optional)',style: TextStyle(
                                                          color: Colors.white,
                                                          fontSize: 15,
                                                          fontWeight: FontWeight.w600
                                                      ),textAlign: TextAlign.center,),
                                                    ),
                                                  ),
                                                )
                                            ),
                                          ),
                                        ],
                                      ),
                                      Padding(
                                        padding: EdgeInsetsDirectional.fromSTEB(
                                            0.0, 15.0, 0.0, 0.0),
                                        child: Center(
                                          child: SizedBox(
                                              width: MediaQuery.sizeOf(context).width * 0.9,
                                              height: 330,
                                              child:  BaseMap(loc: latlng2.LatLng(currentLocation2!.latitude!,currentLocation2!.longitude!) ,)),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              // Padding(
                                //   padding: EdgeInsetsDirectional.fromSTEB(
                                //       15.0, 15.0, 15.0, 15.0),
                                //   child: Column(
                                //     mainAxisSize: MainAxisSize.max,
                                //     children: [
                                //       Padding(
                                //         padding: EdgeInsetsDirectional.fromSTEB(
                                //             0.0, 0.0, 0.0, 0.0),
                                //         child: Container(
                                //           width:
                                //           MediaQuery.sizeOf(context).width * 0.8,
                                //           decoration: BoxDecoration(
                                //             color: FlutterFlowTheme.of(context)
                                //                 .secondaryBackground,
                                //           ),
                                //           child: Text(
                                //             'Want to get extra points? \n find and scan the QR Code',
                                //             textAlign: TextAlign.center,
                                //             style: FlutterFlowTheme.of(context)
                                //                 .bodyMedium
                                //                 .override(
                                //               fontFamily: 'Readex Pro',
                                //               fontSize: 20.0,
                                //               fontWeight: FontWeight.w500,
                                //             ),
                                //           ),
                                //         ),
                                //       ),
                                //       Padding(
                                //         padding: EdgeInsetsDirectional.fromSTEB(
                                //             0.0, 20.0, 0.0, 0.0),
                                //         child: Row(
                                //           mainAxisSize: MainAxisSize.max,
                                //           mainAxisAlignment:
                                //           MainAxisAlignment.spaceAround,
                                //           children: [
                                //             Align(
                                //               alignment:
                                //               AlignmentDirectional(0.00, 0.00),
                                //               child: FFButtonWidget(
                                //                 onPressed: () async{
                                //                   final result = await Navigator.push(
                                //                     context,
                                //                     PageRouteBuilder(
                                //                       pageBuilder: (_, __, ___) => QRCodeReader(),
                                //                       transitionsBuilder: (_, a1, a2, child) =>
                                //                           SlideTransition(
                                //                             position: Tween(
                                //                                 begin: Offset(1, 0),
                                //                                 end: Offset(0, 0))
                                //                                 .animate(a1),
                                //                             child: child,
                                //                           ),
                                //                     ),
                                //                   );
                                //
                                //                   if (!mounted) return;
                                //
                                //                   if (result == 'Decrypt!') {
                                //                     openDialog();
                                //                     //   await currentUserReference!.update({
                                //                     // ...mapToFirestore(
                                //                     // {
                                //                     // 'checkedCampains': FieldValue.arrayUnion(
                                //                     // [widget.document?.reference]),
                                //                     // },
                                //                     // ),
                                //                     // });
                                //                     Timer(Duration(seconds: 4), () {
                                //                       Navigator.of(context).pop();
                                //                       Navigator.of(context).pop();
                                //                       showSnackBarText('QR Code read successfully!', context, true);
                                //                     });
                                //                   }
                                //                 },
                                //                 text: 'Scan QR Code',
                                //                 options: FFButtonOptions(
                                //                   width: MediaQuery.sizeOf(context)
                                //                       .width *
                                //                       0.4,
                                //                   height: 45.0,
                                //                   padding:
                                //                   EdgeInsetsDirectional.fromSTEB(
                                //                       0.0, 0.0, 0.0, 0.0),
                                //                   iconPadding:
                                //                   EdgeInsetsDirectional.fromSTEB(
                                //                       0.0, 0.0, 0.0, 0.0),
                                //                   color: FlutterFlowTheme.of(context)
                                //                       .primary,
                                //                   textStyle:
                                //                   FlutterFlowTheme.of(context)
                                //                       .titleSmall
                                //                       .override(
                                //                     fontFamily: 'Readex Pro',
                                //                     color: Colors.white,
                                //                   ),
                                //                   elevation: 3.0,
                                //                   borderSide: BorderSide(
                                //                     color: Colors.transparent,
                                //                     width: 1.0,
                                //                   ),
                                //                   borderRadius:
                                //                   BorderRadius.circular(12.0),
                                //                 ),
                                //               ),
                                //             ),
                                //             Align(
                                //               alignment:
                                //               AlignmentDirectional(0.00, 0.00),
                                //               child: FFButtonWidget(
                                //                 onPressed: () async {
                                //                   Navigator.pop(context);
                                //                 },
                                //                 text: 'Nah... I\'m good',
                                //                 options: FFButtonOptions(
                                //                   width: MediaQuery.sizeOf(context)
                                //                       .width *
                                //                       0.4,
                                //                   height: 45.0,
                                //                   padding:
                                //                   EdgeInsetsDirectional.fromSTEB(
                                //                       0.0, 0.0, 0.0, 0.0),
                                //                   iconPadding:
                                //                   EdgeInsetsDirectional.fromSTEB(
                                //                       0.0, 0.0, 0.0, 0.0),
                                //                   color: FlutterFlowTheme.of(context)
                                //                       .error,
                                //                   textStyle:
                                //                   FlutterFlowTheme.of(context)
                                //                       .titleSmall
                                //                       .override(
                                //                     fontFamily: 'Readex Pro',
                                //                     color: Colors.white,
                                //                   ),
                                //                   elevation: 3.0,
                                //                   borderSide: BorderSide(
                                //                     color: Colors.transparent,
                                //                     width: 1.0,
                                //                   ),
                                //                   borderRadius:
                                //                   BorderRadius.circular(12.0),
                                //                 ),
                                //               ),
                                //             ),
                                //           ],
                                //         ),
                                //       ),
                                //       Padding(
                                //         padding: EdgeInsetsDirectional.fromSTEB(
                                //             0.0, 20.0, 0.0, 0.0),
                                //         child: Text(
                                //           'You\'re close & Checked in',
                                //           textAlign: TextAlign.center,
                                //           style: FlutterFlowTheme.of(context)
                                //               .bodyMedium
                                //               .override(
                                //             fontFamily: 'Readex Pro',
                                //             fontSize: 22.0,
                                //             fontWeight: FontWeight.w500,
                                //           ),
                                //         ),
                                //       ),
                                //       Padding(
                                //         padding: EdgeInsetsDirectional.fromSTEB(
                                //             0.0, 0.0, 0.0, 0.0),
                                //         child: Icon(
                                //           Icons.check_box,
                                //           color: Color(0xFF24963D),
                                //           size: 200.0,
                                //         ),
                                //       ),
                                //     ],
                                //   ),
                                // ),
                              if(_distance! > getRemoteConfigDouble('distance'))
                                //if(!pressedCase2)
                                Padding(
                                  padding: EdgeInsetsDirectional.fromSTEB(
                                      0.0, 0.0, 0.0, 0.0),
                                  child: Column(
                                    mainAxisSize: MainAxisSize.max,
                                    children: [
                                      Padding(
                                        padding: EdgeInsetsDirectional.fromSTEB(0.0, 10.0, 0.0, 0.0),
                                        child: Column(
                                          children: [
                                            Container(
                                              width: MediaQuery.sizeOf(context).width * 0.8,
                                              child: Center(
                                                child: Text(
                                                  _distance == null ? 'Let’s Check you in!' : _distance! < getRemoteConfigDouble('distance') ? 'You’re Close Enough!' : 'You’re Not Close…',
                                                  style: FlutterFlowTheme.of(context).headlineMedium.override(
                                                      fontFamily: 'Open Sans',
                                                      fontWeight: FontWeight.w700,
                                                      fontSize: 20
                                                  ),
                                                  textAlign: TextAlign.center,
                                                ),
                                              ),
                                            ),
                                            if (currentLocation2 != null)
                                              Container(
                                                width: MediaQuery.sizeOf(context).width * 0.8,
                                                child: Center(
                                                  child: Text(
                                                    'Want to scan the QR code?',
                                                    style: FlutterFlowTheme.of(context).headlineMedium.override(
                                                        fontFamily: 'Open Sans',
                                                        fontWeight: FontWeight.w400,
                                                        fontSize: 14
                                                    ),
                                                    textAlign: TextAlign.center,
                                                  ),
                                                ),
                                              ),
                                          ],
                                        ),
                                      ),
                                      Padding(
                                          padding: EdgeInsetsDirectional.fromSTEB(0.0, 10.0, 0.0, 10.0),
                                          child: Row(
                                            mainAxisAlignment: MainAxisAlignment.center,
                                            children: [
                                              Text(
                                                'Checking current location:  ',
                                                style: FlutterFlowTheme.of(context)
                                                    .bodyMedium
                                                    .override(
                                                    fontFamily: 'Readex Pro',
                                                    fontSize: 14.0,
                                                    color:Colors.black.withOpacity(0.4)
                                                ),
                                              ),
                                              SizedBox(
                                                width: 5,
                                              ),
                                              if(permissionDenied )
                                                Text(
                                                  'Permission Denied',
                                                  style: FlutterFlowTheme.of(context)
                                                      .bodyMedium
                                                      .override(
                                                      fontFamily: 'Readex Pro',
                                                      fontSize: 14.0,
                                                      color: Colors.red
                                                  ),
                                                ),
                                              if (_distance != null)
                                                Text(
                                                  '${shortenDistance(_distance!)}',
                                                  style: FlutterFlowTheme.of(context)
                                                      .bodyMedium
                                                      .override(
                                                      fontFamily: 'Readex Pro',
                                                      fontSize: 14.0,
                                                      color: _distance! > getRemoteConfigDouble('distance')? Colors.red : Colors.green
                                                  ),
                                                ),
                                              if (_distance == null && !permissionDenied)
                                                SizedBox(
                                                  height: 20,
                                                  width: 20,
                                                  child: CircularProgressIndicator(
                                                    color: Colors.black,
                                                  ),
                                                )
                                            ],
                                          )
                                      ),
                                      // Row(
                                      //   mainAxisAlignment: MainAxisAlignment.center,
                                      //   children: [
                                      //     Align(
                                      //       alignment: AlignmentDirectional(0.00, 0.00),
                                      //       child: Padding(
                                      //         padding: EdgeInsetsDirectional.fromSTEB(
                                      //             0.0, 10.0, 0.0, 10.0),
                                      //         child: FFButtonWidget(
                                      //           onPressed: () {
                                      //             currentLocation2 = null;
                                      //             _distance = null;
                                      //             setState(() {
                                      //               //index++;
                                      //               pressedCase2 = true;
                                      //             });
                                      //             _getCurrentLocation();
                                      //           },
                                      //           text: 'Try Location Again',
                                      //           options: FFButtonOptions(
                                      //             width:
                                      //             MediaQuery.sizeOf(context).width *
                                      //                 0.4,
                                      //             height: 45.0,
                                      //             padding: EdgeInsetsDirectional.fromSTEB(
                                      //                 0.0, 0.0, 0.0, 0.0),
                                      //             iconPadding:
                                      //             EdgeInsetsDirectional.fromSTEB(
                                      //                 0.0, 0.0, 0.0, 0.0),
                                      //             color: Color(0xff2596be),
                                      //             textStyle: FlutterFlowTheme.of(context)
                                      //                 .titleSmall
                                      //                 .override(
                                      //               fontFamily: 'Readex Pro',
                                      //               color: Colors.white,
                                      //             ),
                                      //             elevation: 3.0,
                                      //             borderSide: BorderSide(
                                      //               color: Colors.transparent,
                                      //               width: 1.0,
                                      //             ),
                                      //             borderRadius:
                                      //             BorderRadius.circular(12.0),
                                      //           ),
                                      //         ),
                                      //       ),
                                      //     ),
                                      //     Align(
                                      //       alignment: AlignmentDirectional(0.00, 0.00),
                                      //       child: Padding(
                                      //         padding: EdgeInsetsDirectional.fromSTEB(
                                      //             0.0, 10.0, 0.0, 10.0),
                                      //         child: FFButtonWidget(
                                      //           onPressed: () {
                                      //             currentLocation2 = null;
                                      //             _distance = null;
                                      //             setState(() {
                                      //               //index++;
                                      //               pressedCase2 = true;
                                      //             });
                                      //             _getCurrentLocation();
                                      //           },
                                      //           text: 'Scan QR Code \n(Optional)',
                                      //           options: FFButtonOptions(
                                      //             width:
                                      //             MediaQuery.sizeOf(context).width *
                                      //                 0.4,
                                      //             //height: 45.0,
                                      //             padding: EdgeInsetsDirectional.fromSTEB(
                                      //                 0.0, 0.0, 0.0, 0.0),
                                      //             iconPadding:
                                      //             EdgeInsetsDirectional.fromSTEB(
                                      //                 0.0, 0.0, 0.0, 0.0),
                                      //             color: Color(0xff96c93e),
                                      //             textStyle: FlutterFlowTheme.of(context)
                                      //                 .titleSmall
                                      //                 .override(
                                      //               fontFamily: 'Readex Pro',
                                      //               color: Colors.white,
                                      //             ),
                                      //             elevation: 3.0,
                                      //             borderSide: BorderSide(
                                      //               color: Colors.transparent,
                                      //               width: 1.0,
                                      //             ),
                                      //             borderRadius:
                                      //             BorderRadius.circular(12.0),
                                      //           ),
                                      //         ),
                                      //       ),
                                      //     ),
                                      //   ],
                                      // ),
                                      Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                        children: [
                                          Align(
                                            alignment: AlignmentDirectional(0.00, 0.00),
                                            child: Padding(
                                              padding: EdgeInsetsDirectional.fromSTEB(
                                                  0.0, 10.0, 0.0, 10.0),
                                              child: InkWell(
                                                splashColor: Colors.transparent,
                                                focusColor: Colors.transparent,
                                                hoverColor: Colors.transparent,
                                                highlightColor: Colors.transparent,
                                                onTap: (){
                                                  currentLocation2 = null;
                                                  _distance = null;
                                                  setState(() {
                                                    //index++;
                                                    pressedCase2 = true;
                                                  });
                                                  _getCurrentLocation();
                                                },
                                                child: Container(
                                                  width: MediaQuery.sizeOf(context).width * 0.4,
                                                  height: 45,
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                    BorderRadius.circular(12.0),
                                                    color: Color(0xff2596be),
                                                  ),
                                                  child: Center(
                                                    child: Text('Try Location \n Again',style: TextStyle(
                                                      fontSize: 15,
                                                      color: Colors.white,
                                                      fontWeight: FontWeight.w600
                                                    ),textAlign: TextAlign.center,),
                                                  ),
                                                ),
                                              )
                                            ),
                                          ),
                                          Align(
                                            alignment: AlignmentDirectional(0.00, 0.00),
                                            child: Padding(
                                                padding: EdgeInsetsDirectional.fromSTEB(
                                                    0.0, 10.0, 0.0, 10.0),
                                                child: InkWell(
                                                  splashColor: Colors.transparent,
                                                  focusColor: Colors.transparent,
                                                  hoverColor: Colors.transparent,
                                                  highlightColor: Colors.transparent,
                                                  onTap: ()async{
                                                    final result = await Navigator.push(
                                                      context,
                                                      PageRouteBuilder(
                                                        pageBuilder: (_, __, ___) => QRCodeReader(),
                                                        transitionsBuilder: (_, a1, a2, child) =>
                                                            SlideTransition(
                                                              position: Tween(
                                                                  begin: Offset(1, 0),
                                                                  end: Offset(0, 0))
                                                                  .animate(a1),
                                                              child: child,
                                                            ),
                                                      ),
                                                    );

                                                    if (!mounted) return;

                                                    if (result == 'Decrypt!') {
                                                      openDialog();
                                                      await currentUserReference!.update({
                                                    ...mapToFirestore(
                                                    {
                                                    'checkedCampains': FieldValue.arrayUnion(
                                                    [widget.document?.reference]),
                                                    },
                                                    ),
                                                    });
                                                    Timer(Duration(seconds: 4), () {
                                                    Navigator.of(context).pop();
                                                    Navigator.of(context).pop();
                                                    showSnackBarText('QR Code read successfully!', context, true);
                                                    });
                                                  }
                                                  },
                                                  child: Container(
                                                    width: MediaQuery.sizeOf(context).width * 0.4,
                                                    height: 45,
                                                    decoration: BoxDecoration(
                                                      borderRadius:
                                                      BorderRadius.circular(12.0),
                                                      color: Color(0xff96c93e),
                                                    ),
                                                    child: Center(
                                                      child: Text('Scan QR Code \n(Optional)',style: TextStyle(
                                                          color: Colors.white,
                                                          fontSize: 15,
                                                          fontWeight: FontWeight.w600
                                                      ),textAlign: TextAlign.center,),
                                                    ),
                                                  ),
                                                )
                                            ),
                                          ),
                                        ],
                                      ),
                                      Padding(
                                        padding: EdgeInsetsDirectional.fromSTEB(
                                            0.0, 15.0, 0.0, 0.0),
                                        child: Center(
                                          child: SizedBox(
                                              width: MediaQuery.sizeOf(context).width * 0.9,
                                              height: 330,
                                              child:  BaseMap(loc: latlng2.LatLng(currentLocation2!.latitude!,currentLocation2!.longitude!) ,)),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                // if(pressedCase2)
                                //   Padding(
                                //     padding: EdgeInsetsDirectional.fromSTEB(
                                //         15.0, 15.0, 15.0, 0.0),
                                //     child: Column(
                                //       mainAxisSize: MainAxisSize.max,
                                //       children: [
                                //         Padding(
                                //           padding: EdgeInsetsDirectional.fromSTEB(
                                //               0.0, 0.0, 0.0, 0.0),
                                //           child: Container(
                                //             width: MediaQuery.sizeOf(context).width * 0.8,
                                //             decoration: BoxDecoration(
                                //               color: FlutterFlowTheme.of(context)
                                //                   .secondaryBackground,
                                //             ),
                                //             child: Text(
                                //               'Doesn\'t seem like you are close – want to scan the QR Code',
                                //               textAlign: TextAlign.center,
                                //               style: FlutterFlowTheme.of(context)
                                //                   .bodyMedium
                                //                   .override(
                                //                 fontFamily: 'Readex Pro',
                                //                 fontSize: 20.0,
                                //                 fontWeight: FontWeight.w500,
                                //               ),
                                //             ),
                                //           ),
                                //         ),
                                //         Padding(
                                //           padding: EdgeInsetsDirectional.fromSTEB(
                                //               0.0, 20.0, 0.0, 0.0),
                                //           child: Row(
                                //             mainAxisSize: MainAxisSize.max,
                                //             mainAxisAlignment:
                                //             MainAxisAlignment.spaceAround,
                                //             children: [
                                //               Align(
                                //                 alignment:
                                //                 AlignmentDirectional(0.00, 0.00),
                                //                 child: FFButtonWidget(
                                //                   onPressed: () async{
                                //                     final result = await Navigator.push(
                                //                       context,
                                //                       PageRouteBuilder(
                                //                         pageBuilder: (_, __, ___) => QRCodeReader(),
                                //                         transitionsBuilder: (_, a1, a2, child) =>
                                //                             SlideTransition(
                                //                               position: Tween(
                                //                                   begin: Offset(1, 0),
                                //                                   end: Offset(0, 0))
                                //                                   .animate(a1),
                                //                               child: child,
                                //                             ),
                                //                       ),
                                //                     );
                                //
                                //                     if (!mounted) return;
                                //
                                //                     if (result == 'Decrypt!') {
                                //                       openDialog();
                                //                         await currentUserReference!.update({
                                //                       ...mapToFirestore(
                                //                       {
                                //                       'checkedCampains': FieldValue.arrayUnion(
                                //                       [widget.document?.reference]),
                                //                       },
                                //                       ),
                                //                       });
                                //                       Timer(Duration(seconds: 4), () {
                                //                         Navigator.of(context).pop();
                                //                         Navigator.of(context).pop();
                                //                         showSnackBarText('QR Code read successfully!', context, true);
                                //                       });
                                //                     }
                                //                   },
                                //                   text: 'Scan QR Code',
                                //                   options: FFButtonOptions(
                                //                     width: MediaQuery.sizeOf(context)
                                //                         .width *
                                //                         0.4,
                                //                     height: 45.0,
                                //                     padding:
                                //                     EdgeInsetsDirectional.fromSTEB(
                                //                         0.0, 0.0, 0.0, 0.0),
                                //                     iconPadding:
                                //                     EdgeInsetsDirectional.fromSTEB(
                                //                         0.0, 0.0, 0.0, 0.0),
                                //                     color: FlutterFlowTheme.of(context)
                                //                         .primary,
                                //                     textStyle:
                                //                     FlutterFlowTheme.of(context)
                                //                         .titleSmall
                                //                         .override(
                                //                       fontFamily: 'Readex Pro',
                                //                       color: Colors.white,
                                //                     ),
                                //                     elevation: 3.0,
                                //                     borderSide: BorderSide(
                                //                       color: Colors.transparent,
                                //                       width: 1.0,
                                //                     ),
                                //                     borderRadius:
                                //                     BorderRadius.circular(12.0),
                                //                   ),
                                //                 ),
                                //               ),
                                //               Align(
                                //                 alignment:
                                //                 AlignmentDirectional(0.00, 0.00),
                                //                 child: FFButtonWidget(
                                //                   onPressed: () async {
                                //                     Navigator.pop(context);
                                //                   },
                                //                   text: 'Nah... I\'m good',
                                //                   options: FFButtonOptions(
                                //                     width: MediaQuery.sizeOf(context)
                                //                         .width *
                                //                         0.4,
                                //                     height: 45.0,
                                //                     padding:
                                //                     EdgeInsetsDirectional.fromSTEB(
                                //                         0.0, 0.0, 0.0, 0.0),
                                //                     iconPadding:
                                //                     EdgeInsetsDirectional.fromSTEB(
                                //                         0.0, 0.0, 0.0, 0.0),
                                //                     color: FlutterFlowTheme.of(context)
                                //                         .error,
                                //                     textStyle:
                                //                     FlutterFlowTheme.of(context)
                                //                         .titleSmall
                                //                         .override(
                                //                       fontFamily: 'Readex Pro',
                                //                       color: Colors.white,
                                //                     ),
                                //                     elevation: 3.0,
                                //                     borderSide: BorderSide(
                                //                       color: Colors.transparent,
                                //                       width: 1.0,
                                //                     ),
                                //                     borderRadius:
                                //                     BorderRadius.circular(12.0),
                                //                   ),
                                //                 ),
                                //               ),
                                //             ],
                                //           ),
                                //         ),
                                //         Padding(
                                //           padding: EdgeInsetsDirectional.fromSTEB(
                                //               0.0, 20.0, 0.0, 0.0),
                                //           child: Text(
                                //             'Scan the QR to Check in',
                                //             textAlign: TextAlign.center,
                                //             style: FlutterFlowTheme.of(context)
                                //                 .bodyMedium
                                //                 .override(
                                //               fontFamily: 'Readex Pro',
                                //               fontSize: 22.0,
                                //               fontWeight: FontWeight.w500,
                                //             ),
                                //           ),
                                //         ),
                                //         Padding(
                                //           padding: EdgeInsetsDirectional.fromSTEB(
                                //               0.0, 20.0, 0.0, 0.0),
                                //           child: Icon(
                                //             Icons.remove_circle_outline,
                                //             color: Colors.grey,
                                //             size: 200.0,
                                //           ),
                                //         ),
                                //       ],
                                //     ),
                                //   ),
                              // if (!widget.isQRRequired!)
                              //   Padding(
                              //     padding: EdgeInsetsDirectional.fromSTEB(
                              //         15.0, 15.0, 15.0, 15.0),
                              //     child: Container(
                              //       width: double.infinity,
                              //       decoration: BoxDecoration(
                              //         color: FlutterFlowTheme.of(context)
                              //             .secondaryBackground,
                              //         border: Border.all(
                              //           color: FlutterFlowTheme.of(context).primaryText,
                              //         ),
                              //       ),
                              //       child: Column(
                              //         mainAxisSize: MainAxisSize.max,
                              //         children: [
                              //           Padding(
                              //             padding: EdgeInsetsDirectional.fromSTEB(
                              //                 0.0, 20.0, 0.0, 0.0),
                              //             child: Container(
                              //               width:
                              //                   MediaQuery.sizeOf(context).width * 0.8,
                              //               decoration: BoxDecoration(
                              //                 color: FlutterFlowTheme.of(context)
                              //                     .secondaryBackground,
                              //               ),
                              //               child: Text(
                              //                 'You\'re close & Checked in',
                              //                 textAlign: TextAlign.center,
                              //                 style: FlutterFlowTheme.of(context)
                              //                     .bodyMedium
                              //                     .override(
                              //                       fontFamily: 'Readex Pro',
                              //                       fontSize: 22.0,
                              //                       fontWeight: FontWeight.w500,
                              //                     ),
                              //               ),
                              //             ),
                              //           ),
                              //           Padding(
                              //             padding: EdgeInsetsDirectional.fromSTEB(
                              //                 0.0, 20.0, 0.0, 0.0),
                              //             child: Icon(
                              //               Icons.check_box,
                              //               color: Color(0xFF24963D),
                              //               size: 200.0,
                              //             ),
                              //           ),
                              //           Padding(
                              //             padding: EdgeInsetsDirectional.fromSTEB(
                              //                 0.0, 25.0, 0.0, 15.0),
                              //             child: Row(
                              //               mainAxisSize: MainAxisSize.max,
                              //               mainAxisAlignment:
                              //                   MainAxisAlignment.spaceAround,
                              //               children: [
                              //                 Align(
                              //                   alignment:
                              //                       AlignmentDirectional(0.00, 0.00),
                              //                   child: FFButtonWidget(
                              //                     onPressed: () {
                              //                       print('Button pressed ...');
                              //                     },
                              //                     text: 'Cancel',
                              //                     options: FFButtonOptions(
                              //                       width: MediaQuery.sizeOf(context)
                              //                               .width *
                              //                           0.35,
                              //                       height: 40.0,
                              //                       padding:
                              //                           EdgeInsetsDirectional.fromSTEB(
                              //                               0.0, 0.0, 0.0, 0.0),
                              //                       iconPadding:
                              //                           EdgeInsetsDirectional.fromSTEB(
                              //                               0.0, 0.0, 0.0, 0.0),
                              //                       color: FlutterFlowTheme.of(context)
                              //                           .primary,
                              //                       textStyle:
                              //                           FlutterFlowTheme.of(context)
                              //                               .titleSmall
                              //                               .override(
                              //                                 fontFamily: 'Readex Pro',
                              //                                 color: Colors.white,
                              //                               ),
                              //                       elevation: 3.0,
                              //                       borderSide: BorderSide(
                              //                         color: Colors.transparent,
                              //                         width: 1.0,
                              //                       ),
                              //                       borderRadius:
                              //                           BorderRadius.circular(12.0),
                              //                     ),
                              //                   ),
                              //                 ),
                              //               ],
                              //             ),
                              //           ),
                              //         ],
                              //       ),
                              //     ),
                              //   ),
                              // if (!widget.isQRRequired!)
                              //   Padding(
                              //     padding: EdgeInsetsDirectional.fromSTEB(
                              //         15.0, 15.0, 15.0, 15.0),
                              //     child: Container(
                              //       width: double.infinity,
                              //       decoration: BoxDecoration(
                              //         color: FlutterFlowTheme.of(context)
                              //             .secondaryBackground,
                              //         border: Border.all(
                              //           color: FlutterFlowTheme.of(context).primaryText,
                              //         ),
                              //       ),
                              //       child: Column(
                              //         mainAxisSize: MainAxisSize.max,
                              //         children: [
                              //           Container(
                              //             width: MediaQuery.sizeOf(context).width * 0.8,
                              //             decoration: BoxDecoration(
                              //               color: FlutterFlowTheme.of(context)
                              //                   .secondaryBackground,
                              //             ),
                              //             child: Padding(
                              //               padding: EdgeInsetsDirectional.fromSTEB(
                              //                   0.0, 20.0, 0.0, 20.0),
                              //               child: Text(
                              //                 'Hmmm you seem a bit far – try \ngeolocation again or scan the QR Code at that location ',
                              //                 textAlign: TextAlign.center,
                              //                 style: FlutterFlowTheme.of(context)
                              //                     .bodyMedium
                              //                     .override(
                              //                       fontFamily: 'Readex Pro',
                              //                       fontSize: 20.0,
                              //                       fontWeight: FontWeight.w500,
                              //                     ),
                              //               ),
                              //             ),
                              //           ),
                              //           Align(
                              //             alignment: AlignmentDirectional(0.00, 0.00),
                              //             child: Padding(
                              //               padding: EdgeInsetsDirectional.fromSTEB(
                              //                   0.0, 0.0, 0.0, 20.0),
                              //               child: FFButtonWidget(
                              //                 onPressed: () {
                              //                   print('Button pressed ...');
                              //                 },
                              //                 text: 'Try Geolocation Again\n',
                              //                 options: FFButtonOptions(
                              //                   width:
                              //                       MediaQuery.sizeOf(context).width *
                              //                           0.7,
                              //                   height: 45.0,
                              //                   padding: EdgeInsetsDirectional.fromSTEB(
                              //                       0.0, 0.0, 0.0, 0.0),
                              //                   iconPadding:
                              //                       EdgeInsetsDirectional.fromSTEB(
                              //                           0.0, 0.0, 0.0, 0.0),
                              //                   color: FlutterFlowTheme.of(context)
                              //                       .primary,
                              //                   textStyle: FlutterFlowTheme.of(context)
                              //                       .titleSmall
                              //                       .override(
                              //                         fontFamily: 'Readex Pro',
                              //                         color: Colors.white,
                              //                       ),
                              //                   elevation: 3.0,
                              //                   borderSide: BorderSide(
                              //                     color: Colors.transparent,
                              //                     width: 1.0,
                              //                   ),
                              //                   borderRadius:
                              //                       BorderRadius.circular(12.0),
                              //                 ),
                              //               ),
                              //             ),
                              //           ),
                              //         ],
                              //       ),
                              //     ),
                              //   ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
              if(widget.document!.qRCodeAvailable)
                if(widget.document!.requiresQRScan)
                  Column(
                    children: [
                      if (currentLocation2 == null)
                        Column(
                          children: [
                            Padding(
                              padding: EdgeInsetsDirectional.fromSTEB(0.0, 10.0, 0.0, 0.0),
                              child: Container(
                                width: MediaQuery.sizeOf(context).width * 0.8,
                                child: Center(
                                  child: Text(
                                    _distance == null ? 'Let’s Check you in!' : _distance! < getRemoteConfigDouble('distance') ? 'You’re Checked In!' : 'You’re Not Close…',
                                    style: FlutterFlowTheme.of(context).headlineMedium.override(
                                        fontFamily: 'Open Sans',
                                        fontWeight: FontWeight.w700,
                                        fontSize: 20
                                    ),
                                    textAlign: TextAlign.center,
                                  ),
                                ),
                              ),
                            ),
                            Padding(
                                padding: EdgeInsetsDirectional.fromSTEB(0.0, 10.0, 0.0, 10.0),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Text(
                                      'Checking current location:  ',
                                      style: FlutterFlowTheme.of(context)
                                          .bodyMedium
                                          .override(
                                          fontFamily: 'Readex Pro',
                                          fontSize: 14.0,
                                          color:Colors.black.withOpacity(0.4)
                                      ),
                                    ),
                                    SizedBox(
                                      width: 5,
                                    ),
                                    if(permissionDenied)
                                      Text(
                                        'Permission Denied',
                                        style: FlutterFlowTheme.of(context)
                                            .bodyMedium
                                            .override(
                                            fontFamily: 'Readex Pro',
                                            fontSize: 14.0,
                                            color: Colors.red
                                        ),
                                      ),
                                    if (_distance != null)
                                      Text(
                                        '${shortenDistance(_distance!)}',
                                        style: FlutterFlowTheme.of(context)
                                            .bodyMedium
                                            .override(
                                            fontFamily: 'Readex Pro',
                                            fontSize: 14.0,
                                            color: _distance! > getRemoteConfigDouble('distance')? Colors.red : Colors.green
                                        ),
                                      ),
                                    if (_distance == null && !permissionDenied)
                                      SizedBox(
                                        height: 20,
                                        width: 20,
                                        child: CircularProgressIndicator(
                                          color: Colors.black,
                                        ),
                                      )
                                  ],
                                )
                            ),
                            Padding(
                              padding: EdgeInsetsDirectional.fromSTEB(
                                  0.0, 30.0, 0.0, 0.0),
                              child: Center(
                                child: SizedBox(
                                  height: 40,
                                  width: 40,
                                  child: CircularProgressIndicator(
                                    color: Colors.black,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      if (_distance != null)
                        Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
                          child: Container(
                            width: double.infinity,
                            decoration: BoxDecoration(
                              color: FlutterFlowTheme.of(context).secondaryBackground,
                            ),
                            child: Column(
                              mainAxisSize: MainAxisSize.max,
                              children: [
                                if(_distance! < getRemoteConfigDouble('distance'))
                                  Padding(
                                    padding: EdgeInsetsDirectional.fromSTEB(
                                        0.0, 0.0, 0.0, 0.0),
                                    child: Column(
                                      mainAxisSize: MainAxisSize.max,
                                      children: [
                                        Padding(
                                          padding: EdgeInsetsDirectional.fromSTEB(0.0, 10.0, 0.0, 0.0),
                                          child: Column(
                                            children: [
                                              Container(
                                                width: MediaQuery.sizeOf(context).width * 0.8,
                                                child: Center(
                                                  child: Text(
                                                    _distance == null ? 'Let’s Check you in!' : _distance! < getRemoteConfigDouble('distance') ? 'You’re Close Enough!' : 'You’re Not Close…',
                                                    style: FlutterFlowTheme.of(context).headlineMedium.override(
                                                        fontFamily: 'Open Sans',
                                                        fontWeight: FontWeight.w700,
                                                        fontSize: 20
                                                    ),
                                                    textAlign: TextAlign.center,
                                                  ),
                                                ),
                                              ),
                                              if (currentLocation2 != null)
                                                Container(
                                                  width: MediaQuery.sizeOf(context).width * 0.8,
                                                  child: Center(
                                                    child: Text(
                                                      'Now find the QR code',
                                                      style: FlutterFlowTheme.of(context).headlineMedium.override(
                                                          fontFamily: 'Open Sans',
                                                          fontWeight: FontWeight.w700,
                                                          fontSize: 20
                                                      ),
                                                      textAlign: TextAlign.center,
                                                    ),
                                                  ),
                                                ),
                                            ],
                                          ),
                                        ),
                                        Padding(
                                            padding: EdgeInsetsDirectional.fromSTEB(0.0, 10.0, 0.0, 10.0),
                                            child: Row(
                                              mainAxisAlignment: MainAxisAlignment.center,
                                              children: [
                                                Text(
                                                  'Checking current location:  ',
                                                  style: FlutterFlowTheme.of(context)
                                                      .bodyMedium
                                                      .override(
                                                      fontFamily: 'Readex Pro',
                                                      fontSize: 14.0,
                                                      color:Colors.black.withOpacity(0.4)
                                                  ),
                                                ),
                                                SizedBox(
                                                  width: 5,
                                                ),
                                                if(permissionDenied )
                                                  Text(
                                                    'Permission Denied',
                                                    style: FlutterFlowTheme.of(context)
                                                        .bodyMedium
                                                        .override(
                                                        fontFamily: 'Readex Pro',
                                                        fontSize: 14.0,
                                                        color: Colors.red
                                                    ),
                                                  ),
                                                if (_distance != null)
                                                  Text(
                                                    '${shortenDistance(_distance!)}',
                                                    style: FlutterFlowTheme.of(context)
                                                        .bodyMedium
                                                        .override(
                                                        fontFamily: 'Readex Pro',
                                                        fontSize: 14.0,
                                                        color: _distance! > getRemoteConfigDouble('distance')? Colors.red : Colors.green
                                                    ),
                                                  ),
                                                if (_distance == null && !permissionDenied)
                                                  SizedBox(
                                                    height: 20,
                                                    width: 20,
                                                    child: CircularProgressIndicator(
                                                      color: Colors.black,
                                                    ),
                                                  )
                                              ],
                                            )
                                        ),
                                        // Row(
                                        //   mainAxisAlignment: MainAxisAlignment.center,
                                        //   children: [
                                        //     Align(
                                        //       alignment: AlignmentDirectional(0.00, 0.00),
                                        //       child: Padding(
                                        //         padding: EdgeInsetsDirectional.fromSTEB(
                                        //             0.0, 10.0, 0.0, 10.0),
                                        //         child: FFButtonWidget(
                                        //           onPressed: () {
                                        //             currentLocation2 = null;
                                        //             _distance = null;
                                        //             setState(() {
                                        //               //index++;
                                        //               pressedCase2 = true;
                                        //             });
                                        //             _getCurrentLocation();
                                        //           },
                                        //           text: 'Try Location Again',
                                        //           options: FFButtonOptions(
                                        //             width:
                                        //             MediaQuery.sizeOf(context).width *
                                        //                 0.4,
                                        //             height: 45.0,
                                        //             padding: EdgeInsetsDirectional.fromSTEB(
                                        //                 0.0, 0.0, 0.0, 0.0),
                                        //             iconPadding:
                                        //             EdgeInsetsDirectional.fromSTEB(
                                        //                 0.0, 0.0, 0.0, 0.0),
                                        //             color: Color(0xff2596be),
                                        //             textStyle: FlutterFlowTheme.of(context)
                                        //                 .titleSmall
                                        //                 .override(
                                        //               fontFamily: 'Readex Pro',
                                        //               color: Colors.white,
                                        //             ),
                                        //             elevation: 3.0,
                                        //             borderSide: BorderSide(
                                        //               color: Colors.transparent,
                                        //               width: 1.0,
                                        //             ),
                                        //             borderRadius:
                                        //             BorderRadius.circular(12.0),
                                        //           ),
                                        //         ),
                                        //       ),
                                        //     ),
                                        //     Align(
                                        //       alignment: AlignmentDirectional(0.00, 0.00),
                                        //       child: Padding(
                                        //         padding: EdgeInsetsDirectional.fromSTEB(
                                        //             0.0, 10.0, 0.0, 10.0),
                                        //         child: FFButtonWidget(
                                        //           onPressed: () {
                                        //             currentLocation2 = null;
                                        //             _distance = null;
                                        //             setState(() {
                                        //               //index++;
                                        //               pressedCase2 = true;
                                        //             });
                                        //             _getCurrentLocation();
                                        //           },
                                        //           text: 'Scan QR Code \n(Optional)',
                                        //           options: FFButtonOptions(
                                        //             width:
                                        //             MediaQuery.sizeOf(context).width *
                                        //                 0.4,
                                        //             //height: 45.0,
                                        //             padding: EdgeInsetsDirectional.fromSTEB(
                                        //                 0.0, 0.0, 0.0, 0.0),
                                        //             iconPadding:
                                        //             EdgeInsetsDirectional.fromSTEB(
                                        //                 0.0, 0.0, 0.0, 0.0),
                                        //             color: Color(0xff96c93e),
                                        //             textStyle: FlutterFlowTheme.of(context)
                                        //                 .titleSmall
                                        //                 .override(
                                        //               fontFamily: 'Readex Pro',
                                        //               color: Colors.white,
                                        //             ),
                                        //             elevation: 3.0,
                                        //             borderSide: BorderSide(
                                        //               color: Colors.transparent,
                                        //               width: 1.0,
                                        //             ),
                                        //             borderRadius:
                                        //             BorderRadius.circular(12.0),
                                        //           ),
                                        //         ),
                                        //       ),
                                        //     ),
                                        //   ],
                                        // ),
                                        Row(
                                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                          children: [
                                            Align(
                                              alignment: AlignmentDirectional(0.00, 0.00),
                                              child: Padding(
                                                  padding: EdgeInsetsDirectional.fromSTEB(
                                                      0.0, 10.0, 0.0, 10.0),
                                                  child: InkWell(
                                                    splashColor: Colors.transparent,
                                                    focusColor: Colors.transparent,
                                                    hoverColor: Colors.transparent,
                                                    highlightColor: Colors.transparent,
                                                    onTap: (){
                                                      Navigator.pop(context);
                                                    },
                                                    child: Container(
                                                      width: MediaQuery.sizeOf(context).width * 0.4,
                                                      height: 45,
                                                      decoration: BoxDecoration(
                                                        borderRadius:
                                                        BorderRadius.circular(12.0),
                                                        color: Color(0xff2596be),
                                                      ),
                                                      child: Center(
                                                        child: Text('You’re In',style: TextStyle(
                                                            fontSize: 15,
                                                            color: Colors.white,
                                                            fontWeight: FontWeight.w600
                                                        ),textAlign: TextAlign.center,),
                                                      ),
                                                    ),
                                                  )
                                              ),
                                            ),
                                            Align(
                                              alignment: AlignmentDirectional(0.00, 0.00),
                                              child: Padding(
                                                  padding: EdgeInsetsDirectional.fromSTEB(
                                                      0.0, 10.0, 0.0, 10.0),
                                                  child: InkWell(
                                                    splashColor: Colors.transparent,
                                                    focusColor: Colors.transparent,
                                                    hoverColor: Colors.transparent,
                                                    highlightColor: Colors.transparent,
                                                    onTap: ()async{
                                                      final result = await Navigator.push(
                                                        context,
                                                        PageRouteBuilder(
                                                          pageBuilder: (_, __, ___) => QRCodeReader(),
                                                          transitionsBuilder: (_, a1, a2, child) =>
                                                              SlideTransition(
                                                                position: Tween(
                                                                    begin: Offset(1, 0),
                                                                    end: Offset(0, 0))
                                                                    .animate(a1),
                                                                child: child,
                                                              ),
                                                        ),
                                                      );

                                                      if (!mounted) return;

                                                      if (result == 'Decrypt!') {
                                                        openDialog();
                                                        await currentUserReference!.update({
                                                          ...mapToFirestore(
                                                            {
                                                              'checkedCampains': FieldValue.arrayUnion(
                                                                  [widget.document?.reference]),
                                                            },
                                                          ),
                                                        });
                                                        Timer(Duration(seconds: 4), () {
                                                          Navigator.of(context).pop();
                                                          Navigator.of(context).pop();
                                                          showSnackBarText('QR Code read successfully!', context, true);
                                                        });
                                                      }
                                                    },
                                                    child: Container(
                                                      width: MediaQuery.sizeOf(context).width * 0.4,
                                                      height: 45,
                                                      decoration: BoxDecoration(
                                                        borderRadius:
                                                        BorderRadius.circular(12.0),
                                                        color: Color(0xff96c93e),
                                                      ),
                                                      child: Center(
                                                        child: Text('Scan QR Code \n(Required)',style: TextStyle(
                                                            color: Colors.white,
                                                            fontSize: 15,
                                                            fontWeight: FontWeight.w600
                                                        ),textAlign: TextAlign.center,),
                                                      ),
                                                    ),
                                                  )
                                              ),
                                            ),
                                          ],
                                        ),
                                        Padding(
                                          padding: EdgeInsetsDirectional.fromSTEB(
                                              0.0, 15.0, 0.0, 0.0),
                                          child: Center(
                                            child: SizedBox(
                                                width: MediaQuery.sizeOf(context).width * 0.9,
                                                height: 330,
                                                child:  BaseMap(loc: latlng2.LatLng(currentLocation2!.latitude!,currentLocation2!.longitude!) ,)),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                // Padding(
                                //   padding: EdgeInsetsDirectional.fromSTEB(
                                //       15.0, 15.0, 15.0, 15.0),
                                //   child: Column(
                                //     mainAxisSize: MainAxisSize.max,
                                //     children: [
                                //       Padding(
                                //         padding: EdgeInsetsDirectional.fromSTEB(
                                //             0.0, 0.0, 0.0, 0.0),
                                //         child: Container(
                                //           width:
                                //           MediaQuery.sizeOf(context).width * 0.8,
                                //           decoration: BoxDecoration(
                                //             color: FlutterFlowTheme.of(context)
                                //                 .secondaryBackground,
                                //           ),
                                //           child: Text(
                                //             'Want to get extra points? \n find and scan the QR Code',
                                //             textAlign: TextAlign.center,
                                //             style: FlutterFlowTheme.of(context)
                                //                 .bodyMedium
                                //                 .override(
                                //               fontFamily: 'Readex Pro',
                                //               fontSize: 20.0,
                                //               fontWeight: FontWeight.w500,
                                //             ),
                                //           ),
                                //         ),
                                //       ),
                                //       Padding(
                                //         padding: EdgeInsetsDirectional.fromSTEB(
                                //             0.0, 20.0, 0.0, 0.0),
                                //         child: Row(
                                //           mainAxisSize: MainAxisSize.max,
                                //           mainAxisAlignment:
                                //           MainAxisAlignment.spaceAround,
                                //           children: [
                                //             Align(
                                //               alignment:
                                //               AlignmentDirectional(0.00, 0.00),
                                //               child: FFButtonWidget(
                                //                 onPressed: () async{
                                //                   final result = await Navigator.push(
                                //                     context,
                                //                     PageRouteBuilder(
                                //                       pageBuilder: (_, __, ___) => QRCodeReader(),
                                //                       transitionsBuilder: (_, a1, a2, child) =>
                                //                           SlideTransition(
                                //                             position: Tween(
                                //                                 begin: Offset(1, 0),
                                //                                 end: Offset(0, 0))
                                //                                 .animate(a1),
                                //                             child: child,
                                //                           ),
                                //                     ),
                                //                   );
                                //
                                //                   if (!mounted) return;
                                //
                                //                   if (result == 'Decrypt!') {
                                //                     openDialog();
                                //                     //   await currentUserReference!.update({
                                //                     // ...mapToFirestore(
                                //                     // {
                                //                     // 'checkedCampains': FieldValue.arrayUnion(
                                //                     // [widget.document?.reference]),
                                //                     // },
                                //                     // ),
                                //                     // });
                                //                     Timer(Duration(seconds: 4), () {
                                //                       Navigator.of(context).pop();
                                //                       Navigator.of(context).pop();
                                //                       showSnackBarText('QR Code read successfully!', context, true);
                                //                     });
                                //                   }
                                //                 },
                                //                 text: 'Scan QR Code',
                                //                 options: FFButtonOptions(
                                //                   width: MediaQuery.sizeOf(context)
                                //                       .width *
                                //                       0.4,
                                //                   height: 45.0,
                                //                   padding:
                                //                   EdgeInsetsDirectional.fromSTEB(
                                //                       0.0, 0.0, 0.0, 0.0),
                                //                   iconPadding:
                                //                   EdgeInsetsDirectional.fromSTEB(
                                //                       0.0, 0.0, 0.0, 0.0),
                                //                   color: FlutterFlowTheme.of(context)
                                //                       .primary,
                                //                   textStyle:
                                //                   FlutterFlowTheme.of(context)
                                //                       .titleSmall
                                //                       .override(
                                //                     fontFamily: 'Readex Pro',
                                //                     color: Colors.white,
                                //                   ),
                                //                   elevation: 3.0,
                                //                   borderSide: BorderSide(
                                //                     color: Colors.transparent,
                                //                     width: 1.0,
                                //                   ),
                                //                   borderRadius:
                                //                   BorderRadius.circular(12.0),
                                //                 ),
                                //               ),
                                //             ),
                                //             Align(
                                //               alignment:
                                //               AlignmentDirectional(0.00, 0.00),
                                //               child: FFButtonWidget(
                                //                 onPressed: () async {
                                //                   Navigator.pop(context);
                                //                 },
                                //                 text: 'Nah... I\'m good',
                                //                 options: FFButtonOptions(
                                //                   width: MediaQuery.sizeOf(context)
                                //                       .width *
                                //                       0.4,
                                //                   height: 45.0,
                                //                   padding:
                                //                   EdgeInsetsDirectional.fromSTEB(
                                //                       0.0, 0.0, 0.0, 0.0),
                                //                   iconPadding:
                                //                   EdgeInsetsDirectional.fromSTEB(
                                //                       0.0, 0.0, 0.0, 0.0),
                                //                   color: FlutterFlowTheme.of(context)
                                //                       .error,
                                //                   textStyle:
                                //                   FlutterFlowTheme.of(context)
                                //                       .titleSmall
                                //                       .override(
                                //                     fontFamily: 'Readex Pro',
                                //                     color: Colors.white,
                                //                   ),
                                //                   elevation: 3.0,
                                //                   borderSide: BorderSide(
                                //                     color: Colors.transparent,
                                //                     width: 1.0,
                                //                   ),
                                //                   borderRadius:
                                //                   BorderRadius.circular(12.0),
                                //                 ),
                                //               ),
                                //             ),
                                //           ],
                                //         ),
                                //       ),
                                //       Padding(
                                //         padding: EdgeInsetsDirectional.fromSTEB(
                                //             0.0, 20.0, 0.0, 0.0),
                                //         child: Text(
                                //           'You\'re close & Checked in',
                                //           textAlign: TextAlign.center,
                                //           style: FlutterFlowTheme.of(context)
                                //               .bodyMedium
                                //               .override(
                                //             fontFamily: 'Readex Pro',
                                //             fontSize: 22.0,
                                //             fontWeight: FontWeight.w500,
                                //           ),
                                //         ),
                                //       ),
                                //       Padding(
                                //         padding: EdgeInsetsDirectional.fromSTEB(
                                //             0.0, 0.0, 0.0, 0.0),
                                //         child: Icon(
                                //           Icons.check_box,
                                //           color: Color(0xFF24963D),
                                //           size: 200.0,
                                //         ),
                                //       ),
                                //     ],
                                //   ),
                                // ),
                                if(_distance! > getRemoteConfigDouble('distance'))
                                //if(!pressedCase2)
                                  Padding(
                                    padding: EdgeInsetsDirectional.fromSTEB(
                                        0.0, 0.0, 0.0, 0.0),
                                    child: Column(
                                      mainAxisSize: MainAxisSize.max,
                                      children: [
                                        Padding(
                                          padding: EdgeInsetsDirectional.fromSTEB(0.0, 10.0, 0.0, 0.0),
                                          child: Column(
                                            children: [
                                              Container(
                                                width: MediaQuery.sizeOf(context).width * 0.8,
                                                child: Center(
                                                  child: Text(
                                                    _distance == null ? 'Let’s Check you in!' : _distance! < getRemoteConfigDouble('distance') ? 'You’re Close Enough!' : 'You’re Not Close…',
                                                    style: FlutterFlowTheme.of(context).headlineMedium.override(
                                                        fontFamily: 'Open Sans',
                                                        fontWeight: FontWeight.w700,
                                                        fontSize: 20
                                                    ),
                                                    textAlign: TextAlign.center,
                                                  ),
                                                ),
                                              ),
                                              if (currentLocation2 != null)
                                                Container(
                                                  width: MediaQuery.sizeOf(context).width * 0.8,
                                                  child: Center(
                                                    child: Text(
                                                      'You can try again or scan the QR code',
                                                      style: FlutterFlowTheme.of(context).headlineMedium.override(
                                                          fontFamily: 'Open Sans',
                                                          fontWeight: FontWeight.w400,
                                                          fontSize: 14
                                                      ),
                                                      textAlign: TextAlign.center,
                                                    ),
                                                  ),
                                                ),
                                            ],
                                          ),
                                        ),
                                        Padding(
                                            padding: EdgeInsetsDirectional.fromSTEB(0.0, 10.0, 0.0, 10.0),
                                            child: Row(
                                              mainAxisAlignment: MainAxisAlignment.center,
                                              children: [
                                                Text(
                                                  'Checking current location:  ',
                                                  style: FlutterFlowTheme.of(context)
                                                      .bodyMedium
                                                      .override(
                                                      fontFamily: 'Readex Pro',
                                                      fontSize: 14.0,
                                                      color:Colors.black.withOpacity(0.4)
                                                  ),
                                                ),
                                                SizedBox(
                                                  width: 5,
                                                ),
                                                if(permissionDenied )
                                                  Text(
                                                    'Permission Denied',
                                                    style: FlutterFlowTheme.of(context)
                                                        .bodyMedium
                                                        .override(
                                                        fontFamily: 'Readex Pro',
                                                        fontSize: 14.0,
                                                        color: Colors.red
                                                    ),
                                                  ),
                                                if (_distance != null)
                                                  Text(
                                                    '${shortenDistance(_distance!)}',
                                                    style: FlutterFlowTheme.of(context)
                                                        .bodyMedium
                                                        .override(
                                                        fontFamily: 'Readex Pro',
                                                        fontSize: 14.0,
                                                        color: _distance! > getRemoteConfigDouble('distance')? Colors.red : Colors.green
                                                    ),
                                                  ),
                                                if (_distance == null && !permissionDenied)
                                                  SizedBox(
                                                    height: 20,
                                                    width: 20,
                                                    child: CircularProgressIndicator(
                                                      color: Colors.black,
                                                    ),
                                                  )
                                              ],
                                            )
                                        ),
                                        // Row(
                                        //   mainAxisAlignment: MainAxisAlignment.center,
                                        //   children: [
                                        //     Align(
                                        //       alignment: AlignmentDirectional(0.00, 0.00),
                                        //       child: Padding(
                                        //         padding: EdgeInsetsDirectional.fromSTEB(
                                        //             0.0, 10.0, 0.0, 10.0),
                                        //         child: FFButtonWidget(
                                        //           onPressed: () {
                                        //             currentLocation2 = null;
                                        //             _distance = null;
                                        //             setState(() {
                                        //               //index++;
                                        //               pressedCase2 = true;
                                        //             });
                                        //             _getCurrentLocation();
                                        //           },
                                        //           text: 'Try Location Again',
                                        //           options: FFButtonOptions(
                                        //             width:
                                        //             MediaQuery.sizeOf(context).width *
                                        //                 0.4,
                                        //             height: 45.0,
                                        //             padding: EdgeInsetsDirectional.fromSTEB(
                                        //                 0.0, 0.0, 0.0, 0.0),
                                        //             iconPadding:
                                        //             EdgeInsetsDirectional.fromSTEB(
                                        //                 0.0, 0.0, 0.0, 0.0),
                                        //             color: Color(0xff2596be),
                                        //             textStyle: FlutterFlowTheme.of(context)
                                        //                 .titleSmall
                                        //                 .override(
                                        //               fontFamily: 'Readex Pro',
                                        //               color: Colors.white,
                                        //             ),
                                        //             elevation: 3.0,
                                        //             borderSide: BorderSide(
                                        //               color: Colors.transparent,
                                        //               width: 1.0,
                                        //             ),
                                        //             borderRadius:
                                        //             BorderRadius.circular(12.0),
                                        //           ),
                                        //         ),
                                        //       ),
                                        //     ),
                                        //     Align(
                                        //       alignment: AlignmentDirectional(0.00, 0.00),
                                        //       child: Padding(
                                        //         padding: EdgeInsetsDirectional.fromSTEB(
                                        //             0.0, 10.0, 0.0, 10.0),
                                        //         child: FFButtonWidget(
                                        //           onPressed: () {
                                        //             currentLocation2 = null;
                                        //             _distance = null;
                                        //             setState(() {
                                        //               //index++;
                                        //               pressedCase2 = true;
                                        //             });
                                        //             _getCurrentLocation();
                                        //           },
                                        //           text: 'Scan QR Code \n(Optional)',
                                        //           options: FFButtonOptions(
                                        //             width:
                                        //             MediaQuery.sizeOf(context).width *
                                        //                 0.4,
                                        //             //height: 45.0,
                                        //             padding: EdgeInsetsDirectional.fromSTEB(
                                        //                 0.0, 0.0, 0.0, 0.0),
                                        //             iconPadding:
                                        //             EdgeInsetsDirectional.fromSTEB(
                                        //                 0.0, 0.0, 0.0, 0.0),
                                        //             color: Color(0xff96c93e),
                                        //             textStyle: FlutterFlowTheme.of(context)
                                        //                 .titleSmall
                                        //                 .override(
                                        //               fontFamily: 'Readex Pro',
                                        //               color: Colors.white,
                                        //             ),
                                        //             elevation: 3.0,
                                        //             borderSide: BorderSide(
                                        //               color: Colors.transparent,
                                        //               width: 1.0,
                                        //             ),
                                        //             borderRadius:
                                        //             BorderRadius.circular(12.0),
                                        //           ),
                                        //         ),
                                        //       ),
                                        //     ),
                                        //   ],
                                        // ),
                                        Row(
                                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                          children: [
                                            Align(
                                              alignment: AlignmentDirectional(0.00, 0.00),
                                              child: Padding(
                                                  padding: EdgeInsetsDirectional.fromSTEB(
                                                      0.0, 10.0, 0.0, 10.0),
                                                  child: InkWell(
                                                    splashColor: Colors.transparent,
                                                    focusColor: Colors.transparent,
                                                    hoverColor: Colors.transparent,
                                                    highlightColor: Colors.transparent,
                                                    onTap: (){
                                                      currentLocation2 = null;
                                                      _distance = null;
                                                      setState(() {
                                                        //index++;
                                                        pressedCase2 = true;
                                                      });
                                                      _getCurrentLocation();
                                                    },
                                                    child: Container(
                                                      width: MediaQuery.sizeOf(context).width * 0.4,
                                                      height: 45,
                                                      decoration: BoxDecoration(
                                                        borderRadius:
                                                        BorderRadius.circular(12.0),
                                                        color: Color(0xff2596be),
                                                      ),
                                                      child: Center(
                                                        child: Text('Try Location \n Again',style: TextStyle(
                                                            fontSize: 15,
                                                            color: Colors.white,
                                                            fontWeight: FontWeight.w600
                                                        ),textAlign: TextAlign.center,),
                                                      ),
                                                    ),
                                                  )
                                              ),
                                            ),
                                            Align(
                                              alignment: AlignmentDirectional(0.00, 0.00),
                                              child: Padding(
                                                  padding: EdgeInsetsDirectional.fromSTEB(
                                                      0.0, 10.0, 0.0, 10.0),
                                                  child: InkWell(
                                                    splashColor: Colors.transparent,
                                                    focusColor: Colors.transparent,
                                                    hoverColor: Colors.transparent,
                                                    highlightColor: Colors.transparent,
                                                    onTap: ()async{
                                                      final result = await Navigator.push(
                                                        context,
                                                        PageRouteBuilder(
                                                          pageBuilder: (_, __, ___) => QRCodeReader(),
                                                          transitionsBuilder: (_, a1, a2, child) =>
                                                              SlideTransition(
                                                                position: Tween(
                                                                    begin: Offset(1, 0),
                                                                    end: Offset(0, 0))
                                                                    .animate(a1),
                                                                child: child,
                                                              ),
                                                        ),
                                                      );

                                                      if (!mounted) return;

                                                      if (result == 'Decrypt!') {
                                                        openDialog();
                                                        await currentUserReference!.update({
                                                          ...mapToFirestore(
                                                            {
                                                              'checkedCampains': FieldValue.arrayUnion(
                                                                  [widget.document?.reference]),
                                                            },
                                                          ),
                                                        });
                                                        Timer(Duration(seconds: 4), () {
                                                          Navigator.of(context).pop();
                                                          Navigator.of(context).pop();
                                                          showSnackBarText('QR Code read successfully!', context, true);
                                                        });
                                                      }
                                                    },
                                                    child: Container(
                                                      width: MediaQuery.sizeOf(context).width * 0.4,
                                                      height: 45,
                                                      decoration: BoxDecoration(
                                                        borderRadius:
                                                        BorderRadius.circular(12.0),
                                                        color: Color(0xff96c93e),
                                                      ),
                                                      child: Center(
                                                        child: Text('Scan QR Code \n(Required)',style: TextStyle(
                                                            color: Colors.white,
                                                            fontSize: 15,
                                                            fontWeight: FontWeight.w600
                                                        ),textAlign: TextAlign.center,),
                                                      ),
                                                    ),
                                                  )
                                              ),
                                            ),
                                          ],
                                        ),
                                        Padding(
                                          padding: EdgeInsetsDirectional.fromSTEB(
                                              0.0, 15.0, 0.0, 0.0),
                                          child: Center(
                                            child: SizedBox(
                                                width: MediaQuery.sizeOf(context).width * 0.9,
                                                height: 330,
                                                child:  BaseMap(loc: latlng2.LatLng(currentLocation2!.latitude!,currentLocation2!.longitude!) ,)),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                // if(pressedCase2)
                                //   Padding(
                                //     padding: EdgeInsetsDirectional.fromSTEB(
                                //         15.0, 15.0, 15.0, 0.0),
                                //     child: Column(
                                //       mainAxisSize: MainAxisSize.max,
                                //       children: [
                                //         Padding(
                                //           padding: EdgeInsetsDirectional.fromSTEB(
                                //               0.0, 0.0, 0.0, 0.0),
                                //           child: Container(
                                //             width: MediaQuery.sizeOf(context).width * 0.8,
                                //             decoration: BoxDecoration(
                                //               color: FlutterFlowTheme.of(context)
                                //                   .secondaryBackground,
                                //             ),
                                //             child: Text(
                                //               'Doesn\'t seem like you are close – want to scan the QR Code',
                                //               textAlign: TextAlign.center,
                                //               style: FlutterFlowTheme.of(context)
                                //                   .bodyMedium
                                //                   .override(
                                //                 fontFamily: 'Readex Pro',
                                //                 fontSize: 20.0,
                                //                 fontWeight: FontWeight.w500,
                                //               ),
                                //             ),
                                //           ),
                                //         ),
                                //         Padding(
                                //           padding: EdgeInsetsDirectional.fromSTEB(
                                //               0.0, 20.0, 0.0, 0.0),
                                //           child: Row(
                                //             mainAxisSize: MainAxisSize.max,
                                //             mainAxisAlignment:
                                //             MainAxisAlignment.spaceAround,
                                //             children: [
                                //               Align(
                                //                 alignment:
                                //                 AlignmentDirectional(0.00, 0.00),
                                //                 child: FFButtonWidget(
                                //                   onPressed: () async{
                                //                     final result = await Navigator.push(
                                //                       context,
                                //                       PageRouteBuilder(
                                //                         pageBuilder: (_, __, ___) => QRCodeReader(),
                                //                         transitionsBuilder: (_, a1, a2, child) =>
                                //                             SlideTransition(
                                //                               position: Tween(
                                //                                   begin: Offset(1, 0),
                                //                                   end: Offset(0, 0))
                                //                                   .animate(a1),
                                //                               child: child,
                                //                             ),
                                //                       ),
                                //                     );
                                //
                                //                     if (!mounted) return;
                                //
                                //                     if (result == 'Decrypt!') {
                                //                       openDialog();
                                //                         await currentUserReference!.update({
                                //                       ...mapToFirestore(
                                //                       {
                                //                       'checkedCampains': FieldValue.arrayUnion(
                                //                       [widget.document?.reference]),
                                //                       },
                                //                       ),
                                //                       });
                                //                       Timer(Duration(seconds: 4), () {
                                //                         Navigator.of(context).pop();
                                //                         Navigator.of(context).pop();
                                //                         showSnackBarText('QR Code read successfully!', context, true);
                                //                       });
                                //                     }
                                //                   },
                                //                   text: 'Scan QR Code',
                                //                   options: FFButtonOptions(
                                //                     width: MediaQuery.sizeOf(context)
                                //                         .width *
                                //                         0.4,
                                //                     height: 45.0,
                                //                     padding:
                                //                     EdgeInsetsDirectional.fromSTEB(
                                //                         0.0, 0.0, 0.0, 0.0),
                                //                     iconPadding:
                                //                     EdgeInsetsDirectional.fromSTEB(
                                //                         0.0, 0.0, 0.0, 0.0),
                                //                     color: FlutterFlowTheme.of(context)
                                //                         .primary,
                                //                     textStyle:
                                //                     FlutterFlowTheme.of(context)
                                //                         .titleSmall
                                //                         .override(
                                //                       fontFamily: 'Readex Pro',
                                //                       color: Colors.white,
                                //                     ),
                                //                     elevation: 3.0,
                                //                     borderSide: BorderSide(
                                //                       color: Colors.transparent,
                                //                       width: 1.0,
                                //                     ),
                                //                     borderRadius:
                                //                     BorderRadius.circular(12.0),
                                //                   ),
                                //                 ),
                                //               ),
                                //               Align(
                                //                 alignment:
                                //                 AlignmentDirectional(0.00, 0.00),
                                //                 child: FFButtonWidget(
                                //                   onPressed: () async {
                                //                     Navigator.pop(context);
                                //                   },
                                //                   text: 'Nah... I\'m good',
                                //                   options: FFButtonOptions(
                                //                     width: MediaQuery.sizeOf(context)
                                //                         .width *
                                //                         0.4,
                                //                     height: 45.0,
                                //                     padding:
                                //                     EdgeInsetsDirectional.fromSTEB(
                                //                         0.0, 0.0, 0.0, 0.0),
                                //                     iconPadding:
                                //                     EdgeInsetsDirectional.fromSTEB(
                                //                         0.0, 0.0, 0.0, 0.0),
                                //                     color: FlutterFlowTheme.of(context)
                                //                         .error,
                                //                     textStyle:
                                //                     FlutterFlowTheme.of(context)
                                //                         .titleSmall
                                //                         .override(
                                //                       fontFamily: 'Readex Pro',
                                //                       color: Colors.white,
                                //                     ),
                                //                     elevation: 3.0,
                                //                     borderSide: BorderSide(
                                //                       color: Colors.transparent,
                                //                       width: 1.0,
                                //                     ),
                                //                     borderRadius:
                                //                     BorderRadius.circular(12.0),
                                //                   ),
                                //                 ),
                                //               ),
                                //             ],
                                //           ),
                                //         ),
                                //         Padding(
                                //           padding: EdgeInsetsDirectional.fromSTEB(
                                //               0.0, 20.0, 0.0, 0.0),
                                //           child: Text(
                                //             'Scan the QR to Check in',
                                //             textAlign: TextAlign.center,
                                //             style: FlutterFlowTheme.of(context)
                                //                 .bodyMedium
                                //                 .override(
                                //               fontFamily: 'Readex Pro',
                                //               fontSize: 22.0,
                                //               fontWeight: FontWeight.w500,
                                //             ),
                                //           ),
                                //         ),
                                //         Padding(
                                //           padding: EdgeInsetsDirectional.fromSTEB(
                                //               0.0, 20.0, 0.0, 0.0),
                                //           child: Icon(
                                //             Icons.remove_circle_outline,
                                //             color: Colors.grey,
                                //             size: 200.0,
                                //           ),
                                //         ),
                                //       ],
                                //     ),
                                //   ),
                                // if (!widget.isQRRequired!)
                                //   Padding(
                                //     padding: EdgeInsetsDirectional.fromSTEB(
                                //         15.0, 15.0, 15.0, 15.0),
                                //     child: Container(
                                //       width: double.infinity,
                                //       decoration: BoxDecoration(
                                //         color: FlutterFlowTheme.of(context)
                                //             .secondaryBackground,
                                //         border: Border.all(
                                //           color: FlutterFlowTheme.of(context).primaryText,
                                //         ),
                                //       ),
                                //       child: Column(
                                //         mainAxisSize: MainAxisSize.max,
                                //         children: [
                                //           Padding(
                                //             padding: EdgeInsetsDirectional.fromSTEB(
                                //                 0.0, 20.0, 0.0, 0.0),
                                //             child: Container(
                                //               width:
                                //                   MediaQuery.sizeOf(context).width * 0.8,
                                //               decoration: BoxDecoration(
                                //                 color: FlutterFlowTheme.of(context)
                                //                     .secondaryBackground,
                                //               ),
                                //               child: Text(
                                //                 'You\'re close & Checked in',
                                //                 textAlign: TextAlign.center,
                                //                 style: FlutterFlowTheme.of(context)
                                //                     .bodyMedium
                                //                     .override(
                                //                       fontFamily: 'Readex Pro',
                                //                       fontSize: 22.0,
                                //                       fontWeight: FontWeight.w500,
                                //                     ),
                                //               ),
                                //             ),
                                //           ),
                                //           Padding(
                                //             padding: EdgeInsetsDirectional.fromSTEB(
                                //                 0.0, 20.0, 0.0, 0.0),
                                //             child: Icon(
                                //               Icons.check_box,
                                //               color: Color(0xFF24963D),
                                //               size: 200.0,
                                //             ),
                                //           ),
                                //           Padding(
                                //             padding: EdgeInsetsDirectional.fromSTEB(
                                //                 0.0, 25.0, 0.0, 15.0),
                                //             child: Row(
                                //               mainAxisSize: MainAxisSize.max,
                                //               mainAxisAlignment:
                                //                   MainAxisAlignment.spaceAround,
                                //               children: [
                                //                 Align(
                                //                   alignment:
                                //                       AlignmentDirectional(0.00, 0.00),
                                //                   child: FFButtonWidget(
                                //                     onPressed: () {
                                //                       print('Button pressed ...');
                                //                     },
                                //                     text: 'Cancel',
                                //                     options: FFButtonOptions(
                                //                       width: MediaQuery.sizeOf(context)
                                //                               .width *
                                //                           0.35,
                                //                       height: 40.0,
                                //                       padding:
                                //                           EdgeInsetsDirectional.fromSTEB(
                                //                               0.0, 0.0, 0.0, 0.0),
                                //                       iconPadding:
                                //                           EdgeInsetsDirectional.fromSTEB(
                                //                               0.0, 0.0, 0.0, 0.0),
                                //                       color: FlutterFlowTheme.of(context)
                                //                           .primary,
                                //                       textStyle:
                                //                           FlutterFlowTheme.of(context)
                                //                               .titleSmall
                                //                               .override(
                                //                                 fontFamily: 'Readex Pro',
                                //                                 color: Colors.white,
                                //                               ),
                                //                       elevation: 3.0,
                                //                       borderSide: BorderSide(
                                //                         color: Colors.transparent,
                                //                         width: 1.0,
                                //                       ),
                                //                       borderRadius:
                                //                           BorderRadius.circular(12.0),
                                //                     ),
                                //                   ),
                                //                 ),
                                //               ],
                                //             ),
                                //           ),
                                //         ],
                                //       ),
                                //     ),
                                //   ),
                                // if (!widget.isQRRequired!)
                                //   Padding(
                                //     padding: EdgeInsetsDirectional.fromSTEB(
                                //         15.0, 15.0, 15.0, 15.0),
                                //     child: Container(
                                //       width: double.infinity,
                                //       decoration: BoxDecoration(
                                //         color: FlutterFlowTheme.of(context)
                                //             .secondaryBackground,
                                //         border: Border.all(
                                //           color: FlutterFlowTheme.of(context).primaryText,
                                //         ),
                                //       ),
                                //       child: Column(
                                //         mainAxisSize: MainAxisSize.max,
                                //         children: [
                                //           Container(
                                //             width: MediaQuery.sizeOf(context).width * 0.8,
                                //             decoration: BoxDecoration(
                                //               color: FlutterFlowTheme.of(context)
                                //                   .secondaryBackground,
                                //             ),
                                //             child: Padding(
                                //               padding: EdgeInsetsDirectional.fromSTEB(
                                //                   0.0, 20.0, 0.0, 20.0),
                                //               child: Text(
                                //                 'Hmmm you seem a bit far – try \ngeolocation again or scan the QR Code at that location ',
                                //                 textAlign: TextAlign.center,
                                //                 style: FlutterFlowTheme.of(context)
                                //                     .bodyMedium
                                //                     .override(
                                //                       fontFamily: 'Readex Pro',
                                //                       fontSize: 20.0,
                                //                       fontWeight: FontWeight.w500,
                                //                     ),
                                //               ),
                                //             ),
                                //           ),
                                //           Align(
                                //             alignment: AlignmentDirectional(0.00, 0.00),
                                //             child: Padding(
                                //               padding: EdgeInsetsDirectional.fromSTEB(
                                //                   0.0, 0.0, 0.0, 20.0),
                                //               child: FFButtonWidget(
                                //                 onPressed: () {
                                //                   print('Button pressed ...');
                                //                 },
                                //                 text: 'Try Geolocation Again\n',
                                //                 options: FFButtonOptions(
                                //                   width:
                                //                       MediaQuery.sizeOf(context).width *
                                //                           0.7,
                                //                   height: 45.0,
                                //                   padding: EdgeInsetsDirectional.fromSTEB(
                                //                       0.0, 0.0, 0.0, 0.0),
                                //                   iconPadding:
                                //                       EdgeInsetsDirectional.fromSTEB(
                                //                           0.0, 0.0, 0.0, 0.0),
                                //                   color: FlutterFlowTheme.of(context)
                                //                       .primary,
                                //                   textStyle: FlutterFlowTheme.of(context)
                                //                       .titleSmall
                                //                       .override(
                                //                         fontFamily: 'Readex Pro',
                                //                         color: Colors.white,
                                //                       ),
                                //                   elevation: 3.0,
                                //                   borderSide: BorderSide(
                                //                     color: Colors.transparent,
                                //                     width: 1.0,
                                //                   ),
                                //                   borderRadius:
                                //                       BorderRadius.circular(12.0),
                                //                 ),
                                //               ),
                                //             ),
                                //           ),
                                //         ],
                                //       ),
                                //     ),
                                //   ),
                              ],
                            ),
                          ),
                        ),
                    ],
                  ),
              // if(widget.document!.qRCodeAvailable)
              //   if(widget.document!.requiresQRScan)
              //     Column(
              //       children: [
              //         if (currentLocation2 == null)
              //           Column(
              //             children: [
              //               Padding(
              //                 padding: EdgeInsetsDirectional.fromSTEB(0.0, 10.0, 0.0, 0.0),
              //                 child: Container(
              //                   width: MediaQuery.sizeOf(context).width * 0.8,
              //                   child: Center(
              //                     child: Text(
              //                       _distance == null ? 'Let’s Check you in!' : _distance! < 30 ? 'You’re Checked In!' : 'Hmmm – You seem far way',
              //                       style: FlutterFlowTheme.of(context).headlineMedium.override(
              //                           fontFamily: 'Open Sans',
              //                           fontWeight: FontWeight.w700,
              //                           fontSize: 20
              //                       ),
              //                       textAlign: TextAlign.center,
              //                     ),
              //                   ),
              //                 ),
              //               ),
              //               Padding(
              //                   padding: EdgeInsetsDirectional.fromSTEB(0.0, 10.0, 0.0, 10.0),
              //                   child: Row(
              //                     mainAxisAlignment: MainAxisAlignment.center,
              //                     children: [
              //                       Text(
              //                         'Checking current location:  ',
              //                         style: FlutterFlowTheme.of(context)
              //                             .bodyMedium
              //                             .override(
              //                             fontFamily: 'Readex Pro',
              //                             fontSize: 14.0,
              //                             color:Colors.black.withOpacity(0.4)
              //                         ),
              //                       ),
              //                       SizedBox(
              //                         width: 5,
              //                       ),
              //                       if(permissionDenied )
              //                         Text(
              //                           'Permission Denied',
              //                           style: FlutterFlowTheme.of(context)
              //                               .bodyMedium
              //                               .override(
              //                               fontFamily: 'Readex Pro',
              //                               fontSize: 14.0,
              //                               color: Colors.red
              //                           ),
              //                         ),
              //                       if (_distance != null)
              //                         Text(
              //                           '${shortenDistance(_distance!)}',
              //                           style: FlutterFlowTheme.of(context)
              //                               .bodyMedium
              //                               .override(
              //                               fontFamily: 'Readex Pro',
              //                               fontSize: 14.0,
              //                               color: _distance! > 30? Colors.red : Colors.green
              //                           ),
              //                         ),
              //                       if (_distance == null && !permissionDenied)
              //                         SizedBox(
              //                           height: 20,
              //                           width: 20,
              //                           child: CircularProgressIndicator(
              //                             color: Colors.black,
              //                           ),
              //                         )
              //                     ],
              //                   )
              //               ),
              //               Padding(
              //                 padding: EdgeInsetsDirectional.fromSTEB(
              //                     0.0, 30.0, 0.0, 0.0),
              //                 child: Center(
              //                   child: SizedBox(
              //                     height: 40,
              //                     width: 40,
              //                     child: CircularProgressIndicator(
              //                       color: Colors.black,
              //                     ),
              //                   ),
              //                 ),
              //               ),
              //             ],
              //           ),
              //         if (_distance != null)
              //           Padding(
              //             padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
              //             child: Container(
              //               width: double.infinity,
              //               decoration: BoxDecoration(
              //                 color: FlutterFlowTheme.of(context).secondaryBackground,
              //               ),
              //               child: Column(
              //                 mainAxisSize: MainAxisSize.max,
              //                 children: [
              //                   if(_distance! < 30)
              //                     Padding(
              //                       padding: EdgeInsetsDirectional.fromSTEB(
              //                           15.0, 15.0, 15.0, 15.0),
              //                       child: Column(
              //                         mainAxisSize: MainAxisSize.max,
              //                         children: [
              //                           Padding(
              //                             padding: EdgeInsetsDirectional.fromSTEB(
              //                                 0.0, 0.0, 0.0, 0.0),
              //                             child: Container(
              //                               width:
              //                               MediaQuery.sizeOf(context).width * 0.8,
              //                               decoration: BoxDecoration(
              //                                 color: FlutterFlowTheme.of(context)
              //                                     .secondaryBackground,
              //                               ),
              //                               child: Text(
              //                                 'Almost... Now you need to \n scan the QR Code',
              //                                 textAlign: TextAlign.center,
              //                                 style: FlutterFlowTheme.of(context)
              //                                     .bodyMedium
              //                                     .override(
              //                                   fontFamily: 'Readex Pro',
              //                                   fontSize: 20.0,
              //                                   fontWeight: FontWeight.w500,
              //                                 ),
              //                               ),
              //                             ),
              //                           ),
              //                           Padding(
              //                             padding: EdgeInsetsDirectional.fromSTEB(
              //                                 0.0, 20.0, 0.0, 0.0),
              //                             child: Row(
              //                               mainAxisSize: MainAxisSize.max,
              //                               mainAxisAlignment:
              //                               MainAxisAlignment.spaceAround,
              //                               children: [
              //                                 Align(
              //                                   alignment:
              //                                   AlignmentDirectional(0.00, 0.00),
              //                                   child: FFButtonWidget(
              //                                     onPressed: () async{
              //                                       final result = await Navigator.push(
              //                                         context,
              //                                         PageRouteBuilder(
              //                                           pageBuilder: (_, __, ___) => QRCodeReader(),
              //                                           transitionsBuilder: (_, a1, a2, child) =>
              //                                               SlideTransition(
              //                                                 position: Tween(
              //                                                     begin: Offset(1, 0),
              //                                                     end: Offset(0, 0))
              //                                                     .animate(a1),
              //                                                 child: child,
              //                                               ),
              //                                         ),
              //                                       );
              //
              //                                       if (!mounted) return;
              //
              //                                       if (result == 'Decrypt!') {
              //                                         openDialog();
              //                                           await currentUserReference!.update({
              //                                         ...mapToFirestore(
              //                                         {
              //                                         'checkedCampains': FieldValue.arrayUnion(
              //                                         [widget.document?.reference]),
              //                                         },
              //                                         ),
              //                                         });
              //                                         Timer(Duration(seconds: 4), () {
              //                                           Navigator.of(context).pop();
              //                                           Navigator.of(context).pop();
              //                                           showSnackBarText('QR Code read successfully!', context, true);
              //                                         });
              //                                       }
              //                                     },
              //                                     text: 'Scan QR Code',
              //                                     options: FFButtonOptions(
              //                                       width: MediaQuery.sizeOf(context)
              //                                           .width *
              //                                           0.4,
              //                                       height: 45.0,
              //                                       padding:
              //                                       EdgeInsetsDirectional.fromSTEB(
              //                                           0.0, 0.0, 0.0, 0.0),
              //                                       iconPadding:
              //                                       EdgeInsetsDirectional.fromSTEB(
              //                                           0.0, 0.0, 0.0, 0.0),
              //                                       color: FlutterFlowTheme.of(context)
              //                                           .primary,
              //                                       textStyle:
              //                                       FlutterFlowTheme.of(context)
              //                                           .titleSmall
              //                                           .override(
              //                                         fontFamily: 'Readex Pro',
              //                                         color: Colors.white,
              //                                       ),
              //                                       elevation: 3.0,
              //                                       borderSide: BorderSide(
              //                                         color: Colors.transparent,
              //                                         width: 1.0,
              //                                       ),
              //                                       borderRadius:
              //                                       BorderRadius.circular(12.0),
              //                                     ),
              //                                   ),
              //                                 ),
              //                               ],
              //                             ),
              //                           ),
              //                           Padding(
              //                             padding: EdgeInsetsDirectional.fromSTEB(
              //                                 0.0, 20.0, 0.0, 0.0),
              //                             child: Text(
              //                               'Ask someone where the QR code is',
              //                               textAlign: TextAlign.center,
              //                               style: FlutterFlowTheme.of(context)
              //                                   .bodyMedium
              //                                   .override(
              //                                 fontFamily: 'Readex Pro',
              //                                 fontSize: 22.0,
              //                                 fontWeight: FontWeight.w500,
              //                               ),
              //                             ),
              //                           ),
              //                           Padding(
              //                             padding: EdgeInsetsDirectional.fromSTEB(
              //                                 0.0, 0.0, 0.0, 0.0),
              //                             child: Icon(
              //                               Icons.remove_circle_outline,
              //                               color: Colors.grey,
              //                               size: 200.0,
              //                             ),
              //                           ),
              //                         ],
              //                       ),
              //                     ),
              //                   if(_distance! > 30)
              //                     if(!pressedCase3)
              //                       Padding(
              //                         padding: EdgeInsetsDirectional.fromSTEB(
              //                             0.0, 0.0, 0.0, 0.0),
              //                         child: Column(
              //                           mainAxisSize: MainAxisSize.max,
              //                           children: [
              //                             Padding(
              //                               padding: EdgeInsetsDirectional.fromSTEB(0.0, 10.0, 0.0, 0.0),
              //                               child: Container(
              //                                 width: MediaQuery.sizeOf(context).width * 0.8,
              //                                 child: Center(
              //                                   child: Text(
              //                                     _distance == null ? 'Let’s Check you in!' : _distance! < 30 ? 'You’re Checked In!' : 'Hmmm – You seem far way',
              //                                     style: FlutterFlowTheme.of(context).headlineMedium.override(
              //                                         fontFamily: 'Open Sans',
              //                                         fontWeight: FontWeight.w700,
              //                                         fontSize: 20
              //                                     ),
              //                                     textAlign: TextAlign.center,
              //                                   ),
              //                                 ),
              //                               ),
              //                             ),
              //                             Padding(
              //                                 padding: EdgeInsetsDirectional.fromSTEB(0.0, 10.0, 0.0, 10.0),
              //                                 child: Row(
              //                                   mainAxisAlignment: MainAxisAlignment.center,
              //                                   children: [
              //                                     Text(
              //                                       'Checking current location:  ',
              //                                       style: FlutterFlowTheme.of(context)
              //                                           .bodyMedium
              //                                           .override(
              //                                           fontFamily: 'Readex Pro',
              //                                           fontSize: 14.0,
              //                                           color:Colors.black.withOpacity(0.4)
              //                                       ),
              //                                     ),
              //                                     SizedBox(
              //                                       width: 5,
              //                                     ),
              //                                     if(permissionDenied )
              //                                       Text(
              //                                         'Permission Denied',
              //                                         style: FlutterFlowTheme.of(context)
              //                                             .bodyMedium
              //                                             .override(
              //                                             fontFamily: 'Readex Pro',
              //                                             fontSize: 14.0,
              //                                             color: Colors.red
              //                                         ),
              //                                       ),
              //                                     if (_distance != null)
              //                                       Text(
              //                                         '${shortenDistance(_distance!)}',
              //                                         style: FlutterFlowTheme.of(context)
              //                                             .bodyMedium
              //                                             .override(
              //                                             fontFamily: 'Readex Pro',
              //                                             fontSize: 14.0,
              //                                             color: _distance! > 30? Colors.red : Colors.green
              //                                         ),
              //                                       ),
              //                                     if (_distance == null && !permissionDenied)
              //                                       SizedBox(
              //                                         height: 20,
              //                                         width: 20,
              //                                         child: CircularProgressIndicator(
              //                                           color: Colors.black,
              //                                         ),
              //                                       )
              //                                   ],
              //                                 )
              //                             ),
              //                             Align(
              //                               alignment: AlignmentDirectional(0.00, 0.00),
              //                               child: Padding(
              //                                 padding: EdgeInsetsDirectional.fromSTEB(
              //                                     0.0, 10.0, 0.0, 10.0),
              //                                 child: FFButtonWidget(
              //                                   onPressed: () {
              //                                     currentLocation2 = null;
              //                                     _distance = null;
              //                                     setState(() {
              //                                       //index++;
              //                                       pressedCase3 = true;
              //                                     });
              //                                     _getCurrentLocation();
              //                                   },
              //                                   text: 'Try Getting Location again',
              //                                   options: FFButtonOptions(
              //                                     width:
              //                                     MediaQuery.sizeOf(context).width *
              //                                         0.8,
              //                                     height: 45.0,
              //                                     padding: EdgeInsetsDirectional.fromSTEB(
              //                                         0.0, 0.0, 0.0, 0.0),
              //                                     iconPadding:
              //                                     EdgeInsetsDirectional.fromSTEB(
              //                                         0.0, 0.0, 0.0, 0.0),
              //                                     color: FlutterFlowTheme.of(context).error,
              //                                     textStyle: FlutterFlowTheme.of(context)
              //                                         .titleSmall
              //                                         .override(
              //                                       fontFamily: 'Readex Pro',
              //                                       color: Colors.white,
              //                                     ),
              //                                     elevation: 3.0,
              //                                     borderSide: BorderSide(
              //                                       color: Colors.transparent,
              //                                       width: 1.0,
              //                                     ),
              //                                     borderRadius:
              //                                     BorderRadius.circular(12.0),
              //                                   ),
              //                                 ),
              //                               ),
              //                             ),
              //                             Padding(
              //                               padding: EdgeInsetsDirectional.fromSTEB(
              //                                   0.0, 15.0, 0.0, 0.0),
              //                               child: Center(
              //                                 child: SizedBox(
              //                                     width: MediaQuery.sizeOf(context).width * 0.9,
              //                                     height: 330,
              //                                     child:  BaseMap(loc: latlng2.LatLng(currentLocation2!.latitude!,currentLocation2!.longitude!) ,)),
              //                               ),
              //                             ),
              //                           ],
              //                         ),
              //                       ),
              //                     if(pressedCase3)
              //                       Padding(
              //                       padding: EdgeInsetsDirectional.fromSTEB(
              //                           15.0, 15.0, 15.0, 15.0),
              //                       child: Column(
              //                         mainAxisSize: MainAxisSize.max,
              //                         children: [
              //                           Padding(
              //                             padding: EdgeInsetsDirectional.fromSTEB(
              //                                 0.0, 0.0, 0.0, 0.0),
              //                             child: Container(width:
              //                               MediaQuery.sizeOf(context).width * 0.8,
              //                               decoration: BoxDecoration(
              //                                 color: FlutterFlowTheme.of(context)
              //                                     .secondaryBackground,
              //                               ),
              //                               child: Text(
              //                                 'Doesn\'t seem like you are \nclose – Lets try to scan \n the QR Code',
              //                                 textAlign: TextAlign.center,
              //                                 style: FlutterFlowTheme.of(context)
              //                                     .bodyMedium
              //                                     .override(
              //                                   fontFamily: 'Readex Pro',
              //                                   fontSize: 20.0,
              //                                   fontWeight: FontWeight.w500,
              //                                 ),
              //                               ),
              //                             ),
              //                           ),
              //                           Padding(
              //                             padding: EdgeInsetsDirectional.fromSTEB(
              //                                 0.0, 20.0, 0.0, 0.0),
              //                             child: Row(
              //                               mainAxisSize: MainAxisSize.max,
              //                               mainAxisAlignment:
              //                               MainAxisAlignment.spaceAround,
              //                               children: [
              //                                 Align(
              //                                   alignment:
              //                                   AlignmentDirectional(0.00, 0.00),
              //                                   child: FFButtonWidget(
              //                                     onPressed: () async{
              //                                       final result = await Navigator.push(
              //                                         context,
              //                                         PageRouteBuilder(
              //                                           pageBuilder: (_, __, ___) => QRCodeReader(),
              //                                           transitionsBuilder: (_, a1, a2, child) =>
              //                                               SlideTransition(
              //                                                 position: Tween(
              //                                                     begin: Offset(1, 0),
              //                                                     end: Offset(0, 0))
              //                                                     .animate(a1),
              //                                                 child: child,
              //                                               ),
              //                                         ),
              //                                       );
              //
              //                                       if (!mounted) return;
              //
              //                                       if (result == 'Decrypt!') {
              //                                         openDialog();
              //                                         await currentUserReference!.update({
              //                                           ...mapToFirestore(
              //                                             {
              //                                               'checkedCampains': FieldValue.arrayUnion(
              //                                                   [widget.document?.reference]),
              //                                             },
              //                                           ),
              //                                         });
              //                                         Timer(Duration(seconds: 4), () {
              //                                           Navigator.of(context).pop();
              //                                           Navigator.of(context).pop();
              //                                           showSnackBarText('QR Code read successfully!', context, true);
              //                                         });
              //                                       }
              //                                     },
              //                                     text: 'Scan QR Code',
              //                                     options: FFButtonOptions(
              //                                       width: MediaQuery.sizeOf(context)
              //                                           .width *
              //                                           0.4,
              //                                       height: 45.0,
              //                                       padding:
              //                                       EdgeInsetsDirectional.fromSTEB(
              //                                           0.0, 0.0, 0.0, 0.0),
              //                                       iconPadding:
              //                                       EdgeInsetsDirectional.fromSTEB(
              //                                           0.0, 0.0, 0.0, 0.0),
              //                                       color: FlutterFlowTheme.of(context)
              //                                           .primary,
              //                                       textStyle:
              //                                       FlutterFlowTheme.of(context)
              //                                           .titleSmall
              //                                           .override(
              //                                         fontFamily: 'Readex Pro',
              //                                         color: Colors.white,
              //                                       ),
              //                                       elevation: 3.0,
              //                                       borderSide: BorderSide(
              //                                         color: Colors.transparent,
              //                                         width: 1.0,
              //                                       ),
              //                                       borderRadius:
              //                                       BorderRadius.circular(12.0),
              //                                     ),
              //                                   ),
              //                                 ),
              //                               ],
              //                             ),
              //                           ),
              //                           Padding(
              //                             padding: EdgeInsetsDirectional.fromSTEB(
              //                                 0.0, 20.0, 0.0, 0.0),
              //                             child: Text(
              //                               'You need to Scan the QR to Check in',
              //                               textAlign: TextAlign.center,
              //                               style: FlutterFlowTheme.of(context)
              //                                   .bodyMedium
              //                                   .override(
              //                                 fontFamily: 'Readex Pro',
              //                                 fontSize: 22.0,
              //                                 fontWeight: FontWeight.w500,
              //                               ),
              //                             ),
              //                           ),
              //                           Padding(
              //                             padding: EdgeInsetsDirectional.fromSTEB(
              //                                 0.0, 0.0, 0.0, 0.0),
              //                             child: Icon(
              //                               Icons.remove_circle_outline,
              //                               color: Colors.grey,
              //                               size: 200.0,
              //                             ),
              //                           ),
              //                         ],
              //                       ),
              //                     ),
              //                   // if (!widget.isQRRequired!)
              //                   //   Padding(
              //                   //     padding: EdgeInsetsDirectional.fromSTEB(
              //                   //         15.0, 15.0, 15.0, 15.0),
              //                   //     child: Container(
              //                   //       width: double.infinity,
              //                   //       decoration: BoxDecoration(
              //                   //         color: FlutterFlowTheme.of(context)
              //                   //             .secondaryBackground,
              //                   //         border: Border.all(
              //                   //           color: FlutterFlowTheme.of(context).primaryText,
              //                   //         ),
              //                   //       ),
              //                   //       child: Column(
              //                   //         mainAxisSize: MainAxisSize.max,
              //                   //         children: [
              //                   //           Padding(
              //                   //             padding: EdgeInsetsDirectional.fromSTEB(
              //                   //                 0.0, 20.0, 0.0, 0.0),
              //                   //             child: Container(
              //                   //               width:
              //                   //                   MediaQuery.sizeOf(context).width * 0.8,
              //                   //               decoration: BoxDecoration(
              //                   //                 color: FlutterFlowTheme.of(context)
              //                   //                     .secondaryBackground,
              //                   //               ),
              //                   //               child: Text(
              //                   //                 'You\'re close & Checked in',
              //                   //                 textAlign: TextAlign.center,
              //                   //                 style: FlutterFlowTheme.of(context)
              //                   //                     .bodyMedium
              //                   //                     .override(
              //                   //                       fontFamily: 'Readex Pro',
              //                   //                       fontSize: 22.0,
              //                   //                       fontWeight: FontWeight.w500,
              //                   //                     ),
              //                   //               ),
              //                   //             ),
              //                   //           ),
              //                   //           Padding(
              //                   //             padding: EdgeInsetsDirectional.fromSTEB(
              //                   //                 0.0, 20.0, 0.0, 0.0),
              //                   //             child: Icon(
              //                   //               Icons.check_box,
              //                   //               color: Color(0xFF24963D),
              //                   //               size: 200.0,
              //                   //             ),
              //                   //           ),
              //                   //           Padding(
              //                   //             padding: EdgeInsetsDirectional.fromSTEB(
              //                   //                 0.0, 25.0, 0.0, 15.0),
              //                   //             child: Row(
              //                   //               mainAxisSize: MainAxisSize.max,
              //                   //               mainAxisAlignment:
              //                   //                   MainAxisAlignment.spaceAround,
              //                   //               children: [
              //                   //                 Align(
              //                   //                   alignment:
              //                   //                       AlignmentDirectional(0.00, 0.00),
              //                   //                   child: FFButtonWidget(
              //                   //                     onPressed: () {
              //                   //                       print('Button pressed ...');
              //                   //                     },
              //                   //                     text: 'Cancel',
              //                   //                     options: FFButtonOptions(
              //                   //                       width: MediaQuery.sizeOf(context)
              //                   //                               .width *
              //                   //                           0.35,
              //                   //                       height: 40.0,
              //                   //                       padding:
              //                   //                           EdgeInsetsDirectional.fromSTEB(
              //                   //                               0.0, 0.0, 0.0, 0.0),
              //                   //                       iconPadding:
              //                   //                           EdgeInsetsDirectional.fromSTEB(
              //                   //                               0.0, 0.0, 0.0, 0.0),
              //                   //                       color: FlutterFlowTheme.of(context)
              //                   //                           .primary,
              //                   //                       textStyle:
              //                   //                           FlutterFlowTheme.of(context)
              //                   //                               .titleSmall
              //                   //                               .override(
              //                   //                                 fontFamily: 'Readex Pro',
              //                   //                                 color: Colors.white,
              //                   //                               ),
              //                   //                       elevation: 3.0,
              //                   //                       borderSide: BorderSide(
              //                   //                         color: Colors.transparent,
              //                   //                         width: 1.0,
              //                   //                       ),
              //                   //                       borderRadius:
              //                   //                           BorderRadius.circular(12.0),
              //                   //                     ),
              //                   //                   ),
              //                   //                 ),
              //                   //               ],
              //                   //             ),
              //                   //           ),
              //                   //         ],
              //                   //       ),
              //                   //     ),
              //                   //   ),
              //                   // if (!widget.isQRRequired!)
              //                   //   Padding(
              //                   //     padding: EdgeInsetsDirectional.fromSTEB(
              //                   //         15.0, 15.0, 15.0, 15.0),
              //                   //     child: Container(
              //                   //       width: double.infinity,
              //                   //       decoration: BoxDecoration(
              //                   //         color: FlutterFlowTheme.of(context)
              //                   //             .secondaryBackground,
              //                   //         border: Border.all(
              //                   //           color: FlutterFlowTheme.of(context).primaryText,
              //                   //         ),
              //                   //       ),
              //                   //       child: Column(
              //                   //         mainAxisSize: MainAxisSize.max,
              //                   //         children: [
              //                   //           Container(
              //                   //             width: MediaQuery.sizeOf(context).width * 0.8,
              //                   //             decoration: BoxDecoration(
              //                   //               color: FlutterFlowTheme.of(context)
              //                   //                   .secondaryBackground,
              //                   //             ),
              //                   //             child: Padding(
              //                   //               padding: EdgeInsetsDirectional.fromSTEB(
              //                   //                   0.0, 20.0, 0.0, 20.0),
              //                   //               child: Text(
              //                   //                 'Hmmm you seem a bit far – try \ngeolocation again or scan the QR Code at that location ',
              //                   //                 textAlign: TextAlign.center,
              //                   //                 style: FlutterFlowTheme.of(context)
              //                   //                     .bodyMedium
              //                   //                     .override(
              //                   //                       fontFamily: 'Readex Pro',
              //                   //                       fontSize: 20.0,
              //                   //                       fontWeight: FontWeight.w500,
              //                   //                     ),
              //                   //               ),
              //                   //             ),
              //                   //           ),
              //                   //           Align(
              //                   //             alignment: AlignmentDirectional(0.00, 0.00),
              //                   //             child: Padding(
              //                   //               padding: EdgeInsetsDirectional.fromSTEB(
              //                   //                   0.0, 0.0, 0.0, 20.0),
              //                   //               child: FFButtonWidget(
              //                   //                 onPressed: () {
              //                   //                   print('Button pressed ...');
              //                   //                 },
              //                   //                 text: 'Try Geolocation Again\n',
              //                   //                 options: FFButtonOptions(
              //                   //                   width:
              //                   //                       MediaQuery.sizeOf(context).width *
              //                   //                           0.7,
              //                   //                   height: 45.0,
              //                   //                   padding: EdgeInsetsDirectional.fromSTEB(
              //                   //                       0.0, 0.0, 0.0, 0.0),
              //                   //                   iconPadding:
              //                   //                       EdgeInsetsDirectional.fromSTEB(
              //                   //                           0.0, 0.0, 0.0, 0.0),
              //                   //                   color: FlutterFlowTheme.of(context)
              //                   //                       .primary,
              //                   //                   textStyle: FlutterFlowTheme.of(context)
              //                   //                       .titleSmall
              //                   //                       .override(
              //                   //                         fontFamily: 'Readex Pro',
              //                   //                         color: Colors.white,
              //                   //                       ),
              //                   //                   elevation: 3.0,
              //                   //                   borderSide: BorderSide(
              //                   //                     color: Colors.transparent,
              //                   //                     width: 1.0,
              //                   //                   ),
              //                   //                   borderRadius:
              //                   //                       BorderRadius.circular(12.0),
              //                   //                 ),
              //                   //               ),
              //                   //             ),
              //                   //           ),
              //                   //         ],
              //                   //       ),
              //                   //     ),
              //                   //   ),
              //                 ],
              //               ),
              //             ),
              //           ),
              //       ],
              //     ),

              // Padding(
              //   padding: EdgeInsetsDirectional.fromSTEB(16.0, 4.0, 0.0, 0.0),
              //   child: Text(
              //     'Checking current location: ',
              //     style: FlutterFlowTheme.of(context).labelMedium.override(
              //           fontFamily: 'Readex Pro',
              //           fontSize: 16.0,
              //           fontWeight: FontWeight.w300,
              //         ),
              //   ),
              // ),
              // if(pressed == false)
              //   Column(
              //   children: [
              //     Padding(
              //         padding: EdgeInsetsDirectional.fromSTEB(
              //             0.0, 4.0, 0.0, 0.0),
              //         child: Row(
              //           mainAxisAlignment: MainAxisAlignment.center,
              //           children: [
              //             Text(
              //               'Checking location - ',
              //               style: FlutterFlowTheme.of(context)
              //                   .bodyMedium
              //                   .override(
              //                   fontFamily: 'Readex Pro',
              //                   fontSize: 18.0,
              //                   color:Colors.black.withOpacity(0.5)
              //               ),
              //             ),
              //             SizedBox(
              //               width: 5,
              //             ),
              //             if(permissionDenied )
              //               Text(
              //                 'Permission Denied',
              //                 style: FlutterFlowTheme.of(context)
              //                     .bodyMedium
              //                     .override(
              //                     fontFamily: 'Readex Pro',
              //                     fontSize: 18.0,
              //                     color: Colors.red
              //                 ),
              //               ),
              //             if (_distance != null)
              //               Text(
              //                 '${shortenDistance(_distance!)} away',
              //                 style: FlutterFlowTheme.of(context)
              //                     .bodyMedium
              //                     .override(
              //                     fontFamily: 'Readex Pro',
              //                     fontSize: 18.0,
              //                     color: _distance! > 656 ? Colors.red : Colors.green
              //                 ),
              //               ),
              //             if (_distance == null && !permissionDenied)
              //               SizedBox(
              //                 height: 20,
              //                 width: 20,
              //                 child: CircularProgressIndicator(
              //                   color: Colors.black,
              //                 ),
              //               )
              //           ],
              //         )
              //     ),
              //     if (currentLocation2 == null)
              //       Padding(
              //         padding: EdgeInsetsDirectional.fromSTEB(
              //             0.0, 30.0, 0.0, 0.0),
              //         child: Center(
              //           child: SizedBox(
              //             height: 40,
              //             width: 40,
              //             child: CircularProgressIndicator(
              //               color: Colors.black,
              //             ),
              //           ),
              //         ),
              //       ),
              //     if(currentLocation2 != null)
              //       Padding(
              //         padding: EdgeInsetsDirectional.fromSTEB(
              //             0.0, 15.0, 0.0, 0.0),
              //         child: Center(
              //           child: SizedBox(
              //               width: MediaQuery.sizeOf(context).width * 0.9,
              //               height: 330,
              //               child:  BaseMap(loc: latlng2.LatLng(currentLocation2!.latitude!,currentLocation2!.longitude!) ,)),
              //         ),
              //       ),
              //     // if(currentLocation2 != null)
              //     //   Align(
              //     //     alignment: AlignmentDirectional(0.00, 0.00),
              //     //     child: Padding(
              //     //       padding: EdgeInsetsDirectional.fromSTEB(
              //     //           0.0, 15.0, 0.0, 20.0),
              //     //       child: FFButtonWidget(
              //     //         onPressed: () async{
              //     //           setState(() {
              //     //             pressed = true;
              //     //           });
              //     //           if(_distance! < 656){
              //     //             await currentUserReference!.update({
              //     //               ...mapToFirestore(
              //     //                 {
              //     //                   'checkedCampains': FieldValue.arrayUnion(
              //     //                       [widget.document?.reference]),
              //     //                 },
              //     //               ),
              //     //             });
              //     //           }
              //     //
              //     //         },
              //     //         text: 'Continue',
              //     //         options: FFButtonOptions(
              //     //           width:
              //     //           MediaQuery.sizeOf(context).width *
              //     //               0.7,
              //     //           height: 45.0,
              //     //           padding: EdgeInsetsDirectional.fromSTEB(
              //     //               0.0, 0.0, 0.0, 0.0),
              //     //           iconPadding:
              //     //           EdgeInsetsDirectional.fromSTEB(
              //     //               0.0, 0.0, 0.0, 0.0),
              //     //           color: FlutterFlowTheme.of(context)
              //     //               .primary,
              //     //           textStyle: FlutterFlowTheme.of(context)
              //     //               .titleSmall
              //     //               .override(
              //     //             fontFamily: 'Readex Pro',
              //     //             color: Colors.white,
              //     //           ),
              //     //           elevation: 3.0,
              //     //           borderSide: BorderSide(
              //     //             color: Colors.transparent,
              //     //             width: 1.0,
              //     //           ),
              //     //           borderRadius:
              //     //           BorderRadius.circular(12.0),
              //     //         ),
              //     //       ),
              //     //     ),
              //     //   ),
              //   ],
              // ),
              // if(!widget.document!.qRCodeAvailable)
              //   Padding(
              //     padding: EdgeInsetsDirectional.fromSTEB(0.0, 15.0, 0.0, 0.0),
              //     child: Container(
              //       width: double.infinity,
              //       decoration: BoxDecoration(
              //         color: FlutterFlowTheme.of(context).secondaryBackground,
              //       ),
              //       child: Column(
              //         mainAxisSize: MainAxisSize.max,
              //         children: [
              //           if(_distance! < 656)
              //             Padding(
              //               padding: EdgeInsetsDirectional.fromSTEB(
              //                   15.0, 15.0, 15.0, 15.0),
              //               child: Container(
              //                 width: double.infinity,
              //                 decoration: BoxDecoration(
              //                   color: FlutterFlowTheme.of(context)
              //                       .secondaryBackground,
              //                   border: Border.all(
              //                     color: FlutterFlowTheme.of(context).primaryText,
              //                   ),
              //                 ),
              //                 child: Column(
              //                   mainAxisSize: MainAxisSize.max,
              //                   children: [
              //                     Padding(
              //                       padding: EdgeInsetsDirectional.fromSTEB(
              //                           0.0, 20.0, 0.0, 0.0),
              //                       child: Container(
              //                         width:
              //                         MediaQuery.sizeOf(context).width * 0.8,
              //                         decoration: BoxDecoration(
              //                           color: FlutterFlowTheme.of(context)
              //                               .secondaryBackground,
              //                         ),
              //                         child: Text(
              //                           'Want to get extra points? find and scan the QR Code',
              //                           textAlign: TextAlign.center,
              //                           style: FlutterFlowTheme.of(context)
              //                               .bodyMedium
              //                               .override(
              //                             fontFamily: 'Readex Pro',
              //                             fontSize: 20.0,
              //                             fontWeight: FontWeight.w500,
              //                           ),
              //                         ),
              //                       ),
              //                     ),
              //                     Padding(
              //                       padding: EdgeInsetsDirectional.fromSTEB(
              //                           0.0, 20.0, 0.0, 0.0),
              //                       child: Row(
              //                         mainAxisSize: MainAxisSize.max,
              //                         mainAxisAlignment:
              //                         MainAxisAlignment.spaceAround,
              //                         children: [
              //                           Align(
              //                             alignment:
              //                             AlignmentDirectional(0.00, 0.00),
              //                             child: FFButtonWidget(
              //                               onPressed: () async{
              //                                 final result = await Navigator.push(
              //                                   context,
              //                                   PageRouteBuilder(
              //                                     pageBuilder: (_, __, ___) => QRCodeReader(),
              //                                     transitionsBuilder: (_, a1, a2, child) =>
              //                                         SlideTransition(
              //                                           position: Tween(
              //                                               begin: Offset(1, 0),
              //                                               end: Offset(0, 0))
              //                                               .animate(a1),
              //                                           child: child,
              //                                         ),
              //                                   ),
              //                                 );
              //
              //                                 if (!mounted) return;
              //
              //                                 if (result == 'Decrypt!') {
              //                                   openDialog();
              //                                   //   await currentUserReference!.update({
              //                                   // ...mapToFirestore(
              //                                   // {
              //                                   // 'checkedCampains': FieldValue.arrayUnion(
              //                                   // [widget.document?.reference]),
              //                                   // },
              //                                   // ),
              //                                   // });
              //                                   Timer(Duration(seconds: 4), () {
              //                                     Navigator.of(context).pop();
              //                                     Navigator.of(context).pop();
              //                                     showSnackBarText('Point added to your score', context, true);
              //                                   });
              //                                 }
              //                               },
              //                               text: 'Scan QR Code',
              //                               options: FFButtonOptions(
              //                                 width: MediaQuery.sizeOf(context)
              //                                     .width *
              //                                     0.4,
              //                                 height: 45.0,
              //                                 padding:
              //                                 EdgeInsetsDirectional.fromSTEB(
              //                                     0.0, 0.0, 0.0, 0.0),
              //                                 iconPadding:
              //                                 EdgeInsetsDirectional.fromSTEB(
              //                                     0.0, 0.0, 0.0, 0.0),
              //                                 color: FlutterFlowTheme.of(context)
              //                                     .primary,
              //                                 textStyle:
              //                                 FlutterFlowTheme.of(context)
              //                                     .titleSmall
              //                                     .override(
              //                                   fontFamily: 'Readex Pro',
              //                                   color: Colors.white,
              //                                 ),
              //                                 elevation: 3.0,
              //                                 borderSide: BorderSide(
              //                                   color: Colors.transparent,
              //                                   width: 1.0,
              //                                 ),
              //                                 borderRadius:
              //                                 BorderRadius.circular(12.0),
              //                               ),
              //                             ),
              //                           ),
              //                           Align(
              //                             alignment:
              //                             AlignmentDirectional(0.00, 0.00),
              //                             child: FFButtonWidget(
              //                               onPressed: () async {
              //                                 Navigator.pop(context);
              //                               },
              //                               text: 'Nah... I\'m good',
              //                               options: FFButtonOptions(
              //                                 width: MediaQuery.sizeOf(context)
              //                                     .width *
              //                                     0.4,
              //                                 height: 45.0,
              //                                 padding:
              //                                 EdgeInsetsDirectional.fromSTEB(
              //                                     0.0, 0.0, 0.0, 0.0),
              //                                 iconPadding:
              //                                 EdgeInsetsDirectional.fromSTEB(
              //                                     0.0, 0.0, 0.0, 0.0),
              //                                 color: FlutterFlowTheme.of(context)
              //                                     .error,
              //                                 textStyle:
              //                                 FlutterFlowTheme.of(context)
              //                                     .titleSmall
              //                                     .override(
              //                                   fontFamily: 'Readex Pro',
              //                                   color: Colors.white,
              //                                 ),
              //                                 elevation: 3.0,
              //                                 borderSide: BorderSide(
              //                                   color: Colors.transparent,
              //                                   width: 1.0,
              //                                 ),
              //                                 borderRadius:
              //                                 BorderRadius.circular(12.0),
              //                               ),
              //                             ),
              //                           ),
              //                         ],
              //                       ),
              //                     ),
              //                     Padding(
              //                       padding: EdgeInsetsDirectional.fromSTEB(
              //                           0.0, 20.0, 0.0, 0.0),
              //                       child: Text(
              //                         'You\'re close & Checked in',
              //                         textAlign: TextAlign.center,
              //                         style: FlutterFlowTheme.of(context)
              //                             .bodyMedium
              //                             .override(
              //                           fontFamily: 'Readex Pro',
              //                           fontSize: 22.0,
              //                           fontWeight: FontWeight.w500,
              //                         ),
              //                       ),
              //                     ),
              //                     Padding(
              //                       padding: EdgeInsetsDirectional.fromSTEB(
              //                           0.0, 20.0, 0.0, 0.0),
              //                       child: Icon(
              //                         Icons.check_box,
              //                         color: Color(0xFF24963D),
              //                         size: 200.0,
              //                       ),
              //                     ),
              //                   ],
              //                 ),
              //               ),
              //             ),
              //           if(_distance! > 656)
              //             Padding(
              //               padding: EdgeInsetsDirectional.fromSTEB(
              //                   15.0, 15.0, 15.0, 15.0),
              //               child: Container(
              //                 width: double.infinity,
              //                 decoration: BoxDecoration(
              //                   color: FlutterFlowTheme.of(context)
              //                       .secondaryBackground,
              //                   border: Border.all(
              //                     color: FlutterFlowTheme.of(context).primaryText,
              //                   ),
              //                 ),
              //                 child: Column(
              //                   mainAxisSize: MainAxisSize.max,
              //                   children: [
              //                     Padding(
              //                       padding: EdgeInsetsDirectional.fromSTEB(
              //                           0.0, 20.0, 0.0, 0.0),
              //                       child: Container(
              //                         width:
              //                         MediaQuery.sizeOf(context).width * 0.8,
              //                         decoration: BoxDecoration(
              //                           color: FlutterFlowTheme.of(context)
              //                               .secondaryBackground,
              //                         ),
              //                         child: Text(
              //                           'Hmmm you seem a bit far – try \ngeolocation again or scan the QR Code at that location ',
              //                           textAlign: TextAlign.center,
              //                           style: FlutterFlowTheme.of(context)
              //                               .bodyMedium
              //                               .override(
              //                             fontFamily: 'Readex Pro',
              //                             fontSize: 20.0,
              //                             fontWeight: FontWeight.w500,
              //                           ),
              //                         ),
              //                       ),
              //                     ),
              //                     Align(
              //                       alignment: AlignmentDirectional(0.00, 0.00),
              //                       child: Padding(
              //                         padding: EdgeInsetsDirectional.fromSTEB(
              //                             0.0, 20.0, 0.0, 20.0),
              //                         child: FFButtonWidget(
              //                           onPressed: () {
              //                             currentLocation2 = null;
              //                             _distance = null;
              //                             setState(() {
              //                               pressed = false;
              //                             });
              //                             _getCurrentLocation();
              //                           },
              //                           text: 'Try Geolocation Again\n',
              //                           options: FFButtonOptions(
              //                             width:
              //                             MediaQuery.sizeOf(context).width *
              //                                 0.7,
              //                             height: 45.0,
              //                             padding: EdgeInsetsDirectional.fromSTEB(
              //                                 0.0, 0.0, 0.0, 0.0),
              //                             iconPadding:
              //                             EdgeInsetsDirectional.fromSTEB(
              //                                 0.0, 0.0, 0.0, 0.0),
              //                             color: FlutterFlowTheme.of(context)
              //                                 .primary,
              //                             textStyle: FlutterFlowTheme.of(context)
              //                                 .titleSmall
              //                                 .override(
              //                               fontFamily: 'Readex Pro',
              //                               color: Colors.white,
              //                             ),
              //                             elevation: 3.0,
              //                             borderSide: BorderSide(
              //                               color: Colors.transparent,
              //                               width: 1.0,
              //                             ),
              //                             borderRadius:
              //                             BorderRadius.circular(12.0),
              //                           ),
              //                         ),
              //                       ),
              //                     ),
              //                     Align(
              //                       alignment: AlignmentDirectional(0.00, 0.00),
              //                       child: Padding(
              //                         padding: EdgeInsetsDirectional.fromSTEB(
              //                             0.0, 0.0, 0.0, 20.0),
              //                         child: FFButtonWidget(
              //                           onPressed: () async{
              //                             final result = await Navigator.push(
              //                               context,
              //                               PageRouteBuilder(
              //                                 pageBuilder: (_, __, ___) => QRCodeReader(),
              //                                 transitionsBuilder: (_, a1, a2, child) =>
              //                                     SlideTransition(
              //                                       position: Tween(
              //                                           begin: Offset(1, 0),
              //                                           end: Offset(0, 0))
              //                                           .animate(a1),
              //                                       child: child,
              //                                     ),
              //                               ),
              //                             );
              //
              //                             if (!mounted) return;
              //
              //                             if (result == 'Decrypt!') {
              //                               openDialog();
              //                               await currentUserReference!.update({
              //                                 ...mapToFirestore(
              //                                   {
              //                                     'checkedCampains': FieldValue.arrayUnion(
              //                                         [widget.document?.reference]),
              //                                   },
              //                                 ),
              //                               });
              //                               Timer(Duration(seconds: 4), () {
              //                                 Navigator.of(context).pop();
              //                                 Navigator.of(context).pop();
              //                               });
              //                             }
              //                           },
              //                           text: 'Scan QR Code',
              //                           options: FFButtonOptions(
              //                             width:
              //                             MediaQuery.sizeOf(context).width *
              //                                 0.7,
              //                             height: 45.0,
              //                             padding: EdgeInsetsDirectional.fromSTEB(
              //                                 0.0, 0.0, 0.0, 0.0),
              //                             iconPadding:
              //                             EdgeInsetsDirectional.fromSTEB(
              //                                 0.0, 0.0, 0.0, 0.0),
              //                             color:
              //                             FlutterFlowTheme.of(context).error,
              //                             textStyle: FlutterFlowTheme.of(context)
              //                                 .titleSmall
              //                                 .override(
              //                               fontFamily: 'Readex Pro',
              //                               color: Colors.white,
              //                             ),
              //                             elevation: 3.0,
              //                             borderSide: BorderSide(
              //                               color: Colors.transparent,
              //                               width: 1.0,
              //                             ),
              //                             borderRadius:
              //                             BorderRadius.circular(12.0),
              //                           ),
              //                         ),
              //                       ),
              //                     ),
              //                   ],
              //                 ),
              //               ),
              //             ),
              //           // if (!widget.isQRRequired!)
              //           //   Padding(
              //           //     padding: EdgeInsetsDirectional.fromSTEB(
              //           //         15.0, 15.0, 15.0, 15.0),
              //           //     child: Container(
              //           //       width: double.infinity,
              //           //       decoration: BoxDecoration(
              //           //         color: FlutterFlowTheme.of(context)
              //           //             .secondaryBackground,
              //           //         border: Border.all(
              //           //           color: FlutterFlowTheme.of(context).primaryText,
              //           //         ),
              //           //       ),
              //           //       child: Column(
              //           //         mainAxisSize: MainAxisSize.max,
              //           //         children: [
              //           //           Padding(
              //           //             padding: EdgeInsetsDirectional.fromSTEB(
              //           //                 0.0, 20.0, 0.0, 0.0),
              //           //             child: Container(
              //           //               width:
              //           //                   MediaQuery.sizeOf(context).width * 0.8,
              //           //               decoration: BoxDecoration(
              //           //                 color: FlutterFlowTheme.of(context)
              //           //                     .secondaryBackground,
              //           //               ),
              //           //               child: Text(
              //           //                 'You\'re close & Checked in',
              //           //                 textAlign: TextAlign.center,
              //           //                 style: FlutterFlowTheme.of(context)
              //           //                     .bodyMedium
              //           //                     .override(
              //           //                       fontFamily: 'Readex Pro',
              //           //                       fontSize: 22.0,
              //           //                       fontWeight: FontWeight.w500,
              //           //                     ),
              //           //               ),
              //           //             ),
              //           //           ),
              //           //           Padding(
              //           //             padding: EdgeInsetsDirectional.fromSTEB(
              //           //                 0.0, 20.0, 0.0, 0.0),
              //           //             child: Icon(
              //           //               Icons.check_box,
              //           //               color: Color(0xFF24963D),
              //           //               size: 200.0,
              //           //             ),
              //           //           ),
              //           //           Padding(
              //           //             padding: EdgeInsetsDirectional.fromSTEB(
              //           //                 0.0, 25.0, 0.0, 15.0),
              //           //             child: Row(
              //           //               mainAxisSize: MainAxisSize.max,
              //           //               mainAxisAlignment:
              //           //                   MainAxisAlignment.spaceAround,
              //           //               children: [
              //           //                 Align(
              //           //                   alignment:
              //           //                       AlignmentDirectional(0.00, 0.00),
              //           //                   child: FFButtonWidget(
              //           //                     onPressed: () {
              //           //                       print('Button pressed ...');
              //           //                     },
              //           //                     text: 'Cancel',
              //           //                     options: FFButtonOptions(
              //           //                       width: MediaQuery.sizeOf(context)
              //           //                               .width *
              //           //                           0.35,
              //           //                       height: 40.0,
              //           //                       padding:
              //           //                           EdgeInsetsDirectional.fromSTEB(
              //           //                               0.0, 0.0, 0.0, 0.0),
              //           //                       iconPadding:
              //           //                           EdgeInsetsDirectional.fromSTEB(
              //           //                               0.0, 0.0, 0.0, 0.0),
              //           //                       color: FlutterFlowTheme.of(context)
              //           //                           .primary,
              //           //                       textStyle:
              //           //                           FlutterFlowTheme.of(context)
              //           //                               .titleSmall
              //           //                               .override(
              //           //                                 fontFamily: 'Readex Pro',
              //           //                                 color: Colors.white,
              //           //                               ),
              //           //                       elevation: 3.0,
              //           //                       borderSide: BorderSide(
              //           //                         color: Colors.transparent,
              //           //                         width: 1.0,
              //           //                       ),
              //           //                       borderRadius:
              //           //                           BorderRadius.circular(12.0),
              //           //                     ),
              //           //                   ),
              //           //                 ),
              //           //               ],
              //           //             ),
              //           //           ),
              //           //         ],
              //           //       ),
              //           //     ),
              //           //   ),
              //           // if (!widget.isQRRequired!)
              //           //   Padding(
              //           //     padding: EdgeInsetsDirectional.fromSTEB(
              //           //         15.0, 15.0, 15.0, 15.0),
              //           //     child: Container(
              //           //       width: double.infinity,
              //           //       decoration: BoxDecoration(
              //           //         color: FlutterFlowTheme.of(context)
              //           //             .secondaryBackground,
              //           //         border: Border.all(
              //           //           color: FlutterFlowTheme.of(context).primaryText,
              //           //         ),
              //           //       ),
              //           //       child: Column(
              //           //         mainAxisSize: MainAxisSize.max,
              //           //         children: [
              //           //           Container(
              //           //             width: MediaQuery.sizeOf(context).width * 0.8,
              //           //             decoration: BoxDecoration(
              //           //               color: FlutterFlowTheme.of(context)
              //           //                   .secondaryBackground,
              //           //             ),
              //           //             child: Padding(
              //           //               padding: EdgeInsetsDirectional.fromSTEB(
              //           //                   0.0, 20.0, 0.0, 20.0),
              //           //               child: Text(
              //           //                 'Hmmm you seem a bit far – try \ngeolocation again or scan the QR Code at that location ',
              //           //                 textAlign: TextAlign.center,
              //           //                 style: FlutterFlowTheme.of(context)
              //           //                     .bodyMedium
              //           //                     .override(
              //           //                       fontFamily: 'Readex Pro',
              //           //                       fontSize: 20.0,
              //           //                       fontWeight: FontWeight.w500,
              //           //                     ),
              //           //               ),
              //           //             ),
              //           //           ),
              //           //           Align(
              //           //             alignment: AlignmentDirectional(0.00, 0.00),
              //           //             child: Padding(
              //           //               padding: EdgeInsetsDirectional.fromSTEB(
              //           //                   0.0, 0.0, 0.0, 20.0),
              //           //               child: FFButtonWidget(
              //           //                 onPressed: () {
              //           //                   print('Button pressed ...');
              //           //                 },
              //           //                 text: 'Try Geolocation Again\n',
              //           //                 options: FFButtonOptions(
              //           //                   width:
              //           //                       MediaQuery.sizeOf(context).width *
              //           //                           0.7,
              //           //                   height: 45.0,
              //           //                   padding: EdgeInsetsDirectional.fromSTEB(
              //           //                       0.0, 0.0, 0.0, 0.0),
              //           //                   iconPadding:
              //           //                       EdgeInsetsDirectional.fromSTEB(
              //           //                           0.0, 0.0, 0.0, 0.0),
              //           //                   color: FlutterFlowTheme.of(context)
              //           //                       .primary,
              //           //                   textStyle: FlutterFlowTheme.of(context)
              //           //                       .titleSmall
              //           //                       .override(
              //           //                         fontFamily: 'Readex Pro',
              //           //                         color: Colors.white,
              //           //                       ),
              //           //                   elevation: 3.0,
              //           //                   borderSide: BorderSide(
              //           //                     color: Colors.transparent,
              //           //                     width: 1.0,
              //           //                   ),
              //           //                   borderRadius:
              //           //                       BorderRadius.circular(12.0),
              //           //                 ),
              //           //               ),
              //           //             ),
              //           //           ),
              //           //         ],
              //           //       ),
              //           //     ),
              //           //   ),
              //         ],
              //       ),
              //     ),
              //   ),
              // if(pressed && widget.document!.requiresQRScan)
              //   Padding(
              //     padding: EdgeInsetsDirectional.fromSTEB(0.0, 15.0, 0.0, 0.0),
              //     child: Container(
              //       width: double.infinity,
              //       decoration: BoxDecoration(
              //         color: FlutterFlowTheme.of(context).secondaryBackground,
              //       ),
              //       child: Column(
              //         mainAxisSize: MainAxisSize.max,
              //         children: [
              //             if(_distance! < 656)
              //               Padding(
              //                 padding: EdgeInsetsDirectional.fromSTEB(
              //                     15.0, 15.0, 15.0, 15.0),
              //                 child: Container(
              //                   width: double.infinity,
              //                   decoration: BoxDecoration(
              //                     color: FlutterFlowTheme.of(context)
              //                         .secondaryBackground,
              //                     border: Border.all(
              //                       color: FlutterFlowTheme.of(context).primaryText,
              //                     ),
              //                   ),
              //                   child: Column(
              //                     mainAxisSize: MainAxisSize.max,
              //                     children: [
              //                       Padding(
              //                         padding: EdgeInsetsDirectional.fromSTEB(
              //                             0.0, 20.0, 0.0, 0.0),
              //                         child: Container(
              //                           width:
              //                           MediaQuery.sizeOf(context).width * 0.8,
              //                           decoration: BoxDecoration(
              //                             color: FlutterFlowTheme.of(context)
              //                                 .secondaryBackground,
              //                           ),
              //                           child: Text(
              //                             'Want to get extra points? find and scan the QR Code',
              //                             textAlign: TextAlign.center,
              //                             style: FlutterFlowTheme.of(context)
              //                                 .bodyMedium
              //                                 .override(
              //                               fontFamily: 'Readex Pro',
              //                               fontSize: 20.0,
              //                               fontWeight: FontWeight.w500,
              //                             ),
              //                           ),
              //                         ),
              //                       ),
              //                       Padding(
              //                         padding: EdgeInsetsDirectional.fromSTEB(
              //                             0.0, 20.0, 0.0, 0.0),
              //                         child: Row(
              //                           mainAxisSize: MainAxisSize.max,
              //                           mainAxisAlignment:
              //                           MainAxisAlignment.spaceAround,
              //                           children: [
              //                             Align(
              //                               alignment:
              //                               AlignmentDirectional(0.00, 0.00),
              //                               child: FFButtonWidget(
              //                                 onPressed: () async{
              //                                   final result = await Navigator.push(
              //                                     context,
              //                                     PageRouteBuilder(
              //                                       pageBuilder: (_, __, ___) => QRCodeReader(),
              //                                       transitionsBuilder: (_, a1, a2, child) =>
              //                                           SlideTransition(
              //                                             position: Tween(
              //                                                 begin: Offset(1, 0),
              //                                                 end: Offset(0, 0))
              //                                                 .animate(a1),
              //                                             child: child,
              //                                           ),
              //                                     ),
              //                                   );
              //
              //                                   if (!mounted) return;
              //
              //                                   if (result == 'Decrypt!') {
              //                                     openDialog();
              //                                   //   await currentUserReference!.update({
              //                                   // ...mapToFirestore(
              //                                   // {
              //                                   // 'checkedCampains': FieldValue.arrayUnion(
              //                                   // [widget.document?.reference]),
              //                                   // },
              //                                   // ),
              //                                   // });
              //                                   Timer(Duration(seconds: 4), () {
              //                                   Navigator.of(context).pop();
              //                                   Navigator.of(context).pop();
              //                                   showSnackBarText('Point added to your score', context, true);
              //                                   });
              //                                 }
              //                                 },
              //                                 text: 'Scan QR Code',
              //                                 options: FFButtonOptions(
              //                                   width: MediaQuery.sizeOf(context)
              //                                       .width *
              //                                       0.4,
              //                                   height: 45.0,
              //                                   padding:
              //                                   EdgeInsetsDirectional.fromSTEB(
              //                                       0.0, 0.0, 0.0, 0.0),
              //                                   iconPadding:
              //                                   EdgeInsetsDirectional.fromSTEB(
              //                                       0.0, 0.0, 0.0, 0.0),
              //                                   color: FlutterFlowTheme.of(context)
              //                                       .primary,
              //                                   textStyle:
              //                                   FlutterFlowTheme.of(context)
              //                                       .titleSmall
              //                                       .override(
              //                                     fontFamily: 'Readex Pro',
              //                                     color: Colors.white,
              //                                   ),
              //                                   elevation: 3.0,
              //                                   borderSide: BorderSide(
              //                                     color: Colors.transparent,
              //                                     width: 1.0,
              //                                   ),
              //                                   borderRadius:
              //                                   BorderRadius.circular(12.0),
              //                                 ),
              //                               ),
              //                             ),
              //                             Align(
              //                               alignment:
              //                               AlignmentDirectional(0.00, 0.00),
              //                               child: FFButtonWidget(
              //                                 onPressed: () async {
              //                                   Navigator.pop(context);
              //                                 },
              //                                 text: 'Nah... I\'m good',
              //                                 options: FFButtonOptions(
              //                                   width: MediaQuery.sizeOf(context)
              //                                       .width *
              //                                       0.4,
              //                                   height: 45.0,
              //                                   padding:
              //                                   EdgeInsetsDirectional.fromSTEB(
              //                                       0.0, 0.0, 0.0, 0.0),
              //                                   iconPadding:
              //                                   EdgeInsetsDirectional.fromSTEB(
              //                                       0.0, 0.0, 0.0, 0.0),
              //                                   color: FlutterFlowTheme.of(context)
              //                                       .error,
              //                                   textStyle:
              //                                   FlutterFlowTheme.of(context)
              //                                       .titleSmall
              //                                       .override(
              //                                     fontFamily: 'Readex Pro',
              //                                     color: Colors.white,
              //                                   ),
              //                                   elevation: 3.0,
              //                                   borderSide: BorderSide(
              //                                     color: Colors.transparent,
              //                                     width: 1.0,
              //                                   ),
              //                                   borderRadius:
              //                                   BorderRadius.circular(12.0),
              //                                 ),
              //                               ),
              //                             ),
              //                           ],
              //                         ),
              //                       ),
              //                       Padding(
              //                         padding: EdgeInsetsDirectional.fromSTEB(
              //                             0.0, 20.0, 0.0, 0.0),
              //                         child: Text(
              //                           'You\'re close & Checked in',
              //                           textAlign: TextAlign.center,
              //                           style: FlutterFlowTheme.of(context)
              //                               .bodyMedium
              //                               .override(
              //                             fontFamily: 'Readex Pro',
              //                             fontSize: 22.0,
              //                             fontWeight: FontWeight.w500,
              //                           ),
              //                         ),
              //                       ),
              //                       Padding(
              //                         padding: EdgeInsetsDirectional.fromSTEB(
              //                             0.0, 20.0, 0.0, 0.0),
              //                         child: Icon(
              //                           Icons.check_box,
              //                           color: Color(0xFF24963D),
              //                           size: 200.0,
              //                         ),
              //                       ),
              //                     ],
              //                   ),
              //                 ),
              //               ),
              //             if(_distance! > 656)
              //               Padding(
              //               padding: EdgeInsetsDirectional.fromSTEB(
              //                   15.0, 15.0, 15.0, 15.0),
              //               child: Container(
              //                 width: double.infinity,
              //                 decoration: BoxDecoration(
              //                   color: FlutterFlowTheme.of(context)
              //                       .secondaryBackground,
              //                   border: Border.all(
              //                     color: FlutterFlowTheme.of(context).primaryText,
              //                   ),
              //                 ),
              //                 child: Column(
              //                   mainAxisSize: MainAxisSize.max,
              //                   children: [
              //                     Padding(
              //                       padding: EdgeInsetsDirectional.fromSTEB(
              //                           0.0, 20.0, 0.0, 0.0),
              //                       child: Container(
              //                         width:
              //                         MediaQuery.sizeOf(context).width * 0.8,
              //                         decoration: BoxDecoration(
              //                           color: FlutterFlowTheme.of(context)
              //                               .secondaryBackground,
              //                         ),
              //                         child: Text(
              //                           'Hmmm you seem a bit far – try \ngeolocation again or scan the QR Code at that location ',
              //                           textAlign: TextAlign.center,
              //                           style: FlutterFlowTheme.of(context)
              //                               .bodyMedium
              //                               .override(
              //                             fontFamily: 'Readex Pro',
              //                             fontSize: 20.0,
              //                             fontWeight: FontWeight.w500,
              //                           ),
              //                         ),
              //                       ),
              //                     ),
              //                     Align(
              //                       alignment: AlignmentDirectional(0.00, 0.00),
              //                       child: Padding(
              //                         padding: EdgeInsetsDirectional.fromSTEB(
              //                             0.0, 20.0, 0.0, 20.0),
              //                         child: FFButtonWidget(
              //                           onPressed: () {
              //                             currentLocation2 = null;
              //                             _distance = null;
              //                             setState(() {
              //                               pressed = false;
              //                             });
              //                             _getCurrentLocation();
              //                           },
              //                           text: 'Try Geolocation Again\n',
              //                           options: FFButtonOptions(
              //                             width:
              //                             MediaQuery.sizeOf(context).width *
              //                                 0.7,
              //                             height: 45.0,
              //                             padding: EdgeInsetsDirectional.fromSTEB(
              //                                 0.0, 0.0, 0.0, 0.0),
              //                             iconPadding:
              //                             EdgeInsetsDirectional.fromSTEB(
              //                                 0.0, 0.0, 0.0, 0.0),
              //                             color: FlutterFlowTheme.of(context)
              //                                 .primary,
              //                             textStyle: FlutterFlowTheme.of(context)
              //                                 .titleSmall
              //                                 .override(
              //                               fontFamily: 'Readex Pro',
              //                               color: Colors.white,
              //                             ),
              //                             elevation: 3.0,
              //                             borderSide: BorderSide(
              //                               color: Colors.transparent,
              //                               width: 1.0,
              //                             ),
              //                             borderRadius:
              //                             BorderRadius.circular(12.0),
              //                           ),
              //                         ),
              //                       ),
              //                     ),
              //                     Align(
              //                       alignment: AlignmentDirectional(0.00, 0.00),
              //                       child: Padding(
              //                         padding: EdgeInsetsDirectional.fromSTEB(
              //                             0.0, 0.0, 0.0, 20.0),
              //                         child: FFButtonWidget(
              //                           onPressed: () async{
              //                             final result = await Navigator.push(
              //                               context,
              //                               PageRouteBuilder(
              //                                 pageBuilder: (_, __, ___) => QRCodeReader(),
              //                                 transitionsBuilder: (_, a1, a2, child) =>
              //                                     SlideTransition(
              //                                       position: Tween(
              //                                           begin: Offset(1, 0),
              //                                           end: Offset(0, 0))
              //                                           .animate(a1),
              //                                       child: child,
              //                                     ),
              //                               ),
              //                             );
              //
              //                             if (!mounted) return;
              //
              //                             if (result == 'Decrypt!') {
              //                               openDialog();
              //                               await currentUserReference!.update({
              //                                 ...mapToFirestore(
              //                                   {
              //                                     'checkedCampains': FieldValue.arrayUnion(
              //                                         [widget.document?.reference]),
              //                                   },
              //                                 ),
              //                               });
              //                               Timer(Duration(seconds: 4), () {
              //                                 Navigator.of(context).pop();
              //                                 Navigator.of(context).pop();
              //                               });
              //                             }
              //                           },
              //                           text: 'Scan QR Code',
              //                           options: FFButtonOptions(
              //                             width:
              //                             MediaQuery.sizeOf(context).width *
              //                                 0.7,
              //                             height: 45.0,
              //                             padding: EdgeInsetsDirectional.fromSTEB(
              //                                 0.0, 0.0, 0.0, 0.0),
              //                             iconPadding:
              //                             EdgeInsetsDirectional.fromSTEB(
              //                                 0.0, 0.0, 0.0, 0.0),
              //                             color:
              //                             FlutterFlowTheme.of(context).error,
              //                             textStyle: FlutterFlowTheme.of(context)
              //                                 .titleSmall
              //                                 .override(
              //                               fontFamily: 'Readex Pro',
              //                               color: Colors.white,
              //                             ),
              //                             elevation: 3.0,
              //                             borderSide: BorderSide(
              //                               color: Colors.transparent,
              //                               width: 1.0,
              //                             ),
              //                             borderRadius:
              //                             BorderRadius.circular(12.0),
              //                           ),
              //                         ),
              //                       ),
              //                     ),
              //                   ],
              //                 ),
              //               ),
              //             ),
              //           // if (!widget.isQRRequired!)
              //           //   Padding(
              //           //     padding: EdgeInsetsDirectional.fromSTEB(
              //           //         15.0, 15.0, 15.0, 15.0),
              //           //     child: Container(
              //           //       width: double.infinity,
              //           //       decoration: BoxDecoration(
              //           //         color: FlutterFlowTheme.of(context)
              //           //             .secondaryBackground,
              //           //         border: Border.all(
              //           //           color: FlutterFlowTheme.of(context).primaryText,
              //           //         ),
              //           //       ),
              //           //       child: Column(
              //           //         mainAxisSize: MainAxisSize.max,
              //           //         children: [
              //           //           Padding(
              //           //             padding: EdgeInsetsDirectional.fromSTEB(
              //           //                 0.0, 20.0, 0.0, 0.0),
              //           //             child: Container(
              //           //               width:
              //           //                   MediaQuery.sizeOf(context).width * 0.8,
              //           //               decoration: BoxDecoration(
              //           //                 color: FlutterFlowTheme.of(context)
              //           //                     .secondaryBackground,
              //           //               ),
              //           //               child: Text(
              //           //                 'You\'re close & Checked in',
              //           //                 textAlign: TextAlign.center,
              //           //                 style: FlutterFlowTheme.of(context)
              //           //                     .bodyMedium
              //           //                     .override(
              //           //                       fontFamily: 'Readex Pro',
              //           //                       fontSize: 22.0,
              //           //                       fontWeight: FontWeight.w500,
              //           //                     ),
              //           //               ),
              //           //             ),
              //           //           ),
              //           //           Padding(
              //           //             padding: EdgeInsetsDirectional.fromSTEB(
              //           //                 0.0, 20.0, 0.0, 0.0),
              //           //             child: Icon(
              //           //               Icons.check_box,
              //           //               color: Color(0xFF24963D),
              //           //               size: 200.0,
              //           //             ),
              //           //           ),
              //           //           Padding(
              //           //             padding: EdgeInsetsDirectional.fromSTEB(
              //           //                 0.0, 25.0, 0.0, 15.0),
              //           //             child: Row(
              //           //               mainAxisSize: MainAxisSize.max,
              //           //               mainAxisAlignment:
              //           //                   MainAxisAlignment.spaceAround,
              //           //               children: [
              //           //                 Align(
              //           //                   alignment:
              //           //                       AlignmentDirectional(0.00, 0.00),
              //           //                   child: FFButtonWidget(
              //           //                     onPressed: () {
              //           //                       print('Button pressed ...');
              //           //                     },
              //           //                     text: 'Cancel',
              //           //                     options: FFButtonOptions(
              //           //                       width: MediaQuery.sizeOf(context)
              //           //                               .width *
              //           //                           0.35,
              //           //                       height: 40.0,
              //           //                       padding:
              //           //                           EdgeInsetsDirectional.fromSTEB(
              //           //                               0.0, 0.0, 0.0, 0.0),
              //           //                       iconPadding:
              //           //                           EdgeInsetsDirectional.fromSTEB(
              //           //                               0.0, 0.0, 0.0, 0.0),
              //           //                       color: FlutterFlowTheme.of(context)
              //           //                           .primary,
              //           //                       textStyle:
              //           //                           FlutterFlowTheme.of(context)
              //           //                               .titleSmall
              //           //                               .override(
              //           //                                 fontFamily: 'Readex Pro',
              //           //                                 color: Colors.white,
              //           //                               ),
              //           //                       elevation: 3.0,
              //           //                       borderSide: BorderSide(
              //           //                         color: Colors.transparent,
              //           //                         width: 1.0,
              //           //                       ),
              //           //                       borderRadius:
              //           //                           BorderRadius.circular(12.0),
              //           //                     ),
              //           //                   ),
              //           //                 ),
              //           //               ],
              //           //             ),
              //           //           ),
              //           //         ],
              //           //       ),
              //           //     ),
              //           //   ),
              //           // if (!widget.isQRRequired!)
              //           //   Padding(
              //           //     padding: EdgeInsetsDirectional.fromSTEB(
              //           //         15.0, 15.0, 15.0, 15.0),
              //           //     child: Container(
              //           //       width: double.infinity,
              //           //       decoration: BoxDecoration(
              //           //         color: FlutterFlowTheme.of(context)
              //           //             .secondaryBackground,
              //           //         border: Border.all(
              //           //           color: FlutterFlowTheme.of(context).primaryText,
              //           //         ),
              //           //       ),
              //           //       child: Column(
              //           //         mainAxisSize: MainAxisSize.max,
              //           //         children: [
              //           //           Container(
              //           //             width: MediaQuery.sizeOf(context).width * 0.8,
              //           //             decoration: BoxDecoration(
              //           //               color: FlutterFlowTheme.of(context)
              //           //                   .secondaryBackground,
              //           //             ),
              //           //             child: Padding(
              //           //               padding: EdgeInsetsDirectional.fromSTEB(
              //           //                   0.0, 20.0, 0.0, 20.0),
              //           //               child: Text(
              //           //                 'Hmmm you seem a bit far – try \ngeolocation again or scan the QR Code at that location ',
              //           //                 textAlign: TextAlign.center,
              //           //                 style: FlutterFlowTheme.of(context)
              //           //                     .bodyMedium
              //           //                     .override(
              //           //                       fontFamily: 'Readex Pro',
              //           //                       fontSize: 20.0,
              //           //                       fontWeight: FontWeight.w500,
              //           //                     ),
              //           //               ),
              //           //             ),
              //           //           ),
              //           //           Align(
              //           //             alignment: AlignmentDirectional(0.00, 0.00),
              //           //             child: Padding(
              //           //               padding: EdgeInsetsDirectional.fromSTEB(
              //           //                   0.0, 0.0, 0.0, 20.0),
              //           //               child: FFButtonWidget(
              //           //                 onPressed: () {
              //           //                   print('Button pressed ...');
              //           //                 },
              //           //                 text: 'Try Geolocation Again\n',
              //           //                 options: FFButtonOptions(
              //           //                   width:
              //           //                       MediaQuery.sizeOf(context).width *
              //           //                           0.7,
              //           //                   height: 45.0,
              //           //                   padding: EdgeInsetsDirectional.fromSTEB(
              //           //                       0.0, 0.0, 0.0, 0.0),
              //           //                   iconPadding:
              //           //                       EdgeInsetsDirectional.fromSTEB(
              //           //                           0.0, 0.0, 0.0, 0.0),
              //           //                   color: FlutterFlowTheme.of(context)
              //           //                       .primary,
              //           //                   textStyle: FlutterFlowTheme.of(context)
              //           //                       .titleSmall
              //           //                       .override(
              //           //                         fontFamily: 'Readex Pro',
              //           //                         color: Colors.white,
              //           //                       ),
              //           //                   elevation: 3.0,
              //           //                   borderSide: BorderSide(
              //           //                     color: Colors.transparent,
              //           //                     width: 1.0,
              //           //                   ),
              //           //                   borderRadius:
              //           //                       BorderRadius.circular(12.0),
              //           //                 ),
              //           //               ),
              //           //             ),
              //           //           ),
              //           //         ],
              //           //       ),
              //           //     ),
              //           //   ),
              //         ],
              //       ),
              //     ),
              //   ),
              // if(pressed && !widget.document!.requiresQRScan)
              //   Padding(
              //     padding: EdgeInsetsDirectional.fromSTEB(0.0, 15.0, 0.0, 0.0),
              //     child: Container(
              //       width: double.infinity,
              //       decoration: BoxDecoration(
              //         color: FlutterFlowTheme.of(context).secondaryBackground,
              //       ),
              //       child: Column(
              //         mainAxisSize: MainAxisSize.max,
              //         children: [
              //         if(_distance! < 656)
              //           Padding(
              //                 padding: EdgeInsetsDirectional.fromSTEB(
              //                     15.0, 15.0, 15.0, 15.0),
              //                 child: Container(
              //                   width: double.infinity,
              //                   decoration: BoxDecoration(
              //                     color: FlutterFlowTheme.of(context)
              //                         .secondaryBackground,
              //                     border: Border.all(
              //                       color: FlutterFlowTheme.of(context).primaryText,
              //                     ),
              //                   ),
              //                   child: Column(
              //                     mainAxisSize: MainAxisSize.max,
              //                     children: [
              //                       Padding(
              //                         padding: EdgeInsetsDirectional.fromSTEB(
              //                             0.0, 20.0, 0.0, 0.0),
              //                         child: Container(
              //                           width:
              //                           MediaQuery.sizeOf(context).width * 0.8,
              //                           decoration: BoxDecoration(
              //                             color: FlutterFlowTheme.of(context)
              //                                 .secondaryBackground,
              //                           ),
              //                           child: Text(
              //                             'You\'re close & Checked in',
              //                             textAlign: TextAlign.center,
              //                             style: FlutterFlowTheme.of(context)
              //                                 .bodyMedium
              //                                 .override(
              //                               fontFamily: 'Readex Pro',
              //                               fontSize: 22.0,
              //                               fontWeight: FontWeight.w500,
              //                             ),
              //                           ),
              //                         ),
              //                       ),
              //                       Padding(
              //                         padding: EdgeInsetsDirectional.fromSTEB(
              //                             0.0, 20.0, 0.0, 0.0),
              //                         child: Icon(
              //                           Icons.check_box,
              //                           color: Color(0xFF24963D),
              //                           size: 200.0,
              //                         ),
              //                       ),
              //                       Padding(
              //                         padding: EdgeInsetsDirectional.fromSTEB(
              //                             0.0, 25.0, 0.0, 15.0),
              //                         child: Row(
              //                           mainAxisSize: MainAxisSize.max,
              //                           mainAxisAlignment:
              //                           MainAxisAlignment.spaceAround,
              //                           children: [
              //                             Align(
              //                               alignment:
              //                               AlignmentDirectional(0.00, 0.00),
              //                               child: FFButtonWidget(
              //                                 onPressed: () {
              //                                  Navigator.pop(context);
              //                                 },
              //                                 text: 'Cancel',
              //                                 options: FFButtonOptions(
              //                                   width: MediaQuery.sizeOf(context)
              //                                       .width *
              //                                       0.35,
              //                                   height: 40.0,
              //                                   padding:
              //                                   EdgeInsetsDirectional.fromSTEB(
              //                                       0.0, 0.0, 0.0, 0.0),
              //                                   iconPadding:
              //                                   EdgeInsetsDirectional.fromSTEB(
              //                                       0.0, 0.0, 0.0, 0.0),
              //                                   color: FlutterFlowTheme.of(context)
              //                                       .primary,
              //                                   textStyle:
              //                                   FlutterFlowTheme.of(context)
              //                                       .titleSmall
              //                                       .override(
              //                                     fontFamily: 'Readex Pro',
              //                                     color: Colors.white,
              //                                   ),
              //                                   elevation: 3.0,
              //                                   borderSide: BorderSide(
              //                                     color: Colors.transparent,
              //                                     width: 1.0,
              //                                   ),
              //                                   borderRadius:
              //                                   BorderRadius.circular(12.0),
              //                                 ),
              //                               ),
              //                             ),
              //                           ],
              //                         ),
              //                       ),
              //                     ],
              //                   ),
              //                 ),
              //               ),
              //         if(_distance! > 656)
              //           Padding(
              //               padding: EdgeInsetsDirectional.fromSTEB(
              //                   15.0, 15.0, 15.0, 15.0),
              //               child: Container(
              //                 width: double.infinity,
              //                 decoration: BoxDecoration(
              //                   color: FlutterFlowTheme.of(context)
              //                       .secondaryBackground,
              //                   border: Border.all(
              //                     color: FlutterFlowTheme.of(context).primaryText,
              //                   ),
              //                 ),
              //                 child: Column(
              //                   mainAxisSize: MainAxisSize.max,
              //                   children: [
              //                     Container(
              //                       width: MediaQuery.sizeOf(context).width * 0.8,
              //                       decoration: BoxDecoration(
              //                         color: FlutterFlowTheme.of(context)
              //                             .secondaryBackground,
              //                       ),
              //                       child: Padding(
              //                         padding: EdgeInsetsDirectional.fromSTEB(
              //                             0.0, 20.0, 0.0, 20.0),
              //                         child: Text(
              //                           'Hmmm you seem a bit far – try \ngeolocation again ',
              //                           textAlign: TextAlign.center,
              //                           style: FlutterFlowTheme.of(context)
              //                               .bodyMedium
              //                               .override(
              //                             fontFamily: 'Readex Pro',
              //                             fontSize: 20.0,
              //                             fontWeight: FontWeight.w500,
              //                           ),
              //                         ),
              //                       ),
              //                     ),
              //                     Align(
              //                       alignment: AlignmentDirectional(0.00, 0.00),
              //                       child: Padding(
              //                         padding: EdgeInsetsDirectional.fromSTEB(
              //                             0.0, 0.0, 0.0, 20.0),
              //                         child: FFButtonWidget(
              //                           onPressed: () {
              //                             currentLocation2 = null;
              //                             _distance = null;
              //                             setState(() {
              //                               pressed = false;
              //                             });
              //                             _getCurrentLocation();
              //                           },
              //                           text: 'Try Geolocation Again\n',
              //                           options: FFButtonOptions(
              //                             width:
              //                             MediaQuery.sizeOf(context).width *
              //                                 0.7,
              //                             height: 45.0,
              //                             padding: EdgeInsetsDirectional.fromSTEB(
              //                                 0.0, 0.0, 0.0, 0.0),
              //                             iconPadding:
              //                             EdgeInsetsDirectional.fromSTEB(
              //                                 0.0, 0.0, 0.0, 0.0),
              //                             color: FlutterFlowTheme.of(context)
              //                                 .primary,
              //                             textStyle: FlutterFlowTheme.of(context)
              //                                 .titleSmall
              //                                 .override(
              //                               fontFamily: 'Readex Pro',
              //                               color: Colors.white,
              //                             ),
              //                             elevation: 3.0,
              //                             borderSide: BorderSide(
              //                               color: Colors.transparent,
              //                               width: 1.0,
              //                             ),
              //                             borderRadius:
              //                             BorderRadius.circular(12.0),
              //                           ),
              //                         ),
              //                       ),
              //                     ),
              //                   ],
              //                 ),
              //               ),
              //             ),
              //           // if (!widget.isQRRequired!)
              //           //   Padding(
              //           //     padding: EdgeInsetsDirectional.fromSTEB(
              //           //         15.0, 15.0, 15.0, 15.0),
              //           //     child: Container(
              //           //       width: double.infinity,
              //           //       decoration: BoxDecoration(
              //           //         color: FlutterFlowTheme.of(context)
              //           //             .secondaryBackground,
              //           //         border: Border.all(
              //           //           color: FlutterFlowTheme.of(context).primaryText,
              //           //         ),
              //           //       ),
              //           //       child: Column(
              //           //         mainAxisSize: MainAxisSize.max,
              //           //         children: [
              //           //           Padding(
              //           //             padding: EdgeInsetsDirectional.fromSTEB(
              //           //                 0.0, 20.0, 0.0, 0.0),
              //           //             child: Container(
              //           //               width:
              //           //                   MediaQuery.sizeOf(context).width * 0.8,
              //           //               decoration: BoxDecoration(
              //           //                 color: FlutterFlowTheme.of(context)
              //           //                     .secondaryBackground,
              //           //               ),
              //           //               child: Text(
              //           //                 'You\'re close & Checked in',
              //           //                 textAlign: TextAlign.center,
              //           //                 style: FlutterFlowTheme.of(context)
              //           //                     .bodyMedium
              //           //                     .override(
              //           //                       fontFamily: 'Readex Pro',
              //           //                       fontSize: 22.0,
              //           //                       fontWeight: FontWeight.w500,
              //           //                     ),
              //           //               ),
              //           //             ),
              //           //           ),
              //           //           Padding(
              //           //             padding: EdgeInsetsDirectional.fromSTEB(
              //           //                 0.0, 20.0, 0.0, 0.0),
              //           //             child: Icon(
              //           //               Icons.check_box,
              //           //               color: Color(0xFF24963D),
              //           //               size: 200.0,
              //           //             ),
              //           //           ),
              //           //           Padding(
              //           //             padding: EdgeInsetsDirectional.fromSTEB(
              //           //                 0.0, 25.0, 0.0, 15.0),
              //           //             child: Row(
              //           //               mainAxisSize: MainAxisSize.max,
              //           //               mainAxisAlignment:
              //           //                   MainAxisAlignment.spaceAround,
              //           //               children: [
              //           //                 Align(
              //           //                   alignment:
              //           //                       AlignmentDirectional(0.00, 0.00),
              //           //                   child: FFButtonWidget(
              //           //                     onPressed: () {
              //           //                       print('Button pressed ...');
              //           //                     },
              //           //                     text: 'Cancel',
              //           //                     options: FFButtonOptions(
              //           //                       width: MediaQuery.sizeOf(context)
              //           //                               .width *
              //           //                           0.35,
              //           //                       height: 40.0,
              //           //                       padding:
              //           //                           EdgeInsetsDirectional.fromSTEB(
              //           //                               0.0, 0.0, 0.0, 0.0),
              //           //                       iconPadding:
              //           //                           EdgeInsetsDirectional.fromSTEB(
              //           //                               0.0, 0.0, 0.0, 0.0),
              //           //                       color: FlutterFlowTheme.of(context)
              //           //                           .primary,
              //           //                       textStyle:
              //           //                           FlutterFlowTheme.of(context)
              //           //                               .titleSmall
              //           //                               .override(
              //           //                                 fontFamily: 'Readex Pro',
              //           //                                 color: Colors.white,
              //           //                               ),
              //           //                       elevation: 3.0,
              //           //                       borderSide: BorderSide(
              //           //                         color: Colors.transparent,
              //           //                         width: 1.0,
              //           //                       ),
              //           //                       borderRadius:
              //           //                           BorderRadius.circular(12.0),
              //           //                     ),
              //           //                   ),
              //           //                 ),
              //           //               ],
              //           //             ),
              //           //           ),
              //           //         ],
              //           //       ),
              //           //     ),
              //           //   ),
              //           // if (!widget.isQRRequired!)
              //           //   Padding(
              //           //     padding: EdgeInsetsDirectional.fromSTEB(
              //           //         15.0, 15.0, 15.0, 15.0),
              //           //     child: Container(
              //           //       width: double.infinity,
              //           //       decoration: BoxDecoration(
              //           //         color: FlutterFlowTheme.of(context)
              //           //             .secondaryBackground,
              //           //         border: Border.all(
              //           //           color: FlutterFlowTheme.of(context).primaryText,
              //           //         ),
              //           //       ),
              //           //       child: Column(
              //           //         mainAxisSize: MainAxisSize.max,
              //           //         children: [
              //           //           Container(
              //           //             width: MediaQuery.sizeOf(context).width * 0.8,
              //           //             decoration: BoxDecoration(
              //           //               color: FlutterFlowTheme.of(context)
              //           //                   .secondaryBackground,
              //           //             ),
              //           //             child: Padding(
              //           //               padding: EdgeInsetsDirectional.fromSTEB(
              //           //                   0.0, 20.0, 0.0, 20.0),
              //           //               child: Text(
              //           //                 'Hmmm you seem a bit far – try \ngeolocation again or scan the QR Code at that location ',
              //           //                 textAlign: TextAlign.center,
              //           //                 style: FlutterFlowTheme.of(context)
              //           //                     .bodyMedium
              //           //                     .override(
              //           //                       fontFamily: 'Readex Pro',
              //           //                       fontSize: 20.0,
              //           //                       fontWeight: FontWeight.w500,
              //           //                     ),
              //           //               ),
              //           //             ),
              //           //           ),
              //           //           Align(
              //           //             alignment: AlignmentDirectional(0.00, 0.00),
              //           //             child: Padding(
              //           //               padding: EdgeInsetsDirectional.fromSTEB(
              //           //                   0.0, 0.0, 0.0, 20.0),
              //           //               child: FFButtonWidget(
              //           //                 onPressed: () {
              //           //                   print('Button pressed ...');
              //           //                 },
              //           //                 text: 'Try Geolocation Again\n',
              //           //                 options: FFButtonOptions(
              //           //                   width:
              //           //                       MediaQuery.sizeOf(context).width *
              //           //                           0.7,
              //           //                   height: 45.0,
              //           //                   padding: EdgeInsetsDirectional.fromSTEB(
              //           //                       0.0, 0.0, 0.0, 0.0),
              //           //                   iconPadding:
              //           //                       EdgeInsetsDirectional.fromSTEB(
              //           //                           0.0, 0.0, 0.0, 0.0),
              //           //                   color: FlutterFlowTheme.of(context)
              //           //                       .primary,
              //           //                   textStyle: FlutterFlowTheme.of(context)
              //           //                       .titleSmall
              //           //                       .override(
              //           //                         fontFamily: 'Readex Pro',
              //           //                         color: Colors.white,
              //           //                       ),
              //           //                   elevation: 3.0,
              //           //                   borderSide: BorderSide(
              //           //                     color: Colors.transparent,
              //           //                     width: 1.0,
              //           //                   ),
              //           //                   borderRadius:
              //           //                       BorderRadius.circular(12.0),
              //           //                 ),
              //           //               ),
              //           //             ),
              //           //           ),
              //           //         ],
              //           //       ),
              //           //     ),
              //           //   ),
              //         ],
              //       ),
              //     ),
              //   ),
            ],
          ),
        ),
      ),
    );
  }
  Future openDialog() => showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        title: Center(
          child: Text(
            'One sec... we’re reading \n the QR code',
            style: TextStyle(
              fontWeight: FontWeight.bold,
              fontSize: 15,
              color: Color(0xFF000000),
            ),
            textAlign: TextAlign.center,
          ),
        ),
        content: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SizedBox(
              height: 40.0,
              width: 40.0,
              child: CircularProgressIndicator(
                color: Colors.black,
              ),
            ),
          ],
        ),
      ));

}
