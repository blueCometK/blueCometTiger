import 'package:flutter/material.dart';
import 'package:tourism/qr_response.dart';
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'flutter_flow/flutter_flow_util.dart';

class FFAppState extends ChangeNotifier {
  static FFAppState _instance = FFAppState._internal();

  factory FFAppState() {
    return _instance;
  }

  FFAppState._internal();

  static void reset() {
    _instance = FFAppState._internal();
  }

  Future initializePersistedState() async {}

  void update(VoidCallback callback) {
    callback();
    notifyListeners();
  }

  bool _isPressed = false;
  bool get isPressed => _isPressed;
  set isPressed(bool _value) {
    _isPressed = _value;
  }
  String? decryptString;
  String? get getDecryptString => decryptString;
  set setDecryptString(String? string){
    decryptString = string;
    notifyListeners();
  }
  QrResponse? _qrResponse;
  QrResponse? get getQrResponse => _qrResponse;
  set setQrResponse(QrResponse? value) {
    _qrResponse = value;
    notifyListeners();
  }

}

LatLng? _latLngFromString(String? val) {
  if (val == null) {
    return null;
  }
  final split = val.split(',');
  final lat = double.parse(split.first);
  final lng = double.parse(split.last);
  return LatLng(lat, lng);
}

void _safeInit(Function() initializeField) {
  try {
    initializeField();
  } catch (_) {}
}

Future _safeInitAsync(Function() initializeField) async {
  try {
    await initializeField();
  } catch (_) {}
}
