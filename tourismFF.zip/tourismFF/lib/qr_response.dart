import 'dart:convert';

class QrResponse {
  String? key;
  String? campaignName;
  String? accountNumber;
  String? campaignCode;
  String? supportNumber;

  QrResponse({
    this.key,
    this.campaignName,
    this.accountNumber,
    this.campaignCode,
    this.supportNumber,

  });

  @override
  String toString() {
    return '{key:$key,customerName:$campaignName,accountNumber:$accountNumber,branchCode:$campaignCode,phoneNumber:$supportNumber}';
    //return 'QrResponse - (key: $key, customerName: $customerName, accountNumber: $accountNumber, bank: $bank, branchCode: $branchCode, phoneNumber: $phoneNumber, creditLimit: $creditLimit, eligibleAmount: $eligibleAmount)';
  }
  // @override
  // String toString() {
  //   return 'key: $key, customerName: $customerName, accountNumber: $accountNumber, bank: $bank, branchCode: $branchCode, phoneNumber: $phoneNumber, creditLimit: $creditLimit, eligibleAmount: $eligibleAmount';
  // }

  factory QrResponse.fromMap(Map<String, dynamic> data) => QrResponse(
        key: data['key'] as String?,
        campaignName: data['campaignName'] as String?,
        accountNumber: data['accountNumber'] as String?,
        campaignCode: data['campaignCode'] as String?,
        supportNumber: data['supportNumber'] as String?,
      );
  factory QrResponse.fromMap2(Map<String, dynamic> data) => QrResponse(
        key: data['key'] as String?,
        campaignName: data['customerName'] as String?,
        accountNumber: data['accountNumber'] as String?,
        campaignCode: data['branchCode'] as String?,
        supportNumber: data['phoneNumber'] as String?,
      );

  Map<String, dynamic> toMap() => {
        'key': key,
        'customerName': campaignName,
        'accountNumber': accountNumber,
        'campaignCode': campaignCode,
        'supportNumber': supportNumber,
      };


  factory QrResponse.fromJson(String data) {
    return QrResponse.fromMap(json.decode(data) as Map<String, dynamic>);
  }

  /// `dart:convert`
  ///
  /// Converts [QrResponse] to a JSON string.
  String toJson() => json.encode(toMap());
}
