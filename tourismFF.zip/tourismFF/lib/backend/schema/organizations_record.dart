import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class OrganizationsRecord extends FirestoreRecord {
  OrganizationsRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "dateCreated" field.
  DateTime? _dateCreated;
  DateTime? get dateCreated => _dateCreated;
  bool hasDateCreated() => _dateCreated != null;

  // "name" field.
  String? _name;
  String get name => _name ?? '';
  bool hasName() => _name != null;

  // "description" field.
  String? _description;
  String get description => _description ?? '';
  bool hasDescription() => _description != null;

  // "city" field.
  String? _city;
  String get city => _city ?? '';
  bool hasCity() => _city != null;

  // "state" field.
  String? _state;
  String get state => _state ?? '';
  bool hasState() => _state != null;

  // "latitude" field.
  LatLng? _latitude;
  LatLng? get latitude => _latitude;
  bool hasLatitude() => _latitude != null;

  // "longitude" field.
  LatLng? _longitude;
  LatLng? get longitude => _longitude;
  bool hasLongitude() => _longitude != null;

  // "mainImage" field.
  String? _mainImage;
  String get mainImage => _mainImage ?? '';
  bool hasMainImage() => _mainImage != null;

  // "type" field.
  String? _type;
  String get type => _type ?? '';
  bool hasType() => _type != null;

  // "ownerRef" field.
  DocumentReference? _ownerRef;
  DocumentReference? get ownerRef => _ownerRef;
  bool hasOwnerRef() => _ownerRef != null;

  // "orgType" field.
  OrganizationTypeStruct? _orgType;
  OrganizationTypeStruct get orgType => _orgType ?? OrganizationTypeStruct();
  bool hasOrgType() => _orgType != null;

  void _initializeFields() {
    _dateCreated = snapshotData['dateCreated'] as DateTime?;
    _name = snapshotData['name'] as String?;
    _description = snapshotData['description'] as String?;
    _city = snapshotData['city'] as String?;
    _state = snapshotData['state'] as String?;
    _latitude = snapshotData['latitude'] as LatLng?;
    _longitude = snapshotData['longitude'] as LatLng?;
    _mainImage = snapshotData['mainImage'] as String?;
    _type = snapshotData['type'] as String?;
    _ownerRef = snapshotData['ownerRef'] as DocumentReference?;
    _orgType = OrganizationTypeStruct.maybeFromMap(snapshotData['orgType']);
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('organizations');

  static Stream<OrganizationsRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => OrganizationsRecord.fromSnapshot(s));

  static Future<OrganizationsRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => OrganizationsRecord.fromSnapshot(s));

  static OrganizationsRecord fromSnapshot(DocumentSnapshot snapshot) =>
      OrganizationsRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static OrganizationsRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      OrganizationsRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'OrganizationsRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is OrganizationsRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createOrganizationsRecordData({
  DateTime? dateCreated,
  String? name,
  String? description,
  String? city,
  String? state,
  LatLng? latitude,
  LatLng? longitude,
  String? mainImage,
  String? type,
  DocumentReference? ownerRef,
  OrganizationTypeStruct? orgType,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'dateCreated': dateCreated,
      'name': name,
      'description': description,
      'city': city,
      'state': state,
      'latitude': latitude,
      'longitude': longitude,
      'mainImage': mainImage,
      'type': type,
      'ownerRef': ownerRef,
      'orgType': OrganizationTypeStruct().toMap(),
    }.withoutNulls,
  );

  // Handle nested data for "orgType" field.
  addOrganizationTypeStructData(firestoreData, orgType, 'orgType');

  return firestoreData;
}

class OrganizationsRecordDocumentEquality
    implements Equality<OrganizationsRecord> {
  const OrganizationsRecordDocumentEquality();

  @override
  bool equals(OrganizationsRecord? e1, OrganizationsRecord? e2) {
    return e1?.dateCreated == e2?.dateCreated &&
        e1?.name == e2?.name &&
        e1?.description == e2?.description &&
        e1?.city == e2?.city &&
        e1?.state == e2?.state &&
        e1?.latitude == e2?.latitude &&
        e1?.longitude == e2?.longitude &&
        e1?.mainImage == e2?.mainImage &&
        e1?.type == e2?.type &&
        e1?.ownerRef == e2?.ownerRef &&
        e1?.orgType == e2?.orgType;
  }

  @override
  int hash(OrganizationsRecord? e) => const ListEquality().hash([
        e?.dateCreated,
        e?.name,
        e?.description,
        e?.city,
        e?.state,
        e?.latitude,
        e?.longitude,
        e?.mainImage,
        e?.type,
        e?.ownerRef,
        e?.orgType
      ]);

  @override
  bool isValidKey(Object? o) => o is OrganizationsRecord;
}
