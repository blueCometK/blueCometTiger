import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class CampaignsRecord extends FirestoreRecord {
  CampaignsRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "name" field.
  String? _name;
  String get name => _name ?? '';
  bool hasName() => _name != null;

  // "description" field.
  String? _description;
  String get description => _description ?? '';
  bool hasDescription() => _description != null;

  // "organizationRef" field.
  DocumentReference? _organizationRef;
  DocumentReference? get organizationRef => _organizationRef;
  bool hasOrganizationRef() => _organizationRef != null;

  // "startDate" field.
  DateTime? _startDate;
  DateTime? get startDate => _startDate;
  bool hasStartDate() => _startDate != null;

  // "endDate" field.
  DateTime? _endDate;
  DateTime? get endDate => _endDate;
  bool hasEndDate() => _endDate != null;

  // "points" field.
  int? _points;
  int get points => _points ?? 0;
  bool hasPoints() => _points != null;

  // "mainPic" field.
  String? _mainPic;
  String get mainPic => _mainPic ?? '';
  bool hasMainPic() => _mainPic != null;

  // "additionalPics" field.
  List<String>? _additionalPics;
  List<String> get additionalPics => _additionalPics ?? const [];
  bool hasAdditionalPics() => _additionalPics != null;

  // "mainVideo" field.
  String? _mainVideo;
  String get mainVideo => _mainVideo ?? '';
  bool hasMainVideo() => _mainVideo != null;

  // "state" field.
  String? _state;
  String get state => _state ?? '';
  bool hasState() => _state != null;

  // "city" field.
  String? _city;
  String get city => _city ?? '';
  bool hasCity() => _city != null;

  // "address" field.
  String? _address;
  String get address => _address ?? '';
  bool hasAddress() => _address != null;

  // "latitude" field.
  LatLng? _latitude;
  LatLng? get latitude => _latitude;
  bool hasLatitude() => _latitude != null;

  // "longitude" field.
  LatLng? _longitude;
  LatLng? get longitude => _longitude;
  bool hasLongitude() => _longitude != null;

  // "rewards" field.
  List<DocumentReference>? _rewards;
  List<DocumentReference> get rewards => _rewards ?? const [];
  bool hasRewards() => _rewards != null;

  // "organizationRefs" field.
  List<DocumentReference>? _organizationRefs;
  List<DocumentReference> get organizationRefs => _organizationRefs ?? const [];
  bool hasOrganizationRefs() => _organizationRefs != null;

  // "requiresQRScan" field.
  bool? _requiresQRScan;
  bool get requiresQRScan => _requiresQRScan ?? false;
  bool hasRequiresQRScan() => _requiresQRScan != null;

  // "QRCodeAvailable" field.
  bool? _qRCodeAvailable;
  bool get qRCodeAvailable => _qRCodeAvailable ?? false;
  bool hasQRCodeAvailable() => _qRCodeAvailable != null;

  void _initializeFields() {
    _name = snapshotData['name'] as String?;
    _description = snapshotData['description'] as String?;
    _organizationRef = snapshotData['organizationRef'] as DocumentReference?;
    _startDate = snapshotData['startDate'] as DateTime?;
    _endDate = snapshotData['endDate'] as DateTime?;
    _points = castToType<int>(snapshotData['points']);
    _mainPic = snapshotData['mainPic'] as String?;
    _additionalPics = getDataList(snapshotData['additionalPics']);
    _mainVideo = snapshotData['mainVideo'] as String?;
    _state = snapshotData['state'] as String?;
    _city = snapshotData['city'] as String?;
    _address = snapshotData['Address'] as String?;
    _latitude = snapshotData['latitude'] as LatLng?;
    _longitude = snapshotData['longitude'] as LatLng?;
    _rewards = getDataList(snapshotData['rewards']);
    _organizationRefs = getDataList(snapshotData['organizationRefs']);
    _requiresQRScan = snapshotData['requiresQRScan'] as bool?;
    _qRCodeAvailable = snapshotData['QRCodeAvailable'] as bool?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('campaigns');

  static Stream<CampaignsRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => CampaignsRecord.fromSnapshot(s));

  static Future<CampaignsRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => CampaignsRecord.fromSnapshot(s));

  static CampaignsRecord fromSnapshot(DocumentSnapshot snapshot) =>
      CampaignsRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static CampaignsRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      CampaignsRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'CampaignsRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is CampaignsRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createCampaignsRecordData({
  String? name,
  String? description,
  DocumentReference? organizationRef,
  DateTime? startDate,
  DateTime? endDate,
  int? points,
  String? mainPic,
  String? mainVideo,
  String? state,
  String? city,
  String? address,
  LatLng? latitude,
  LatLng? longitude,
  bool? requiresQRScan,
  bool? qRCodeAvailable,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'name': name,
      'description': description,
      'organizationRef': organizationRef,
      'startDate': startDate,
      'endDate': endDate,
      'points': points,
      'mainPic': mainPic,
      'mainVideo': mainVideo,
      'state': state,
      'city': city,
      'address': address,
      'latitude': latitude,
      'longitude': longitude,
      'requiresQRScan': requiresQRScan,
      'QRCodeAvailable': qRCodeAvailable,
    }.withoutNulls,
  );

  return firestoreData;
}

class CampaignsRecordDocumentEquality implements Equality<CampaignsRecord> {
  const CampaignsRecordDocumentEquality();

  @override
  bool equals(CampaignsRecord? e1, CampaignsRecord? e2) {
    const listEquality = ListEquality();
    return e1?.name == e2?.name &&
        e1?.description == e2?.description &&
        e1?.organizationRef == e2?.organizationRef &&
        e1?.startDate == e2?.startDate &&
        e1?.endDate == e2?.endDate &&
        e1?.points == e2?.points &&
        e1?.mainPic == e2?.mainPic &&
        listEquality.equals(e1?.additionalPics, e2?.additionalPics) &&
        e1?.mainVideo == e2?.mainVideo &&
        e1?.state == e2?.state &&
        e1?.city == e2?.city &&
        e1?.address == e2?.address &&
        e1?.latitude == e2?.latitude &&
        e1?.longitude == e2?.longitude &&
        listEquality.equals(e1?.rewards, e2?.rewards) &&
        listEquality.equals(e1?.organizationRefs, e2?.organizationRefs) &&
        e1?.requiresQRScan == e2?.requiresQRScan &&
        e1?.qRCodeAvailable == e2?.qRCodeAvailable;
  }

  @override
  int hash(CampaignsRecord? e) => const ListEquality().hash([
        e?.name,
        e?.description,
        e?.organizationRef,
        e?.startDate,
        e?.endDate,
        e?.points,
        e?.mainPic,
        e?.additionalPics,
        e?.mainVideo,
        e?.state,
        e?.city,
        e?.address,
        e?.latitude,
        e?.longitude,
        e?.rewards,
        e?.organizationRefs,
        e?.requiresQRScan,
        e?.qRCodeAvailable
      ]);

  @override
  bool isValidKey(Object? o) => o is CampaignsRecord;
}
