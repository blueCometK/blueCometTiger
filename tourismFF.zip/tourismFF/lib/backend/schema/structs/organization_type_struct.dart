// ignore_for_file: unnecessary_getters_setters

import 'package:cloud_firestore/cloud_firestore.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class OrganizationTypeStruct extends FFFirebaseStruct {
  OrganizationTypeStruct({
    List<String>? type,
    FirestoreUtilData firestoreUtilData = const FirestoreUtilData(),
  })  : _type = type,
        super(firestoreUtilData);

  // "type" field.
  List<String>? _type;
  List<String> get type => _type ?? const [];
  set type(List<String>? val) => _type = val;
  void updateType(Function(List<String>) updateFn) => updateFn(_type ??= []);
  bool hasType() => _type != null;

  static OrganizationTypeStruct fromMap(Map<String, dynamic> data) =>
      OrganizationTypeStruct(
        type: getDataList(data['type']),
      );

  static OrganizationTypeStruct? maybeFromMap(dynamic data) =>
      data is Map<String, dynamic>
          ? OrganizationTypeStruct.fromMap(data)
          : null;

  Map<String, dynamic> toMap() => {
        'type': _type,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'type': serializeParam(
          _type,
          ParamType.String,
          true,
        ),
      }.withoutNulls;

  static OrganizationTypeStruct fromSerializableMap(
          Map<String, dynamic> data) =>
      OrganizationTypeStruct(
        type: deserializeParam<String>(
          data['type'],
          ParamType.String,
          true,
        ),
      );

  @override
  String toString() => 'OrganizationTypeStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    const listEquality = ListEquality();
    return other is OrganizationTypeStruct &&
        listEquality.equals(type, other.type);
  }

  @override
  int get hashCode => const ListEquality().hash([type]);
}

OrganizationTypeStruct createOrganizationTypeStruct({
  Map<String, dynamic> fieldValues = const {},
  bool clearUnsetFields = true,
  bool create = false,
  bool delete = false,
}) =>
    OrganizationTypeStruct(
      firestoreUtilData: FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
        delete: delete,
        fieldValues: fieldValues,
      ),
    );

OrganizationTypeStruct? updateOrganizationTypeStruct(
  OrganizationTypeStruct? organizationType, {
  bool clearUnsetFields = true,
  bool create = false,
}) =>
    organizationType
      ?..firestoreUtilData = FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
      );

void addOrganizationTypeStructData(
  Map<String, dynamic> firestoreData,
  OrganizationTypeStruct? organizationType,
  String fieldName, [
  bool forFieldValue = false,
]) {
  firestoreData.remove(fieldName);
  if (organizationType == null) {
    return;
  }
  if (organizationType.firestoreUtilData.delete) {
    firestoreData[fieldName] = FieldValue.delete();
    return;
  }
  final clearFields =
      !forFieldValue && organizationType.firestoreUtilData.clearUnsetFields;
  if (clearFields) {
    firestoreData[fieldName] = <String, dynamic>{};
  }
  final organizationTypeData =
      getOrganizationTypeFirestoreData(organizationType, forFieldValue);
  final nestedData =
      organizationTypeData.map((k, v) => MapEntry('$fieldName.$k', v));

  final mergeFields = organizationType.firestoreUtilData.create || clearFields;
  firestoreData
      .addAll(mergeFields ? mergeNestedFields(nestedData) : nestedData);
}

Map<String, dynamic> getOrganizationTypeFirestoreData(
  OrganizationTypeStruct? organizationType, [
  bool forFieldValue = false,
]) {
  if (organizationType == null) {
    return {};
  }
  final firestoreData = mapToFirestore(organizationType.toMap());

  // Add any Firestore field values
  organizationType.firestoreUtilData.fieldValues
      .forEach((k, v) => firestoreData[k] = v);

  return forFieldValue ? mergeNestedFields(firestoreData) : firestoreData;
}

List<Map<String, dynamic>> getOrganizationTypeListFirestoreData(
  List<OrganizationTypeStruct>? organizationTypes,
) =>
    organizationTypes
        ?.map((e) => getOrganizationTypeFirestoreData(e, true))
        .toList() ??
    [];
