import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class CheckinsRecord extends FirestoreRecord {
  CheckinsRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "eventRef" field.
  DocumentReference? _eventRef;
  DocumentReference? get eventRef => _eventRef;
  bool hasEventRef() => _eventRef != null;

  // "datetime" field.
  DateTime? _datetime;
  DateTime? get datetime => _datetime;
  bool hasDatetime() => _datetime != null;

  // "userRef" field.
  DocumentReference? _userRef;
  DocumentReference? get userRef => _userRef;
  bool hasUserRef() => _userRef != null;

  // "photoURL" field.
  String? _photoURL;
  String get photoURL => _photoURL ?? '';
  bool hasPhotoURL() => _photoURL != null;

  // "videoURL" field.
  String? _videoURL;
  String get videoURL => _videoURL ?? '';
  bool hasVideoURL() => _videoURL != null;

  void _initializeFields() {
    _eventRef = snapshotData['eventRef'] as DocumentReference?;
    _datetime = snapshotData['datetime'] as DateTime?;
    _userRef = snapshotData['userRef'] as DocumentReference?;
    _photoURL = snapshotData['photoURL'] as String?;
    _videoURL = snapshotData['videoURL'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('checkins');

  static Stream<CheckinsRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => CheckinsRecord.fromSnapshot(s));

  static Future<CheckinsRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => CheckinsRecord.fromSnapshot(s));

  static CheckinsRecord fromSnapshot(DocumentSnapshot snapshot) =>
      CheckinsRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static CheckinsRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      CheckinsRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'CheckinsRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is CheckinsRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createCheckinsRecordData({
  DocumentReference? eventRef,
  DateTime? datetime,
  DocumentReference? userRef,
  String? photoURL,
  String? videoURL,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'eventRef': eventRef,
      'datetime': datetime,
      'userRef': userRef,
      'photoURL': photoURL,
      'videoURL': videoURL,
    }.withoutNulls,
  );

  return firestoreData;
}

class CheckinsRecordDocumentEquality implements Equality<CheckinsRecord> {
  const CheckinsRecordDocumentEquality();

  @override
  bool equals(CheckinsRecord? e1, CheckinsRecord? e2) {
    return e1?.eventRef == e2?.eventRef &&
        e1?.datetime == e2?.datetime &&
        e1?.userRef == e2?.userRef &&
        e1?.photoURL == e2?.photoURL &&
        e1?.videoURL == e2?.videoURL;
  }

  @override
  int hash(CheckinsRecord? e) => const ListEquality()
      .hash([e?.eventRef, e?.datetime, e?.userRef, e?.photoURL, e?.videoURL]);

  @override
  bool isValidKey(Object? o) => o is CheckinsRecord;
}
