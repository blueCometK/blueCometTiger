import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class CheckinRecord extends FirestoreRecord {
  CheckinRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "eventRef" field.
  DocumentReference? _eventRef;
  DocumentReference? get eventRef => _eventRef;
  bool hasEventRef() => _eventRef != null;

  // "datetime" field.
  DateTime? _datetime;
  DateTime? get datetime => _datetime;
  bool hasDatetime() => _datetime != null;

  // "userRef" field.
  DocumentReference? _userRef;
  DocumentReference? get userRef => _userRef;
  bool hasUserRef() => _userRef != null;

  // "photoURL" field.
  String? _photoURL;
  String get photoURL => _photoURL ?? '';
  bool hasPhotoURL() => _photoURL != null;

  // "videoURL" field.
  String? _videoURL;
  String get videoURL => _videoURL ?? '';
  bool hasVideoURL() => _videoURL != null;

  // "campaignRef" field.
  DocumentReference? _campaignRef;
  DocumentReference? get campaignRef => _campaignRef;
  bool hasCampaignRef() => _campaignRef != null;

  // "createdTime" field.
  DateTime? _createdTime;
  DateTime? get createdTime => _createdTime;
  bool hasCreatedTime() => _createdTime != null;

  // "usersLocation" field.
  LatLng? _usersLocation;
  LatLng? get usersLocation => _usersLocation;
  bool hasUsersLocation() => _usersLocation != null;

  // "userScannedQRCode" field.
  bool? _userScannedQRCode;
  bool get userScannedQRCode => _userScannedQRCode ?? false;
  bool hasUserScannedQRCode() => _userScannedQRCode != null;

  DocumentReference get parentReference => reference.parent.parent!;

  void _initializeFields() {
    _eventRef = snapshotData['eventRef'] as DocumentReference?;
    _datetime = snapshotData['datetime'] as DateTime?;
    _userRef = snapshotData['userRef'] as DocumentReference?;
    _photoURL = snapshotData['photoURL'] as String?;
    _videoURL = snapshotData['videoURL'] as String?;
    _campaignRef = snapshotData['campaignRef'] as DocumentReference?;
    _createdTime = snapshotData['createdTime'] as DateTime?;
    _usersLocation = snapshotData['usersLocation'] as LatLng?;
    _userScannedQRCode = snapshotData['userScannedQRCode'] as bool?;
  }

  static Query<Map<String, dynamic>> collection([DocumentReference? parent]) =>
      parent != null
          ? parent.collection('checkin')
          : FirebaseFirestore.instance.collectionGroup('checkin');

  static DocumentReference createDoc(DocumentReference parent) =>
      parent.collection('checkin').doc();

  static Stream<CheckinRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => CheckinRecord.fromSnapshot(s));

  static Future<CheckinRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => CheckinRecord.fromSnapshot(s));

  static CheckinRecord fromSnapshot(DocumentSnapshot snapshot) =>
      CheckinRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static CheckinRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      CheckinRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'CheckinRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is CheckinRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createCheckinRecordData({
  DocumentReference? eventRef,
  DateTime? datetime,
  DocumentReference? userRef,
  String? photoURL,
  String? videoURL,
  DocumentReference? campaignRef,
  DateTime? createdTime,
  LatLng? usersLocation,
  bool? userScannedQRCode,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'eventRef': eventRef,
      'datetime': datetime,
      'userRef': userRef,
      'photoURL': photoURL,
      'videoURL': videoURL,
      'campaignRef': campaignRef,
      'createdTime': createdTime,
      'usersLocation': usersLocation,
      'userScannedQRCode': userScannedQRCode,
    }.withoutNulls,
  );

  return firestoreData;
}

class CheckinRecordDocumentEquality implements Equality<CheckinRecord> {
  const CheckinRecordDocumentEquality();

  @override
  bool equals(CheckinRecord? e1, CheckinRecord? e2) {
    return e1?.eventRef == e2?.eventRef &&
        e1?.datetime == e2?.datetime &&
        e1?.userRef == e2?.userRef &&
        e1?.photoURL == e2?.photoURL &&
        e1?.videoURL == e2?.videoURL &&
        e1?.campaignRef == e2?.campaignRef &&
        e1?.createdTime == e2?.createdTime &&
        e1?.usersLocation == e2?.usersLocation &&
        e1?.userScannedQRCode == e2?.userScannedQRCode;
  }

  @override
  int hash(CheckinRecord? e) => const ListEquality().hash([
        e?.eventRef,
        e?.datetime,
        e?.userRef,
        e?.photoURL,
        e?.videoURL,
        e?.campaignRef,
        e?.createdTime,
        e?.usersLocation,
        e?.userScannedQRCode
      ]);

  @override
  bool isValidKey(Object? o) => o is CheckinRecord;
}
