import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyCio_Q88wnQ7NKRh6IGp78l2w44zwcIbGo",
            authDomain: "tourism-efc89.firebaseapp.com",
            projectId: "tourism-efc89",
            storageBucket: "tourism-efc89.appspot.com",
            messagingSenderId: "502327329595",
            appId: "1:502327329595:web:7cac3123681fad62556d1e",
            measurementId: "G-K9DY3SFCF4"));
  } else {
    await Firebase.initializeApp();
  }
}
