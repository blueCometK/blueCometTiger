
import 'dart:async';

import 'package:geolocator/geolocator.dart';
import 'package:location/location.dart' as loc;
import 'package:permission_handler/permission_handler.dart';
import 'package:tourism/qr_response.dart';
import '/auth/firebase_auth/auth_util.dart';
import '../../components/show_bottom_nav/show_bottom_nav_widget.dart';
import '../../qr_component/qr_component.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'details_screen_model.dart';
export 'details_screen_model.dart';
import 'package:latlong2/latlong.dart' as latlng2;


class DetailsScreenWidget extends StatefulWidget {
  const DetailsScreenWidget({
    Key? key,
    required this.document,
  }) : super(key: key);

  final CampaignsRecord? document;

  @override
  _DetailsScreenWidgetState createState() => _DetailsScreenWidgetState();
}

class _DetailsScreenWidgetState extends State<DetailsScreenWidget> {
  late DetailsScreenModel _model;
  final geoLocator = GeolocatorPlatform.instance;
  //final geo = Geoflutterfire();
  QrResponse? qrResponse = QrResponse(
    key: "djkkk34343jejjeeeee",
    supportNumber: "+1227743666333",
    accountNumber: "21737474",
    campaignCode: "CAMCODE",
    campaignName: "CAMNAME",
  );

  Position? _currentPosition;
  double? _distance;
  loc.LocationData? currentLocation2;
  bool scanned = false;
  bool permissionDenied = false;
  bool checkInPressed = false;
  final loc.Location location = loc.Location();

  final scaffoldKey = GlobalKey<ScaffoldState>();
  Future<void> _getCurrentLocation() async {
    try {
      loc.LocationAccuracy locationAccuracy = loc.LocationAccuracy.high;
      await location.changeSettings(accuracy: locationAccuracy);

      var status = await Permission.location.status;
      if(status.isGranted){
        var currentLocation = await location.getLocation();
        print(currentLocation.latitude);
        print(currentLocation.longitude);
        // Position position = await geoLocator.getCurrentPosition(
        //     locationSettings: LocationSettings(
        //       accuracy: LocationAccuracy.best,
        //     )
        // );
        setState(() {
          currentLocation2 = currentLocation;
          //_currentPosition = position;
          _calculateDistance(widget.document!.latitude!.latitude,widget.document!.latitude!.longitude);
        });
      }
      else if(status.isDenied){
        if(await Permission.location.request().isGranted){
          // Position position = await geoLocator.getCurrentPosition(
          //     locationSettings: LocationSettings(
          //       accuracy: LocationAccuracy.best,
          //     )
          // );
          var currentLocation = await location.getLocation();
          print(currentLocation.latitude);
          print(currentLocation.longitude);

          // Position position = await geoLocator.getCurrentPosition(
          //     locationSettings: LocationSettings(
          //       accuracy: LocationAccuracy.best,
          //     )
          // );
          setState(() {
            currentLocation2 = currentLocation;
            //_currentPosition = position;
            _calculateDistance(widget.document!.latitude!.latitude,widget.document!.latitude!.longitude);
          });
        }
        else{
          setState(() {
            permissionDenied = true;
          });
          showSnackBarText('You need to give this app location permission to continue', context, false);
        }
      }
      else{
        if(await Permission.location.request().isGranted){
          // Position position = await geoLocator.getCurrentPosition(
          //     locationSettings: LocationSettings(
          //       accuracy: LocationAccuracy.high,
          //     )
          // );
          // setState(() {
          //   _currentPosition = position;
          //   _calculateDistance(widget.document!.latitude!.latitude,widget.document!.latitude!.longitude);
          // });
          var currentLocation = await location.getLocation();
          print(currentLocation.latitude);
          print(currentLocation.longitude);

          // Position position = await geoLocator.getCurrentPosition(
          //     locationSettings: LocationSettings(
          //       accuracy: LocationAccuracy.best,
          //     )
          // );
          setState(() {
            currentLocation2 = currentLocation;
            //_currentPosition = position;
            _calculateDistance(widget.document!.latitude!.latitude,widget.document!.latitude!.longitude);
          });
        }
        else{
          print(status);
          setState(() {
            permissionDenied = true;
          });
          showSnackBarText('You need to give this app location permission to continue', context, false);
        }
       }

    } catch (e) {
      print('Error getting current location: $e');
    }
  }
  void _calculateDistance(double centerLatitude, double centerLongitude) async {
    if (currentLocation2 != null) {
      double distance =  geoLocator.distanceBetween(
        currentLocation2!.latitude!,
        currentLocation2!.longitude!,
        centerLatitude,
        centerLongitude,
      );


      setState(() {
        _distance = distance;
      });
    }
  }
  void showSnackBarText(String text, BuildContext context, bool success){
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(text,style: TextStyle(color: Colors.white),),
        backgroundColor: success ? Colors.orange : Colors.redAccent, duration: Duration(seconds: 2, milliseconds: 500),
      ),
    );
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => DetailsScreenModel());
    _getCurrentLocation();
    FFAppState().isPressed = false;
  }

  @override
  void dispose() {
    _model.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (isiOS) {
      SystemChrome.setSystemUIOverlayStyle(
        SystemUiOverlayStyle(
          statusBarBrightness: Theme.of(context).brightness,
          systemStatusBarContrastEnforced: true,
        ),
      );
    }

    context.watch<FFAppState>();
    return GestureDetector(
      onTap: () => _model.unfocusNode.canRequestFocus
          ? FocusScope.of(context).requestFocus(_model.unfocusNode)
          : FocusScope.of(context).unfocus(),
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).secondaryBackground,
        appBar: AppBar(
          backgroundColor: FlutterFlowTheme.of(context).secondaryBackground,
          automaticallyImplyLeading: false,
          leading: FlutterFlowIconButton(
            borderColor: Colors.transparent,
            borderRadius: 30.0,
            borderWidth: 1.0,
            buttonSize: 60.0,
            icon: Icon(
              Icons.arrow_back_rounded,
              color: FlutterFlowTheme.of(context).primaryText,
              size: 30.0,
            ),
            onPressed: () async {
              context.pop();
            },
          ),
          actions: [],
          centerTitle: false,
          elevation: 0.0,
        ),
        body: SafeArea(
          top: true,
          child: Column(
            mainAxisSize: MainAxisSize.max,
            children: [
              if (!FFAppState().isPressed)
                Expanded(
                  child: Padding(
                    padding:
                    EdgeInsetsDirectional.fromSTEB(12.0, 12.0, 12.0, 12.0),
                    child: SingleChildScrollView(
                      child: Column(
                        mainAxisSize: MainAxisSize.max,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Hero(
                            tag: 'locationImage',
                            transitionOnUserGestures: true,
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(8.0),
                              child: Image.network(
                                'https://images.unsplash.com/photo-1504280390367-361c6d9f38f4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w0NTYyMDF8MHwxfHNlYXJjaHw1fHxjYW1wc3xlbnwwfHx8fDE2OTcwNDYwMzd8MA&ixlib=rb-4.0.3&q=80&w=1080',
                                width: double.infinity,
                                height: 250.0,
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                          Padding(
                            padding: EdgeInsetsDirectional.fromSTEB(
                                0.0, 20.0, 0.0, 0.0),
                            child: Text(
                              valueOrDefault<String>(
                                widget.document?.name,
                                'Name',
                              ),
                              style: FlutterFlowTheme.of(context)
                                  .titleSmall
                                  .override(
                                    fontFamily: 'Readex Pro',
                                    color: Color(0xFF2A2A2A),
                                  ),
                            ),
                          ),
                          Padding(
                            padding: EdgeInsetsDirectional.fromSTEB(
                                0.0, 15.0, 0.0, 0.0),
                            child: Text(
                              'Address',
                              style: FlutterFlowTheme.of(context)
                                  .labelMedium
                                  .override(
                                fontFamily: 'Readex Pro',
                                color: FlutterFlowTheme.of(context)
                                    .primaryText,
                                fontSize: 20.0,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                          Padding(
                            padding: EdgeInsetsDirectional.fromSTEB(
                                0.0, 5.0, 0.0, 0.0),
                            child: Container(
                              width: MediaQuery.sizeOf(context).width * 0.9,
                              decoration: BoxDecoration(
                                color: FlutterFlowTheme.of(context)
                                    .secondaryBackground,
                              ),
                              child: Text(
                                valueOrDefault<String>(
                                  widget.document?.address,
                                  'Address',
                                ),
                                style: FlutterFlowTheme.of(context)
                                    .bodyMedium
                                    .override(
                                  fontFamily: 'Readex Pro',
                                  color: Color(0xBD000000),
                                  fontSize: 18.0,
                                ),
                              ),
                            ),
                          ),
                          Padding(
                            padding: EdgeInsetsDirectional.fromSTEB(
                                0.0, 15.0, 0.0, 0.0),
                            child: Text(
                              'Description',
                              style: FlutterFlowTheme.of(context)
                                  .labelMedium
                                  .override(
                                fontFamily: 'Readex Pro',
                                color: FlutterFlowTheme.of(context)
                                    .primaryText,
                                fontSize: 20.0,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                          Padding(
                            padding: EdgeInsetsDirectional.fromSTEB(
                                0.0, 5.0, 0.0, 20.0),
                            child: Container(
                              width: MediaQuery.sizeOf(context).width * 0.9,
                              decoration: BoxDecoration(
                                color: FlutterFlowTheme.of(context)
                                    .secondaryBackground,
                              ),
                              child: Text(
                                valueOrDefault<String>(
                                  widget.document?.description,
                                  'description',
                                ),
                                style: FlutterFlowTheme.of(context)
                                    .bodyMedium
                                    .override(
                                  fontFamily: 'Readex Pro',
                                  color: Color(0xBD000000),
                                  fontSize: 18.0,
                                ),
                              ),
                            ),
                          ),
                          // Padding(
                          //   padding: EdgeInsetsDirectional.fromSTEB(
                          //       0.0, 15.0, 0.0, 0.0),
                          //   child: Text(
                          //     'QR Detail',
                          //     style: FlutterFlowTheme.of(context)
                          //         .labelMedium
                          //         .override(
                          //       fontFamily: 'Readex Pro',
                          //       color: FlutterFlowTheme.of(context)
                          //           .primaryText,
                          //       fontSize: 20.0,
                          //       fontWeight: FontWeight.w600,
                          //     ),
                          //   ),
                          // ),
                          // Padding(
                          //   padding: EdgeInsetsDirectional.fromSTEB(
                          //       0.0, 15.0, 0.0, 20.0),
                          //   child: Container(
                          //     width: MediaQuery.sizeOf(context).width * 0.9,
                          //     decoration: BoxDecoration(
                          //       color: FlutterFlowTheme.of(context)
                          //           .secondaryBackground,
                          //     ),
                          //     child: Text(
                          //       valueOrDefault<String>(
                          //         widget.document?.description,
                          //         'description',
                          //       ),
                          //       style: FlutterFlowTheme.of(context)
                          //           .bodyMedium
                          //           .override(
                          //         fontFamily: 'Readex Pro',
                          //         color: Color(0xBD000000),
                          //         fontSize: 18.0,
                          //       ),
                          //     ),
                          //   ),
                          // ),
                        ],
                      ),
                    ),
                  ),
                ),
              // if (FFAppState().isPressed)
              //   Expanded(
              //     child: Padding(
              //       padding:
              //           EdgeInsetsDirectional.fromSTEB(12.0, 12.0, 12.0, 12.0),
              //       child: SingleChildScrollView(
              //         child: Column(
              //           mainAxisSize: MainAxisSize.max,
              //           crossAxisAlignment: CrossAxisAlignment.start,
              //           children: [
              //             Hero(
              //               tag: 'locationImage',
              //               transitionOnUserGestures: true,
              //               child: ClipRRect(
              //                 borderRadius: BorderRadius.circular(8.0),
              //                 child: Image.network(
              //                   'https://images.unsplash.com/photo-1504280390367-361c6d9f38f4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w0NTYyMDF8MHwxfHNlYXJjaHw1fHxjYW1wc3xlbnwwfHx8fDE2OTcwNDYwMzd8MA&ixlib=rb-4.0.3&q=80&w=1080',
              //                   width: double.infinity,
              //                   height: 250.0,
              //                   fit: BoxFit.cover,
              //                 ),
              //               ),
              //             ),
              //             // Padding(
              //             //   padding: EdgeInsetsDirectional.fromSTEB(
              //             //       0.0, 20.0, 0.0, 0.0),
              //             //   child: Container(
              //             //     width: double.infinity,
              //             //     height: 300.0,
              //             //     decoration: BoxDecoration(
              //             //       color: FlutterFlowTheme.of(context)
              //             //           .secondaryBackground,
              //             //       borderRadius: BorderRadius.circular(20.0),
              //             //     ),
              //             //     child: ClipRRect(
              //             //       borderRadius: BorderRadius.circular(8.0),
              //             //       child: Image.asset(
              //             //         'assets/images/map.png',
              //             //         width: 300.0,
              //             //         height: 200.0,
              //             //         fit: BoxFit.cover,
              //             //       ),
              //             //     ),
              //             //   ),
              //             // ),
              //             Padding(
              //               padding: EdgeInsetsDirectional.fromSTEB(
              //                   0.0, 25.0, 0.0, 0.0),
              //               child: Text(
              //                 'You are in geoFence area so please Scan the QR code ',
              //                 style: FlutterFlowTheme.of(context)
              //                     .bodyMedium
              //                     .override(
              //                       fontFamily: 'Readex Pro',
              //                       color: Colors.green,
              //                       fontSize: 18.0,
              //                     ),
              //               ),
              //             ),
              //             Padding(
              //               padding: EdgeInsetsDirectional.fromSTEB(
              //                   0.0, 25.0, 0.0, 0.0),
              //               child: Text(
              //                 'QR Details',
              //                 style: FlutterFlowTheme.of(context)
              //                     .bodyMedium
              //                     .override(
              //                       fontFamily: 'Readex Pro',
              //                       color: Colors.black,
              //                       fontSize: 18.0,
              //                     ),
              //               ),
              //             ),
              //             Padding(
              //               padding: EdgeInsetsDirectional.fromSTEB(
              //                   0.0, 25.0, 0.0, 0.0),
              //               child: Row(
              //                 children: [
              //                   Text(
              //                     'Campaign Name - ',
              //                     style: FlutterFlowTheme.of(context)
              //                         .bodyMedium
              //                         .override(
              //                       fontFamily: 'Readex Pro',
              //                       color: Colors.black,
              //                       fontSize: 15.0,
              //                     ),
              //                   ),
              //                   Text(
              //                     scanned ? qrResponse!.campaignName! : 'Scan QR to know details',
              //                     style: FlutterFlowTheme.of(context)
              //                         .bodyMedium
              //                         .override(
              //                       fontFamily: 'Readex Pro',
              //                       color: Colors.black,
              //                       fontSize: 18.0,
              //                     ),
              //                   ),
              //                 ],
              //               )
              //             ),
              //             Padding(
              //               padding: EdgeInsetsDirectional.fromSTEB(
              //                   0.0, 25.0, 0.0, 0.0),
              //               child: Row(
              //                 children: [
              //                   Text(
              //                     'Campaign Code - ',
              //                     style: FlutterFlowTheme.of(context)
              //                         .bodyMedium
              //                         .override(
              //                       fontFamily: 'Readex Pro',
              //                       color: Colors.black,
              //                       fontSize: 15.0,
              //                     ),
              //                   ),
              //                   Text(
              //                     scanned ? qrResponse!.campaignCode! : 'Scan QR to know details',
              //                     style: FlutterFlowTheme.of(context)
              //                         .bodyMedium
              //                         .override(
              //                       fontFamily: 'Readex Pro',
              //                       color: Colors.black,
              //                       fontSize: 18.0,
              //                     ),
              //                   ),
              //                 ],
              //               )
              //             ),
              //             Padding(
              //               padding: EdgeInsetsDirectional.fromSTEB(
              //                   0.0, 25.0, 0.0, 0.0),
              //               child: Row(
              //                 children: [
              //                   Text(
              //                     'Campaign Support - ',
              //                     style: FlutterFlowTheme.of(context)
              //                         .bodyMedium
              //                         .override(
              //                       fontFamily: 'Readex Pro',
              //                       color: Colors.black,
              //                       fontSize: 15.0,
              //                     ),
              //                   ),
              //                   Text(
              //                     scanned ? qrResponse!.supportNumber! : 'Scan QR to know details',
              //                     style: FlutterFlowTheme.of(context)
              //                         .bodyMedium
              //                         .override(
              //                       fontFamily: 'Readex Pro',
              //                       color: Colors.black,
              //                       fontSize: 18.0,
              //                     ),
              //                   ),
              //                 ],
              //               )
              //             ),
              //           ],
              //         ),
              //       ),
              //     ),
              //   ),
              Padding(
                padding: EdgeInsetsDirectional.fromSTEB(24.0, 16.0, 16.0, 16.0),
                child: Row(
                  mainAxisSize: MainAxisSize.max,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    //if (!FFAppState().isPressed)
                    if ((currentUserDocument?.checkedCampains?.toList() ?? [])
                        .contains(widget.document?.reference) ==
                        false)
                      Expanded(
                        child: FFButtonWidget(
                          onPressed: () async {
                              await showModalBottomSheet(
                                isScrollControlled: true,
                                backgroundColor: Colors.transparent,
                                enableDrag: false,
                                context: context,
                                builder: (context) {
                                  return GestureDetector(
                                    onTap: () => _model
                                        .unfocusNode.canRequestFocus
                                        ? FocusScope.of(context)
                                        .requestFocus(_model.unfocusNode)
                                        : FocusScope.of(context).unfocus(),
                                    child: Padding(
                                      padding:
                                      MediaQuery.viewInsetsOf(context),
                                      child: Container(
                                        height: MediaQuery.sizeOf(context)
                                            .height *
                                            0.65,
                                        child: ShowBottomNavWidget(
                                          isQRRequired:
                                          widget.document!.requiresQRScan,
                                          document: widget.document,
                                        ),
                                      ),
                                    ),
                                  );
                                },
                              ).then((value) => safeSetState(() {
                                checkInPressed = true;
                              }));
                            // if(permissionDenied){
                            //   showSnackBarText('You need to give this app location permission to continue', context, false);
                            // }
                            // else{
                            //   if(_distance != null){
                            //     if(_distance! < 200){
                            //       setState(() {
                            //         FFAppState().isPressed = true;
                            //       });
                            //     }
                            //     else{
                            //       print(_currentPosition!.latitude);
                            //       print(_currentPosition!.longitude);
                            //       showSnackBarText('You are away from the camping area',context,false);
                            //     }
                            //   }
                            //   else{
                            //     showSnackBarText('We are fetching your location please wait',context,true);
                            //   }
                            // }
                          },
                          text: !checkInPressed ? 'Check In' : 'Sorry You’re Not Checked In',
                          options: FFButtonOptions(
                            width: 130.0,
                            height: 50.0,
                            padding: EdgeInsetsDirectional.fromSTEB(
                                0.0, 0.0, 0.0, 0.0),
                            iconPadding: EdgeInsetsDirectional.fromSTEB(
                                0.0, 0.0, 0.0, 0.0),
                            color: !checkInPressed ? FlutterFlowTheme.of(context).primary : Colors.grey,
                            textStyle: FlutterFlowTheme.of(context).titleSmall,
                            elevation: 3.0,
                            borderSide: BorderSide(
                              color: Colors.transparent,
                              width: 1.0,
                            ),
                            borderRadius: BorderRadius.circular(8.0),
                          ),
                        ),
                      ),
                    if ((currentUserDocument?.checkedCampains?.toList() ?? [])
                        .contains(widget.document?.reference) ==
                        true)
                      Expanded(
                        child: AuthUserStreamWidget(
                          builder: (context) => FFButtonWidget(
                            onPressed: () async {
                              showSnackBarText('You checked In to this event', context, true);
                            },
                            text: 'Checked In to this event',
                            options: FFButtonOptions(
                              width: 130.0,
                              height: 50.0,
                              padding: EdgeInsetsDirectional.fromSTEB(
                                  0.0, 0.0, 0.0, 0.0),
                              iconPadding: EdgeInsetsDirectional.fromSTEB(
                                  0.0, 0.0, 0.0, 0.0),
                              color: Color(0xFF24963D),
                              textStyle:
                              FlutterFlowTheme.of(context).titleSmall,
                              elevation: 3.0,
                              borderSide: BorderSide(
                                color: Colors.transparent,
                                width: 1.0,
                              ),
                              borderRadius: BorderRadius.circular(8.0),
                            ),
                          ),
                        ),
                      ),
                    // if (FFAppState().isPressed)
                    //   Expanded(
                    //     child: FFButtonWidget(
                    //       onPressed: () async {
                    //         final result = await Navigator.push(
                    //           context,
                    //           PageRouteBuilder(
                    //             pageBuilder: (_, __, ___) => QRCodeReader(),
                    //             transitionsBuilder: (_, a1, a2, child) =>
                    //                 SlideTransition(
                    //                   position: Tween(
                    //                       begin: Offset(1, 0),
                    //                       end: Offset(0, 0))
                    //                       .animate(a1),
                    //                   child: child,
                    //                 ),
                    //           ),
                    //         );
                    //
                    //
                    //         if (!mounted) return;
                    //
                    //         if (result == 'Decrypt!') {
                    //           openDialog();
                    //           // Close the modal after 4 seconds
                    //           Timer(Duration(seconds: 4), () {
                    //             Navigator.of(context).pop();
                    //           });
                    //           setState(() {
                    //             scanned = true;
                    //           });
                    //         }
                    //       },
                    //       text: 'Scan QSR Code',
                    //       options: FFButtonOptions(
                    //         width: 130.0,
                    //         height: 50.0,
                    //         padding: EdgeInsetsDirectional.fromSTEB(
                    //             0.0, 0.0, 0.0, 0.0),
                    //         iconPadding: EdgeInsetsDirectional.fromSTEB(
                    //             0.0, 0.0, 0.0, 0.0),
                    //         color: FlutterFlowTheme.of(context).primary,
                    //         textStyle: FlutterFlowTheme.of(context).titleSmall,
                    //         elevation: 3.0,
                    //         borderSide: BorderSide(
                    //           color: Colors.transparent,
                    //           width: 1.0,
                    //         ),
                    //         borderRadius: BorderRadius.circular(8.0),
                    //
                    //       ),
                    //     ),
                    //   ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
  Future openDialog() => showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        title: Center(
          child: Text(
            'We are decrypting your qrcode',
            style: TextStyle(
              fontWeight: FontWeight.bold,
              fontSize: 15,
              color: Color(0xFF000000),
            ),
          ),
        ),
        content: Row(
          children: [
            SizedBox(
              height: 30.0,
              width: 30.0,
              child: CircularProgressIndicator(
                color: Colors.black,
              ),
            ),
            SizedBox(
              width: 15.0,
            ),
            Text(
              'Anytime Now You Will Be Done',
              style: TextStyle(
                fontWeight: FontWeight.w500,
                fontSize: 12,
                color: Color(0xFF000000),
              ),
            )
          ],
        ),
      ));

}
