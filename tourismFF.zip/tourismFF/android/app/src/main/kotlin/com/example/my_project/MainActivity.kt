package com.steeful.tourism

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
